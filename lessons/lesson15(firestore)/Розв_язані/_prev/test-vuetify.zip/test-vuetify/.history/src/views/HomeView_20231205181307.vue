<template>
    <div class="home">
        <v-btn density="compact">Compact Button</v-btn>
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {},
}
</script>
