<template>
    <div class="home">
        <v-btn density="compact">Compact Button</v-btn>
        <v-tooltip text="Tooltip">
            <template #activator="{ props }">
                <v-btn v-bind="props">Tooltip</v-btn>
            </template>
        </v-tooltip>
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {},
}
</script>
