<template>
    <div class="home">
        <h2 @click="onContactsClick">Контакти</h2>
        <h2 @click="onTestClick">Тест : 8 * 3</h2>
        <h2 @click="onPredictClick">Передбачення для хлопця</h2>
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {
        onContactsClick() {
            this.$router.push({
                path: '/contacts',
            })
        },
        onTestClick() {
            // this.$router.push({ path: '/test/8/3' })
            const num1 = 8,
                num2 = 3
            this.$router.push({
                path: `/test/${num1}/${num2}`,
            })
        },
        onPredictClick() {
            this.$router.push({
                name: 'predictor',
                params: {
                    person: 'boy',
                },
            })
        },
    },
}
</script>
