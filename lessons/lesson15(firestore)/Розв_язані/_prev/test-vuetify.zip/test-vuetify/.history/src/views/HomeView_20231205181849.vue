<template>
    <div class="home">
        <v-btn density="compact">Compact Button</v-btn>
        <v-tooltip text="Tooltip">
            <template #activator="{ props }">
                <v-btn v-bind="props">Tooltip</v-btn>
            </template>
        </v-tooltip>
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    data() {
        return {
            items: [
                {
                    title: 'Item #1',
                    value: 1,
                    props: {
                        prependIcon: 'mdi-home',
                    },
                },
                {
                    title: 'Item #2',
                    value: 2,
                    props: {
                        appendIcon: 'mdi-close',
                    },
                },
                {
                    title: 'Item #3',
                    value: 3,
                    props: {
                        color: 'primary',
                    },
                },
            ],
        }
    },

    methods: {},
}
</script>
