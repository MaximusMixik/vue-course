<template>
    <div class="home">
        <div v-for="item in getItemsList" :key="item.id">{{ item.title }} - {{ item.price }}</div>
    </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'

export default {
    name: 'HomeView',

    computed: {
        ...mapGetters('todoItems', ['getItemsList']),
    },

    created() {
        this.loadList()
    },

    methods: {
        ...mapActions('todoItems', ['loadList']),
    },
}
</script>
