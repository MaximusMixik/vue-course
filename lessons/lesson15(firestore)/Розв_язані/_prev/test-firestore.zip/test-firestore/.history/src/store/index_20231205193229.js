import { createStore } from 'vuex'
import todoItems from './modules/todoItems'

export default createStore({
    namespaced: true,
    state: {},
    getters: {},
    mutations: {},
    actions: {},
    modules: {
        todoItems,
    },
})
