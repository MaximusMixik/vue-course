<template>
    <div class="home">
        <h1></h1>
        <h2
            @click="
                $router.push({
                    name: 'test',
                    params: {
                        first_num: 8,
                        second_num: 3,
                    },
                })
            "
        >
            Тест : 8 * 3
        </h2>
    </div>
</template>

<script>
export default {
    name: 'HomeView',
}
</script>
