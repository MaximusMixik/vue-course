<template>
    <div class="home"></div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'HomeView',

    created() {
        this.loadList()
    },

    methods: {
        ...mapActions('todoItems', ['loadList']),
    },
}
</script>
