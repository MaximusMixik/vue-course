export const currencyList = [
  {
    id: 'usd',
    title: '$',
    rate: 41,
  },
  {
    id: 'ua',
    title: 'грн.',
    rate: 1,
  },
]
