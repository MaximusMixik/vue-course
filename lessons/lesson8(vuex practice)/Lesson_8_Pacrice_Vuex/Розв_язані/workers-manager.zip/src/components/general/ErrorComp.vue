<template>
  <div>Something went wrong!</div>
</template>

<script>
export default {
  name: 'ErrorComp',
}
</script>

<style lang="scss" scoped></style>
