<template>
  <div>Loading .....</div>
</template>

<script>
export default {
  name: 'LoadingComp',
}
</script>

<style lang="scss" scoped></style>
