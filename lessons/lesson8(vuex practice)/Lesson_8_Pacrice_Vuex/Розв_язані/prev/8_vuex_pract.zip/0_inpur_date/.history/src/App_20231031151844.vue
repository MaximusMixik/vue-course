<template>
    <div>
        <text v-model="modText" />
        <h1>modText</h1>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import Text from './components/Text.vue'
export default {
    name: 'App',

    components: {
        Text,
    },

    data() {
        return {
            modText: '',
        }
    },

    computed: {
        ...mapGetters(['getCount']),
    },

    methods: {
        ...mapActions(['incrementCount', 'decrementCount']),
    },
}
</script>

<style lang="scss"></style>
