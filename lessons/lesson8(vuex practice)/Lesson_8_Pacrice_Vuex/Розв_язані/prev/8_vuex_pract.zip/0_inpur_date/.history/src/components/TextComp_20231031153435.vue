<template>
    <div>
        <input v-model="currentValue" type="text" @keydown="onkeyDown" />
    </div>
</template>

<script>
export default {
    props: {
        modelValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: Object,
            default: () => ({}),
        },
    },
    emits: ['update:modelValue'],

    computed: {
        currentValue: {
            get() {
                return this.modelValue
            },
            set(val) {
                console.log('====== val')
                console.log(val)
                if (val.length === 2) val += '/'
                console.log('------ val')
                console.log(val)

                this.$emit('update:modelValue', val)
            },
        },
    },

    methods: {
        onkeyDown(e) {
            console.log(e.key)
            if (!/(Backspace|\d)/.test(e.key)) {
                e.preventDefault()
            }
        },
    },
}
</script>

<style lang="scss" scoped></style>
