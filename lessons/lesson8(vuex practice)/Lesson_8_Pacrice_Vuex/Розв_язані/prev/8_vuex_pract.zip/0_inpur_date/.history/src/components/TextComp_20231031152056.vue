<template>
    <div>
        <input type="text" v-model="currentValue" />
    </div>
</template>

<script>
export default {
    props: {
        moduleValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: String,
            default: () => ({}),
        },
    },
    emits: ['update:moduleValue'],

    computed: {
        currentValue: {
            get() {
                return this.moduleValue
            },
            set(val) {
                this.$emit('update:moduleValue', val)
            },
        },
    },
}
</script>

<style lang="scss" scoped></style>
