<template>
    <div>{{ $store.state.count }}</div>
    <div>
        <button @click="incrementCount">Add</button>
        <button @click="decrementCount">Subtract</button>
    </div>
</template>

<script>
import { mapMutations } from 'vuex'

export default {
    name: 'App',

    methods: {
        ...mapMutations(['increment', 'decrement']),
    },
}
</script>

<style lang="scss"></style>
