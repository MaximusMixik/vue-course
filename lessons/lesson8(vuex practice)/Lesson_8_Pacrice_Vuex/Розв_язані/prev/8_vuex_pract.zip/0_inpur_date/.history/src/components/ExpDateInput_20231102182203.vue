<template>
    <div>
        <input type="text" @keydown="onKeyDown" />
    </div>
</template>

<script>
export default {
    name: 'ExpDateInput',

    data() {
        return {
            localValue: '',
        }
    },

    onKeyDown(event) {
        console.log(event)
    },
}
</script>

<style lang="scss" scoped></style>
