<template>
    <div>
        <input type="text" />
    </div>
</template>

<script>
export default {
    props: {
        moduleValue: {
            type: String,
        },
        moduleValueModifiers: {
            type: String,
        },
    },
}
</script>

<style lang="scss" scoped></style>
