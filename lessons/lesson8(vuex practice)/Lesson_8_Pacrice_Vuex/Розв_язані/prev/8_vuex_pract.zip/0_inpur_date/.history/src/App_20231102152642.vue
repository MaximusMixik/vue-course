<template>
    <div></div>
</template>

<script>
export default {
    name: 'App',

    components: {},

    data() {
        return {}
    },

    computed: {},

    methods: {},
}
</script>

<style lang="scss"></style>
