<template>
    <div>{{ $store.state.count }}</div>
    <div>
        <button @click="increment">Add</button>
        <button @click="decrement">Subtract</button>
    </div>
</template>

<script>
import { mapMutations } from 'vuex'

export default {
    name: 'App',

    methods: {
        ...mapMutations(['increment', 'decrement']),
    },
}
</script>

<style lang="scss"></style>
