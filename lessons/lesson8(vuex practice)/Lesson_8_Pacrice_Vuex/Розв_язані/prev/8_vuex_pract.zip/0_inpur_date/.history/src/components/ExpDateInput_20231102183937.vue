<template>
    <div>
        <input v-model="localValue" type="text" maxlength="5" @keydown="onKeyDown" />
    </div>
</template>

<script>
export default {
    name: 'ExpDateInput',

    data() {
        return {
            localValue: '',
        }
    },

    watch: {
        localValue(newValue, oldValue) {
            if (newValue.length === 2 && oldValue.length === 1) this.localValue = newValue + '/'
        },
    },

    methods: {
        onKeyDown(event) {
            console.log(event.key)

            const key = event.key
            const isDigit = key >= '0' && key <= '9'
            const isBackspace = key === 'Backspace'
            if (!isDigit && !isBackspace) event.preventDefault()
        },
    },
}
</script>

<style lang="scss" scoped></style>
