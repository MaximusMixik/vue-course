<template>
    <div>
        <exp-date-input />
    </div>
</template>

<script>
import ExpDateInput from './components/ExpDateInput.vue'
export default {
    name: 'App',

    components: {
        ExpDateInput,
    },

    data() {
        return {}
    },

    computed: {},

    methods: {},
}
</script>

<style lang="scss"></style>
