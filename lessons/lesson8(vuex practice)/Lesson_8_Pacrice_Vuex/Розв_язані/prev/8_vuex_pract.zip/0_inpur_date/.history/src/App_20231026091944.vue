<template>
    <div>{{ $store.getCount }}</div>
    <div>
        <button @click="$store.incrementCount">Add</button>
        <button @click="$storedecrementCount">Subtract</button>
    </div>
</template>

<script>
export default {
    name: 'App',
}
</script>

<style lang="scss"></style>
