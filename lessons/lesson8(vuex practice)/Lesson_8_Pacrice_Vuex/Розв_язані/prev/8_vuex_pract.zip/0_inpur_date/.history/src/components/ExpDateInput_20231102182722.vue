<template>
    <div>
        <input type="text" @keydown="onKeyDown" />
    </div>
</template>

<script>
export default {
    name: 'ExpDateInput',

    data() {
        return {
            localValue: '',
        }
    },
    methods: {
        onKeyDown(event) {
            console.log(event.key)

            const key = event.key
            const isDigit = key >= '0' && key <= '9'
            if (!isDigit) event.preventDefault()
        },
    },
}
</script>

<style lang="scss" scoped></style>
