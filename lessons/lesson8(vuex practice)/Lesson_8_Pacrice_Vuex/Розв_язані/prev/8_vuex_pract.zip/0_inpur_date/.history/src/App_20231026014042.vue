<template>
    <div>{{ getCount }}</div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'App',

    computed: {
        ...mapGetters(['getCount']),
    },

    methods: {
        ...mapActions(['incrementCount', 'decrementCount']),
    },
}
</script>

<style lang="scss"></style>
