<template>
    <div>{{ getCount }}</div>
    <div>
        <button @click="incrementCount">Add</button>
        <button @click="decrementCount">Subtract</button>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'App',

    computed: {
        ...mapGetters(['getCount']),
    },

    methods: {
        ...mapActions(['incrementCount', 'decrementCount']),
    },
}
</script>

<style lang="scss"></style>
