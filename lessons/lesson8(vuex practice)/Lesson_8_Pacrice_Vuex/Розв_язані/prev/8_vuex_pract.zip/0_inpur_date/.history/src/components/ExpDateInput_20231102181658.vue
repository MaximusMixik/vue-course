<template>
    <div>
        <input type="text" />
    </div>
</template>

<script>
export default {
    name: 'ExpDateInput',

    data() {
        return {
            localValue: value,
        }
    },
}
</script>

<style lang="scss" scoped></style>
