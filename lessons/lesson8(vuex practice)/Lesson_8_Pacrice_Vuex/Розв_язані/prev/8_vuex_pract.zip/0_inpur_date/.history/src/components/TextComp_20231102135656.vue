<template>
    <div>
        <input ref="inp" v-model="localValue" type="text" @keydown="onkeyDown" @click="onClick" />
    </div>
</template>

<script>
export default {
    props: {
        modelValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: Object,
            default: () => ({}),
        },
    },
    emits: ['update:modelValue'],

    data() {
        return {
            localValue: '',
        }
    },

    // computed: {
    //     currentValue: {
    //         get() {
    //             return this.localValue ?? this.modelValue
    //         },
    //         set(val) {
    //             //     console.log('====== val')
    //             //     console.log(val)
    //             if (val.length === 2) val += '/'
    //             console.log('------ val')
    //             console.log(val)

    //             this.$emit('update:modelValue', val)
    //         },
    //     },
    // },

    watch: {
        localValue(newValue, oldValue) {
            if (newValue.length === 2 && oldValue.length === 1) {
                newValue += '/'
                this.localValue = newValue
            } else if (oldValue.length === 3 && newValue.length === 2) {
                newValue = newValue[0]
                this.localValue = newValue
            }
            console.log('===== this.localValue')
            console.log(newValue)
            this.$emit('update:modelValue', newValue)
        },
    },

    methods: {
        onClick() {
            this.$refs.inp.selectionStart = this.modelValue.length
        },
        onkeyDown(e) {
            const isDigit = e.key >= '0' && e.key <= '9'
            const isBackspace = e.key === 'Backspace'
            if (!(isDigit || isBackspace)) {
                e.preventDefault()
                return
            }

            if (!isBackspace && this.localValue.length === 5) {
                e.preventDefault()
                return
            }

            // if (isBackspace) {
            //     if (this.localValue.length === 3) {
            //         console.log('-this.localValue')
            //         console.log(this.localValue)
            //         console.log(this.localValue[0])
            //         this.localValue = this.localValue[0]
            //     }
            // }
            // this.$emit('update:modelValue', this.localValue)
        },
    },
}
</script>

<style lang="scss" scoped></style>
