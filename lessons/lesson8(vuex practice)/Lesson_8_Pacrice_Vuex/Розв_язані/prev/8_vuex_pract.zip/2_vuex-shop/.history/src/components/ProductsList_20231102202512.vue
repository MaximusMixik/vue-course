<template>
    <div>{{ getProducts }}</div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'ProductsList',

    computed: {
        ...mapGetters(['getProducts']),
    },
}
</script>

<style lang="scss" scoped></style>
