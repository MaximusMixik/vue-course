<template>
    <select>
        <option v-for="currency in currencyList" :key="currency.title" value=""></option>
    </select>
</template>

<script>
import { currencyList } from './settings'
export default {
    name: 'CurrencySelector',

    data() {
        return {
            currencyList,
        }
    },
}
</script>

<style lang="scss" scoped></style>
