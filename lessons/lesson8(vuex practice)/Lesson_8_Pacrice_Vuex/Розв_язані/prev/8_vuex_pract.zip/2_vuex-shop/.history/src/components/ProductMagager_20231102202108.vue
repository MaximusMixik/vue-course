<template>
    <div>
        <products-list />
    </div>
</template>

<script>
import ProductsList from './ProductsList.vue'
export default {
    components: { ProductsList },
    name: 'ProductMagager',
}
</script>

<style lang="scss" scoped></style>
