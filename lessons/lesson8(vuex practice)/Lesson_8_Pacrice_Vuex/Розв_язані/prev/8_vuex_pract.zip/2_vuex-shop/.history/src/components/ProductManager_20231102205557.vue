<template>
    <div>
        <currency-selector />
        <products-list />
    </div>
</template>

<script>
import { mapActions } from 'vuex'
import CurrencySelector from './CurrencySelector.vue'

import ProductsList from './ProductsList.vue'
export default {
    name: 'ProductManager',

    components: { ProductsList, CurrencySelector },

    created() {
        this.loadDataFromFile()
    },

    methods: {
        ...mapActions(['loadDataFromFile']),
    },
}
</script>

<style lang="scss" scoped></style>
