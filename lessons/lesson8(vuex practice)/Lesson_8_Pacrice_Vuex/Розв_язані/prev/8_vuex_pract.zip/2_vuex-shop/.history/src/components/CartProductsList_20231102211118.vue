<template>
    <h1>Список товарів корзини</h1>
    <div v-for="product in getCartList" :key="product.id" class="product">
        <div>
            {{ product.title }}
        </div>
        <div>
            <span>{{ getCurrentPrice(product.price) }} {{ currencyTitle }}</span>
            <button @click="rejectProduct(product.id)">Відмовитись</button>
        </div>
    </div>
    <div>Разом до оплати {{}}</div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'CartProductsList',

    computed: {
        ...mapGetters(['getCartList', 'currencyTitle', 'getCurrentPrice', 'getTotalSum']),
    },

    methods: {
        ...mapActions(['rejectProduct']),
    },
}
</script>

<style lang="scss" scoped>
.product {
    width: 400px;
    display: flex;
    justify-content: space-between;
}
</style>
