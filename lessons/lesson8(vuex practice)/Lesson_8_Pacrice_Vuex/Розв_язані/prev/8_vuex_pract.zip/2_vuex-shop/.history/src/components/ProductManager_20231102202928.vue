<template>
    <div>
        <products-list />
    </div>
</template>

<script>
import { mapActions } from 'vuex'

import ProductsList from './ProductsList.vue'
export default {
    name: 'ProductManager',

    components: { ProductsList },

    created() {
        this.loadDataFromFile()
    },

    methods: {
        ...mapActions(['loadDataFromFile']),
    },
}
</script>

<style lang="scss" scoped></style>
