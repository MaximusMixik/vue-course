<template>
    <h1>Список товарів</h1>
    <div v-for="product in getProducts" :key="product.id">
        <div>
            {{ product.title }}
        </div>
        <div>
            <span>{{ product.price }}</span>
            <button>Купити</button>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'ProductsList',

    computed: {
        ...mapGetters(['getProducts']),
    },
}
</script>

<style lang="scss" scoped></style>
