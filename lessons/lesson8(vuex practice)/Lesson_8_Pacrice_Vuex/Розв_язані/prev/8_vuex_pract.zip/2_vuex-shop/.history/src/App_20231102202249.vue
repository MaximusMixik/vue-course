<template><product-magager</template>

<script>
import ProductMagager from './components/ProductMagager.vue'

export default {
    name: 'App',

    components: { ProductMagager },

    data() {},

    computed: {},

    methods: {},
}
</script>

<style lang="scss"></style>
