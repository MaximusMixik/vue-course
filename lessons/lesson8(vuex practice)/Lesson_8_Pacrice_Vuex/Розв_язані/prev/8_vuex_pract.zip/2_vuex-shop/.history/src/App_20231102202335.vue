<template><product-manager /></template>

<script>
import ProductManager from './components/ProductManager.vue'

export default {
    name: 'App',

    components: { ProductManager },

    data() {},

    computed: {},

    methods: {},
}
</script>

<style lang="scss"></style>
