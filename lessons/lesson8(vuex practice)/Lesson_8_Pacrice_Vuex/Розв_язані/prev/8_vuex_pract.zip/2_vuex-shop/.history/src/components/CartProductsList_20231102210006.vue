<template>
    <h1>Список товарів корзини</h1>
    <div v-for="product in getCartList" :key="product.id" class="product">
        <div>
            {{ product.title }}
        </div>
        <div>
            <span>{{ getCurrentPrice(product.price) }} {{ currencyTitle }}</span>
            <button>Купити</button>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'CartProductsList',

    computed: {
        ...mapGetters(['getCartList', 'currencyTitle', 'getCurrentPrice']),
    },
}
</script>

<style lang="scss" scoped>
.product {
    width: 400px;
    display: flex;
    justify-content: space-between;
}
</style>
