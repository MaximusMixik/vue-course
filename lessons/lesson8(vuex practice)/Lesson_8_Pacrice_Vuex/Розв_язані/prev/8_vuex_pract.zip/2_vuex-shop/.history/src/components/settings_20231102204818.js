export currencyList=[
    {
        title:'Гривня',
        rate:1
    },
    {
        title:'Долар',
        rate: 1/38
    },
]
