<template>
    <div>
        <products-list />
    </div>
</template>

<script>
import ProductsList from './ProductsList.vue'
export default {
    name: 'ProductManager',

    components: { ProductsList },
}
</script>

<style lang="scss" scoped></style>
