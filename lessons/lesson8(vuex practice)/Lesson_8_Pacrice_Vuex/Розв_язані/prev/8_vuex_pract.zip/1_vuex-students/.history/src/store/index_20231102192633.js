import { createStore } from 'vuex'
import students from '../data/students.json'

// Create a new store instance.
const store = createStore({
    state() {
        return {
            studentsList: ['ok'],
        }
    },
    getters: {
        // getStudentsList(state){
        //     return state.studentsList
        // }
        getStudentsList: ({ studentsList }) => studentsList,

        getStudentsListWithScoreCategory: (state) => {
            return (scoreCategory) => {
                if (scoreCategory === 12) state.studentsList
                else
                    state.studentsList.map((student) => ({
                        ...student,
                        score: getScoreIn5Category(student.score),
                    }))
            }
        },
    },
    mutations: {
        setStudentList(state, list) {
            state.studentsList = list
        },
    },
    actions: {
        loadStudentsList({ commit }) {
            commit('setStudentList', students)
        },
    },
})
export default store
