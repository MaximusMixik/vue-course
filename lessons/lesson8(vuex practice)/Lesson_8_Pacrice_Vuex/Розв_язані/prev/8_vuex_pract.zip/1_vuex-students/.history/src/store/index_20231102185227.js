import { createStore } from 'vuex'

// Create a new store instance.
const store = createStore({
    state() {
        return {
            studentsList: [],
        }
    },
    getters: {},
    mutations: {},
    actions: {},
})
export default store
