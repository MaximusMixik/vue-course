<template>
    <select v-model="currentCategory">
        <option v-for="category in studentsCategoryList" :key="category.title" :value="category">
            {{ category.title }}
        </option>
    </select>
    <div>{{ currentCategory }}</div>
</template>

<script>
import { studentsCategoryList } from './settings'
export default {
    name: 'StudentsCategory',

    data() {
        return {
            currentCategory: null,
        }
    },

    computed: {
        studentsCategoryList,
    },
}
</script>

<style lang="scss" scoped></style>
