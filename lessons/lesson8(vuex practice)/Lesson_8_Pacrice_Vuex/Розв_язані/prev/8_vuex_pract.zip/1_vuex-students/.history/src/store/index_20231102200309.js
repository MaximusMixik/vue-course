import { createStore } from 'vuex'
import students from '../data/students.json'
import { getScoreIn5Category } from './helpers'

// Create a new store instance.
const store = createStore({
    state() {
        return {
            studentsList: ['ok'],
            currentCategory: undefined,
        }
    },
    getters: {
        getFilteredByStudentsCategoryList: ({ studentsList, currentCategory }) => {
            if (!currentCategory) return studentsList
            else
                return studentsList.filter(
                    (student) => student.score >= currentCategory.minValue && student.score <= currentCategory.maxValue
                )
        },

        // getStudentsList(state){
        //     return state.studentsList
        // }
        getCurrentCategory: ({ currentCategory }) => currentCategory,

        getStudentsList: ({ studentsList }) => studentsList,

        getStudentsListWithScoreCategory: (state) => {
            return (scoreCategory) => {
                if (scoreCategory === 12) return state.studentsList
                else {
                    const studentsListCopy = JSON.parse(JSON.stringify(state.studentsList))
                    studentsListCopy.forEach((student) => {
                        student.score = getScoreIn5Category(student.score)
                    })
                    return studentsListCopy
                }
            }
        },

        // getStudentsListWithScoreCategory: (state) => (scoreCategory) =>
        //     scoreCategory === 12
        //         ? state.studentsList
        //         : state.studentsList.map((student) => ({
        //               ...student,
        //               score: getScoreIn5Category(student.score),
        //           })),
    },
    mutations: {
        setStudentList(state, list) {
            state.studentsList = list
        },
        setCategory(state, category) {
            state.currentCategory = category
        },
    },
    actions: {
        loadStudentsList({ commit }) {
            commit('setStudentList', students)
        },
        setStudentCategory({ commit }, category) {
            commit('setCategory', category)
        },
    },
})
export default store
