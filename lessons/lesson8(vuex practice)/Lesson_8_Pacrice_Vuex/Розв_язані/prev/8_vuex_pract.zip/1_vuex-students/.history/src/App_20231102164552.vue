<template>
    <div>{{ students[0].name }}</div>
</template>

<script>
import students from './data/students.json'
export default {
    name: 'App',

    components: {},

    data() {
        return {
            students,
        }
    },

    computed: {},

    methods: {},
}
</script>

<style lang="scss"></style>
