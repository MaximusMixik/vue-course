<template>
    <select>
        <option v-for="category in studentsCategoryList" :key="category.title" value=""></option>
    </select>
</template>

<script>
import { studentsCategoryList } from './settings'
export default {
    name: 'StudentsCategory',

    computed: {
        studentsCategoryList,
    },
}
</script>

<style lang="scss" scoped></style>
