<template>
    <div v-for="student in studentsData" :key="student.id" class="student-container">
        <div>{{ student.name }}</div>
        <div>{{ student.score }}</div>
    </div>
</template>

<script>
export default {
    name: 'StudentsList',

    props: {
        studentsData: {
            type: Array,
            default: () => [],
        },
    },
}
</script>

<style lang="scss" scoped>
.student-container {
    width: 300px;
    display: flex;
    justify-content: space-between;
}
</style>
