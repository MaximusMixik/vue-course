<template>
    <div>{{ students[0].score + 100 }}</div>
</template>

<script>
import students from './data/students.json'
export default {
    name: 'App',

    components: {},

    data() {
        return {
            students,
        }
    },

    computed: {},

    methods: {},
}
</script>

<style lang="scss"></style>
