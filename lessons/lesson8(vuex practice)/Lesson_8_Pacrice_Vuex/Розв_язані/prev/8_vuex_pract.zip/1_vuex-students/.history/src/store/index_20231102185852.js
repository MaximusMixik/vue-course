import { createStore } from 'vuex'
import students from '../data/students.json'

// Create a new store instance.
const store = createStore({
    state() {
        return {
            studentsList: [],
        }
    },
    getters: {
        // getStudentsList(state){
        //     return state.studentsList
        // }
        getStudentsList: ({ studentsList }) => studentsList,
    },
    mutations: {
        setStudentList(state, list) {
            state.studentsList = list
        },
    },
    actions: {
        loadStudentsList({ commit }) {
            commit('setStudentList', students)
        },
    },
})
export default store
