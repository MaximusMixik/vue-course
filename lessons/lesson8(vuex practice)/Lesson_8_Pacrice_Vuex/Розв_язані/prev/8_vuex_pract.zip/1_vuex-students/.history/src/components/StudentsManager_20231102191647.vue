<template>
    <score-category v-model="scoreCategory" />

    <students-list :students-data="getStudentsList" />
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import ScoreCategory from './ScoreCategory.vue'
import StudentsList from './StudentsList.vue'

export default {
    name: 'StudentsManager',

    components: { StudentsList, ScoreCategory },

    data() {
        return {
            scoreCategory: 12,
        }
    },

    computed: {
        ...mapGetters(['getStudentsList']),
    },

    created() {
        this.loadStudentsList()
    },

    methods: {
        ...mapActions(['loadStudentsList']),
    },
}
</script>

<style lang="scss" scoped></style>
