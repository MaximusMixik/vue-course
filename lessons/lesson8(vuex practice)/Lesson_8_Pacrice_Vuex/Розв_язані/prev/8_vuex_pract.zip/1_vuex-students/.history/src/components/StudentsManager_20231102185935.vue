<template>
    <div></div>
</template>

<script>
export default {
    name: 'StudentsManager',
}
</script>

<style lang="scss" scoped></style>
