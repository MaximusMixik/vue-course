import { createStore } from 'vuex'
import students from '../data/students.json'
import { getScoreIn5Category } from './helpers'

// Create a new store instance.
const store = createStore({
    state() {
        return {
            studentsList: ['ok'],
        }
    },
    getters: {
        // getStudentsList(state){
        //     return state.studentsList
        // }
        getStudentsList: ({ studentsList }) => studentsList,

        // getStudentsListWithScoreCategory: (state) => {
        //     return (scoreCategory) => {
        //         if (scoreCategory === 12) return state.studentsList
        //         else {
        //             const studentsListCopy = JSON.parse(JSON.stringify(state.studentsList))
        //             studentsListCopy.forEach((student) => {
        //                 student.score = getScoreIn5Category(student.score)
        //             })
        //             return studentsListCopy
        //         }
        //     }
        // },

        getStudentsListWithScoreCategory: (state) => (scoreCategory) =>
            scoreCategory === 12
                ? state.studentsList
                : state.studentsList.map((student) => ({
                      ...student,
                      score: getScoreIn5Category(student.score),
                  })),
    },
    mutations: {
        setStudentList(state, list) {
            state.studentsList = list
        },
    },
    actions: {
        loadStudentsList({ commit }) {
            commit('setStudentList', students)
        },
    },
})
export default store
