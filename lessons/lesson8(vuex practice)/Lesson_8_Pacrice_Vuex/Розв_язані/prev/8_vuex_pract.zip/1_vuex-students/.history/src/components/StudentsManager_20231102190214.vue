<template>
    <div>{{ getStudentsList }}</div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'StudentsManager',

    computed: {
        ...mapGetters(['getStudentsList']),
    },
}
</script>

<style lang="scss" scoped></style>
