<template>
    <div>
        <label>
            Система оцінювання
            <select v-model="currentCategory">
                <option :value="12">12</option>
                <option :value="5">5</option>
            </select>
        </label>
    </div>
</template>

<script>
export default {
    name: 'ScoreCategory',

    props: {
        modelValue: {
            type: Number,
            default: null,
        },
    },

    computed: {
        currentCategory: {
            get() {},
            set(val) {},
        },
    },
}
</script>

<style lang="scss" scoped></style>
