<template>
    <div v-for="student in studentsData" :key="student.id">
        <div>{{ student.name }}</div>
        <div>{{ student.score }}</div>
    </div>
</template>

<script>
export default {
    name: 'StudentsList',

    props: {
        studentsData: {
            type: Array,
            default: () => [],
        },
    },
}
</script>

<style lang="scss" scoped></style>
