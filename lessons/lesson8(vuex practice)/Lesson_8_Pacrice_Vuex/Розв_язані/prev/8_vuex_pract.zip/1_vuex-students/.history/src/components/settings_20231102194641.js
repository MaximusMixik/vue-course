export const studentysCategoryList = [
    {
        title: 'Відмінник',
        minScore: 10,
        maxScore: 12,
    },
    {
        title: 'Хорошист',
        minScore: 7,
        maxScore: 9,
    },
    {
        title: 'Трійочник',
        minScore: 4,
        maxScore: 6,
    },
    {
        title: 'Двійочник',
        minScore: 1,
        maxScore: 3,
    },
    {
        title: 'Блатник',
        minScore: 13,
        maxScore: 1000,
    },
]
