<template>
    <div></div>
</template>

<script>
import { studentsCategoryList } from './settings'
export default {
    name: 'StudentsCategory',

    computed: {
        studentsCategoryList,
    },
}
</script>

<style lang="scss" scoped></style>
