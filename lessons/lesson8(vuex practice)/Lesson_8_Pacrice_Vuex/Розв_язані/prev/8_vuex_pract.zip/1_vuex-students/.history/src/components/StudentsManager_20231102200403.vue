<template>
    <students-category />
    <div>
        {{ getFilteredByStudentsCategoryList }}
    </div>
    <score-category v-model="scoreCategory" />
    {{ scoreCategory }}
    <students-list :students-data="filteredStudentsList" />
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import ScoreCategory from './ScoreCategory.vue'
import StudentsCategory from './StudentsCategory.vue'
import StudentsList from './StudentsList.vue'

export default {
    name: 'StudentsManager',

    components: { StudentsList, ScoreCategory, StudentsCategory },

    data() {
        return {
            scoreCategory: null,
        }
    },

    computed: {
        ...mapGetters(['getStudentsList', 'getStudentsListWithScoreCategory', 'getFilteredByStudentsCategoryList']),

        filteredStudentsList() {
            if (this.scoreCategory) return this.getStudentsListWithScoreCategory(this.scoreCategory)
            else return this.getStudentsList
        },
    },

    created() {
        this.loadStudentsList()
    },

    methods: {
        ...mapActions(['loadStudentsList']),
    },
}
</script>

<style lang="scss" scoped></style>
