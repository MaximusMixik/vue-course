<template>
    <students-list />
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import StudentsList from './StudentsList.vue'

export default {
    name: 'StudentsManager',

    components: { StudentsList },

    computed: {
        ...mapGetters(['getStudentsList']),
    },

    created() {
        this.loadStudentsList()
    },

    methods: {
        ...mapActions(['loadStudentsList']),
    },
}
</script>

<style lang="scss" scoped></style>
