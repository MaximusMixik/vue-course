<template>
    <div>{{ getStudentsList }}</div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'StudentsManager',

    computed: {
        ...mapGetters(['getStudentsList']),
    },

    methods: {
        ...mapActions(['loadStudentsList']),
    },

    created() {
        this.loadStudentsList()
    },
}
</script>

<style lang="scss" scoped></style>
