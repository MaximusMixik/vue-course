<template>
    <students-manager />
</template>

<script>
import StudentsManager from './components/StudentsManager.vue'
export default {
    name: 'App',

    components: {
        StudentsManager,
    },

    data() {
        return {}
    },

    computed: {},

    methods: {},
}
</script>

<style lang="scss"></style>
