<template>
  <label>
    {{ title }}
    <!-- <input
      type="text"
      :value="modelValue"
      @input="$emit('update:modelValue', $event.target.value)"
    /> -->
    <input type="text" v-model="cValue" />
  </label>
</template>

<script>
export default {
  name: 'CustomInput',

  props: {
    title: {
      type: String,
      default: '',
    },
    modelValue: {
      type: String,
    },
  },

  computed: {
    cValue: {
      get() {
        return this.modelValue
      },
      set(val) {
        this.$emit('update:modelValue', val)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
