<template>
  <label>
    {{ title }}
    <input
      type="text"
      :value="modelValue"
      @input="$emit('update:modelValue', $event.target.value)"
    />
  </label>
</template>

<script>
export default {
  name: 'FavoriteCard',

  props: {
    dollarRate: {
      type: Number,
      required: true,
    },

    cardData: {
      type: Object,
      default: () => ({}),
    },
  },
}
</script>

<style lang="css" scoped>
.container {
  display: inline-block;
  width: 80px;
  height: 150px;
  border: 2px solid green;
  border-radius: 12px;
}
.img {
  width: 80px;
  height: 130px;
}
.title {
  color: blueviolet;
}
</style>
