<template>
  <my-selector
    selector-title="Brand"
    :selector-options="carBrands"
    v-model="selectedBrandId"
  />
  <div>selectedBrandId = {{ selectedBrandId }}</div>
</template>

<script>
import MySelector from './components/MySelector.vue'
import { carBrands } from './constants/data'
export default {
  name: 'App',

  components: {
    MySelector,
  },

  data() {
    return {
      carBrands,

      selectedBrandId: null,
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
