export const carBrands = [
  { id: 1, title: 'Toyota' },
  { id: 2, title: 'Ford' },
  { id: 3, title: 'Honda' },
  { id: 4, title: 'Chevrolet' },
  { id: 5, title: 'BMW' },
  { id: 6, title: 'Audi' },
  { id: 7, title: 'Mercedes-Benz' },
]

export const carBodyTypes = [
  { id: 1, title: 'Седан' },
  { id: 2, title: 'Хетчбек' },
  { id: 3, title: 'Купе' },
  { id: 4, title: 'Універсал' },
  { id: 5, title: 'Спорткар' },
  { id: 6, title: 'Кросовер' },
  { id: 7, title: 'Мінівен' },
]

const fuelTypes = [
  { id: 1, title: 'Бензин' },
  { id: 2, title: 'Дизель' },
  { id: 3, title: 'Гібрид' },
  { id: 4, title: 'Електрика' },
  { id: 5, title: 'Газ' },
]
