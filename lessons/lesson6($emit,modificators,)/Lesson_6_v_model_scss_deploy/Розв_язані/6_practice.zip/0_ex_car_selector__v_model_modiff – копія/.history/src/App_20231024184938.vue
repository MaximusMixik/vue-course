<template>
  <my-selector
    selector-title="Тип кузова"
    :selector-options="carBodyTypes"
    v-model="selectedBrandId"
  />
  <my-selector
    selector-title="Марка"
    :selector-options="carBrands"
    v-model="selectedBrandId"
  />
  <my-selector
    selector-title="Тип палива"
    :selector-options="fuelTypes"
    v-model="selectedBrandId"
  />
  <div>selectedBrandId = {{ selectedBrandId }}</div>
  <div>selectedBodyId = {{ selectedBodyId }}</div>
  <div>selectedFueld = {{ selectedFueld }}</div>
</template>

<script>
import MySelector from './components/MySelector.vue'
import { carBrands, carBodyTypes, fuelTypes } from './constants/data'
export default {
  name: 'App',

  components: {
    MySelector,
  },

  data() {
    return {
      carBrands,

      selectedBrandId: null,
      selectedBodyId: null,
      selectedFueld: null,
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
