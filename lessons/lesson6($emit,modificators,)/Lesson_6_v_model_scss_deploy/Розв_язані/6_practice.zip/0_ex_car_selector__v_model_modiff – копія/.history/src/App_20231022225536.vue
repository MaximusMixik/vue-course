<template>
  <login-form v-model:login="userLogin" v-model:password="userPassword" />
  <hr />
  <div>User data: {{ userLogin }} - {{ userPassword }}</div>
</template>

<script>
import LoginForm from './components/LoginForm.vue'

export default {
  name: 'App',

  components: {
    LoginForm,
  },

  data() {
    return {
      userLogin: null,
      userPassword: null,
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
