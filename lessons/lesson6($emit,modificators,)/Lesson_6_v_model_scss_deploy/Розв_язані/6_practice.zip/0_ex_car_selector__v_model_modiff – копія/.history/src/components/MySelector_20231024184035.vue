<template>
  <label>
    {{ selectorTitle }}

    <select>
      <option v-for="opt in selectorOptions" :key="opt.id" :value="opt.id">
        {{ opt.title }}
      </option>
    </select>
  </label>
</template>

<script>
export default {
  name: 'MySelector',

  props: {
    selectorTitle: {
      type: String,
      required: true,
    },
    selectorOptions: {
      type: Array,
      required: true,
    },
  },

  computed: {
    // selectedValue:{
    //     get(){},
    //     set(val){}
    // }
  },
}
</script>

<style lang="scss" scoped></style>
