<template>
  <label>
    Login
    <input type="text" v-model="loginValue" />
  </label>
  <label>
    Password
    <input type="text" v-model="passwordValue" />
  </label>
</template>

<script>
export default {
  name: 'LoginForm',

  props: {
    login: {
      type: String,
      default: '',
    },
    password: {
      type: String,
      default: '',
    },
  },

  computed: {
    loginValue: {
      get() {
        return this.login
      },
      set(newVal) {
        this.$emit('update:login', newVal)
      },
    },
    passwordValue: {
      get() {
        return this.password
      },
      set(newVal) {
        this.$emit('update:password', newVal)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
