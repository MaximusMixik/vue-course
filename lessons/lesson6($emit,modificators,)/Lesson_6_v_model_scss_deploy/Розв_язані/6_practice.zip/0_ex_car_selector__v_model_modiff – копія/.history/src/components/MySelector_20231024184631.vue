<template>
  <label>
    {{ selectorTitle }}

    <select v-model="selectedValue">
      <option v-for="opt in selectorOptions" :key="opt.id" :value="opt.id">
        {{ opt.title }}
      </option>
    </select>
  </label>
</template>

<script>
export default {
  name: 'MySelector',

  props: {
    selectorTitle: {
      type: String,
      required: true,
    },
    selectorOptions: {
      type: Array,
      required: true,
    },
    modelValue: {
      type: Number,
    },
  },

  computed: {
    selectedValue: {
      get() {
        return this.modelValue
      },
      set(val) {
        this.$emit('update:modelValue', val)
      },
    },
  },
}
</script>

<style lang="scss" scoped></style>
