<template>
  <label>
    Login
    <input
      type="text"
      :value="login"
      @input="$emit('update:login', $event.target.value)"
    />
  </label>
  <label>
    Password
    <input
      type="text"
      :value="password"
      @input="$emit('update:password', $event.target.value)"
    />
  </label>
</template>

<script>
export default {
  name: 'LoginForm',

  props: {
    login: {
      type: String,
      default: '',
    },
    password: {
      type: String,
      default: '',
    },
  },
}
</script>

<style lang="css" scoped></style>
