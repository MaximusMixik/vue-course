<template>
  <div></div>
</template>

<script>
export default {
  name: 'MySelector',

  props: {
    selectorTitle: {
      type: String,
      required: true,
    },
    selectotOptions: {
      type: Array,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped></style>
