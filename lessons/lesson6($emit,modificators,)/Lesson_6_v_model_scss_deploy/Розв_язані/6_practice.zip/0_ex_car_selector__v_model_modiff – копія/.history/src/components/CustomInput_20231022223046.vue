<template>
  <label>
    {{ title }}
    <input
      type="text"
      :value="modelValue"
      @input="$emit('update:modelValue', $event.target.value)"
    />
  </label>
</template>

<script>
export default {
  name: 'CustomInput',

  props: {
    title: {
      type: String,
      default: '',
    },
    modelValue: {
      type: String,
    },
  },
}
</script>

<style lang="css" scoped></style>
