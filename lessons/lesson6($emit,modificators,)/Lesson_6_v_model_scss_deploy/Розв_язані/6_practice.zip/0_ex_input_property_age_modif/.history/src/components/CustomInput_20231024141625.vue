<template>
  <label>
    {{ title }}
    <input type="text" v-model="currentValue" :class="inputClass" />
  </label>
</template>
<script>
export default {
  name: 'CustomInput',
  props: {
    title: { type: String, default: '' },
    modelValue: {
      type: String,
    },
    modelModifiers: {
      default: () => ({}),
    },
  },
  computed: {
    inputClass() {
      if (this.modelModifiers.ageFormat)
        return this.modelValue < 18 ? 'err' : 'ok'
    },
    currentValue: {
      get() {
        if (this.modelModifiers.ageFormat) return this.modelValue
      },
      set(newVal) {
        console.log(this.modelModifiers)
        if (this.modelModifiers.trimStart) newVal = newVal.trimStart()
        if (this.modelModifiers.makeFirstUppercase && newVal) {
          newVal = `${newVal[0].toUpperCase()}${newVal.slice(1)}`
        }
        this.$emit('update:modelValue', newVal)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
