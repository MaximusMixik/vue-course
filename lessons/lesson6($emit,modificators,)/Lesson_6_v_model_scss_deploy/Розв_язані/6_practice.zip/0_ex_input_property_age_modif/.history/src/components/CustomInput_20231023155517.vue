<template>
  <label>
    {{ title }}
    <input type="text" v-model="currentValue" />
  </label>
</template>

<script>
export default {
  name: 'CustomInput',

  props: {
    title: {
      type: String,
      default: '',
    },
    modelValue: {
      type: String,
    },
    modelModifiers: {
      default: () => ({}),
    },
  },

  computed: {
    currentValue: {
      get() {
        return this.modelValue
      },
      set(newVal) {
        let val = newVal.trimStart()
        if (val) {
          val = `${val[0].toUpperCase()}${val.slice(1)}`
        }
        this.$emit('update:modelValue', val)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
