<template>
  <label>
    {{ title }}
    <input type="text" v-model="currentValue" />
  </label>
</template>
<script>
export default {
  name: 'CustomInput',
  props: {
    title: { type: String, default: '' },
    modelValue: {
      type: String,
    },
    modelModifiers: {
      default: () => ({}),
    },
  },
  computed: {
    currentValue: {
      get() {
        return this.modelValue
      },
      set(newVal) {
        if (this.modelModifiers.trimStart) newVal = newVal.trimStart()
        if (this.modelModifiers.makeFirstUppercase && newVal) {
          newVal = `${newVal[0].toUpperCase()}${newVal.slice(1)}`
        }
        this.$emit('update:modelValue', newVal)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
