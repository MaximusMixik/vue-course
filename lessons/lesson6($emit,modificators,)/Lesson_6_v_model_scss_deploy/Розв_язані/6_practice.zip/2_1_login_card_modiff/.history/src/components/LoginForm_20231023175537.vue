<template>
  <label>
    Login
    <input type="text" v-model="loginValue" />
  </label>
  <label>
    Password
    <input type="text" v-model="cardValue" @keydown="onKeyUp" />
  </label>
</template>
<script>
export default {
  name: 'LoginForm',
  props: {
    login: { type: String },
    loginModifiers: { default: () => ({}) },
    cardNumber: { type: String },
    cardNumberModifiers: { default: () => ({}) },
  },
  data() {
    return {
      updateKey: 0,
    }
  },
  computed: {
    loginValue: {
      get() {
        return this.login
      },
      set(newVal) {
        if (this.loginModifiers.uppercase) newVal = newVal.toUpperCase()
        this.$emit('update:login', newVal)
      },
    },
    cardValue: {
      get() {
        return this.cardNumber
      },
      set(newVal) {
        console.log('newVal')
        console.log(newVal)
        if (this.cardNumberModifiers.separate4Digits) {
          newVal = newVal.replace(/(\d{4}(?=\S+))/g, '$1 ')
        }
        this.$emit('update:cardNumber', newVal)
      },
    },
  },

  methods: {
    onKeyUp(e) {
      console.log('key')
      console.log(e.key)
      console.log(/\D/.test(e.key))
      if (/\D/.test(e.key)) {
        e.preventDefault()
        return false
      } else return true
      // e.preventDefault()
    },
  },
}
</script>

<style lang="css" scoped></style>
