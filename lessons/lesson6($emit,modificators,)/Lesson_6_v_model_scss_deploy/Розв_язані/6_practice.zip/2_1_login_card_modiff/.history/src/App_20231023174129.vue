<template>
  <login-form
    v-model:login.uppercase="userLogin"
    v-model:cardNumber.separate4Digits="userCreditCard"
  />
  <hr />
  <div>User data: {{ userLogin }} : {{ userCreditCard }}</div>
</template>

<script>
import LoginForm from './components/LoginForm.vue'

export default {
  name: 'App',

  components: {
    LoginForm,
  },

  data() {
    return {
      userLogin: null,
      userCreditCard: null,
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
