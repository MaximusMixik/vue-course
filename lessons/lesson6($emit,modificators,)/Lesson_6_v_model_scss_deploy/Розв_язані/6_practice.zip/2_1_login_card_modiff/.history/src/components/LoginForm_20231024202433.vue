<template>
  <label> Login <input type="text" v-model="loginValue" /> </label>
  <label> Card number <input type="text" v-model="cardValue" /> </label>
</template>
<script>
export default {
  name: 'LoginForm',
  props: {
    login: { type: String },
    loginModifiers: { default: () => ({}) },
    cardNumber: { type: String },
    cardNumberModifiers: { default: () => ({}) },
  },
  computed: {
    loginValue: {
      get() {
        return this.login
      },
      set(newVal) {
        if (this.loginModifiers.uppercase) newVal = newVal.toUpperCase()
        this.$emit('update:login', newVal)
      },
    },
    cardValue: {
      get() {
        return (this.cardNumber ?? '')
          .toString()
          .replace(/(\d{4}(?=\S+))/g, '$1 ')
      },
      set(newVal) {
        newVal = newVal.replace(/\D/g, '')

        this.$emit('update:cardNumber', newVal)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
