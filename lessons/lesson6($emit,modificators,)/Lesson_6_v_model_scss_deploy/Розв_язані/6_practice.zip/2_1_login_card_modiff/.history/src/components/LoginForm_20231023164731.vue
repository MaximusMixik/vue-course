<template>
  <label>
    Login
    <input type="text" v-model="loginValue" />
  </label>
  <label>
    Password
    <input type="text" v-model="cardValue" />
  </label>
</template>
<script>
export default {
  name: 'LoginForm',
  props: {
    login: { type: String },
    loginModifiers: { default: () => ({}) },
    cardNumber: { type: String },
    cardNumberModifiers: { default: () => ({}) },
  },
  computed: {
    loginValue: {
      get() {
        return this.login
      },
      set(newVal) {
        if (this.loginModifiers.uppercase) newVal = newVal.upperCase()
        this.$emit('update:login', newVal)
      },
    },
    cardValue: {
      get() {
        return this.cardNumber
      },
      set(newVal) {
        if (this.cardNumberModifiers.digitsOnly)
          newVal = newVal.replace(/\D/, '')
        if (this.cardNumberModifiers.separate4Digits)
          newVal = newVal.replace(/(\d{4})\d/, '$1 ')
        this.$emit('update:password', newVal)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
