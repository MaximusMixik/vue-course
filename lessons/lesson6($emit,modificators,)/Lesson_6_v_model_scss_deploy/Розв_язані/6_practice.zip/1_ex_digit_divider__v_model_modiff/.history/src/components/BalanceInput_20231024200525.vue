<template>
  <div>
    <label>
      Баланс рахунку:
      <input type="text" v-model="currentBalanceValue" />
    </label>
  </div>
</template>

<script>
export default {
  name: 'BalanceInput',

  props: {
    modelValue: {
      type: String,
    },
  },

  computed: {
    currentBalanceValue: {
      get() {
        return this.modelValue
      },
      set(val) {
        this.$emit('update:modelValue', val)
      },
    },
  },
}
</script>

<style lang="scss" scoped></style>
