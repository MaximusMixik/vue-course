<template>
  <div>
    <label>
      Баланс рахунку:
      <input type="text" v-model="currentBalanceValue" />
    </label>
  </div>
</template>

<script>
import { getFormattedNumber } from '../utils/formats'
export default {
  name: 'BalanceInput',

  props: {
    modelValue: {
      type: String,
    },
    modelModifiers: {
      default: () => ({}),
    },
  },

  computed: {
    currentBalanceValue: {
      get() {
        return this.modelValue
      },
      set(val) {
        val.replace(/\D/g, '')
        this.$emit('update:modelValue', getFormattedNumber(val))
      },
    },
  },
}
</script>

<style lang="scss" scoped></style>
