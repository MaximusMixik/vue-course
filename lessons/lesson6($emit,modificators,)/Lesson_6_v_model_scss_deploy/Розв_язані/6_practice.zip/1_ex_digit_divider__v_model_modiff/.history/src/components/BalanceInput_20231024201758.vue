<template>
  <div>
    <label>
      Баланс рахунку:
      <input type="text" v-model="currentBalanceValue" />
    </label>
  </div>
</template>

<script>
import { getFormattedNumber } from '../utils/formats'
export default {
  name: 'BalanceInput',

  props: {
    modelValue: {
      type: String,
    },
    modelModifiers: {
      default: () => ({}),
    },
  },

  computed: {
    currentBalanceValue: {
      get() {
        if (this.modelModifiers.divideDigits)
          return getFormattedNumber(this.modelValue)
        else return this.modelValue
      },
      set(val) {
        if (this.modelModifiers.divideDigits) {
          val = val.replace(/\D/g, '')
        }
        this.$emit('update:modelValue', val)
      },
    },
  },
}
</script>

<style lang="scss" scoped></style>
