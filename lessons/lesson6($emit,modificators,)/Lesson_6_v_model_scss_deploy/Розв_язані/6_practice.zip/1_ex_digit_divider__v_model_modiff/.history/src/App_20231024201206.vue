<template>
  <balance-input v-model:divideDigits="balance" />
  <div>Balance: {{ balance }}</div>
</template>

<script>
import BalanceInput from './components/BalanceInput.vue'

export default {
  name: 'App',

  components: {
    BalanceInput,
  },

  data() {
    return {
      balance: 0,
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
