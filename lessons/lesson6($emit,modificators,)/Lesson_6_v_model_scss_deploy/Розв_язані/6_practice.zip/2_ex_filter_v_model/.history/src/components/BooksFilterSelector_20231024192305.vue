<template>
  <div>
    <label>
      Назва
      <input type="text" v-model="bookTitleValue" />
    </label>
  </div>
  <div>
    <label>
      Рік
      <input type="text" v-model="yearValue" />
    </label>
  </div>
</template>

<script>
export default {
  name: 'BooksFilterSelector',

  props: {
    title: {
      type: String,
    },
    year: {
      type: String,
    },
  },

  computed: {
    bookTitleValue: {
      get() {
        return this.title
      },
      set(val) {
        this.$emit('update:title', val)
      },
    },
    yearValue: {
      get() {
        this.year
      },
      set(val) {
        this.$emit('update:year', val)
      },
    },
  },
}
</script>

<style lang="scss" scoped></style>
