<template>
  <div>
    <h1>Список книг</h1>
    <h2 v-if="isEmpty">Список порожній</h2>
  </div>
</template>

<script>
export default {
  name: 'BooksList',

  props: {
    booksList: {
      type: Array,
      default: () => [],
    },
  },

  computed: {
    isEmpty() {
      return this.booksList.length === 0
    },
  },
}
</script>

<style lang="scss" scoped></style>
