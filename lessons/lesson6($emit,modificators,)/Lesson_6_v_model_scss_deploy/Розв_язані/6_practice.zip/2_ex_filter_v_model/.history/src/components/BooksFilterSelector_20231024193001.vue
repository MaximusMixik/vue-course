<template>
  <h1>Фільтри</h1>
  <div>
    <label>
      Назва
      <input type="text" v-model="bookTitleValue" />
    </label>
  </div>
  <div>
    <label>
      Рік
      <input type="text" v-model="yearValue" />
    </label>
  </div>
  <div>
    <label>
      Автор
      <input type="text" v-model="authorValue" />
    </label>
  </div>
</template>

<script>
export default {
  name: 'BooksFilterSelector',

  props: {
    title: {
      type: String,
    },
    year: {
      type: String,
    },
    author: {
      type: String,
    },
  },

  computed: {
    bookTitleValue: {
      get() {
        return this.title
      },
      set(val) {
        this.$emit('update:title', val)
      },
    },
    yearValue: {
      get() {
        return this.year
      },
      set(val) {
        this.$emit('update:year', val)
      },
    },
    authorValue: {
      get() {
        return this.author
      },
      set(newAuthor) {
        this.$emit('update:author', newAuthor)
      },
    },
  },
}
</script>

<style lang="scss" scoped></style>
