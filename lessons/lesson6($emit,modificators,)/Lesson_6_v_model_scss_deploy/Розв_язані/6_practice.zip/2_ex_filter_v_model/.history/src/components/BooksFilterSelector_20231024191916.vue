<template>
  <div>
    <label>
      Назва
      <input type="text" v-model="bookTitleValue" />
    </label>
  </div>
</template>

<script>
export default {
  name: 'BooksFilterSelector',

  props: {
    title: {
      type: String,
    },
  },

  computed: {
    bookTitleValue: {
      get() {},
      set(val) {},
    },
  },
}
</script>

<style lang="scss" scoped></style>
