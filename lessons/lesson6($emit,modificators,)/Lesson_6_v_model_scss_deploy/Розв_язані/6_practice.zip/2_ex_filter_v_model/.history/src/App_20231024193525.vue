<template>
  <books-filter-selector
    v-model:title="bookTitle"
    v-model:year="bookYear"
    v-model:author="bookAuthor"
  />

  <books-list :books-list="books" />
</template>

<script>
import BooksList from './components/BooksList.vue'
import BooksFilterSelector from './components/BooksFilterSelector.vue'

import { books } from './constants/data'
export default {
  name: 'App',

  components: { BooksList, BooksFilterSelector },

  data() {
    return {
      books,
      bookTitle: null,
      bookYear: null,
      bookAuthor: null,
    }
  },

  computed: {
    filteredBooksList() {
      if (this.bookTitle || this.bookYear || this.bookAuthor) {
        return books.filter((book) => this.isBookAccepted(book))
      }
      return books
    },
  },

  methods: {
    isBookAccepted(book) {
      return (
        (!this.bookTitle || book.title === this.bookTitle) &&
        (!this.bookYear || this.bookYear === book.year) &&
        (!this.bookAuthor || this.bookAuthor === this.bookAuthor)
      )
    },
  },
}
</script>

<style></style>
