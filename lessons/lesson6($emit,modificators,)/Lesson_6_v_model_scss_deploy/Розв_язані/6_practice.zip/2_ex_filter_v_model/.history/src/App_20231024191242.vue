<template>
  <books-list :books-list="books" />
</template>

<script>
import BooksList from './components/BooksList.vue'
import { books } from './constants/data'
export default {
  name: 'App',

  components: { BooksList },

  data() {
    return {
      books,
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
