<template>
  <div>
    <h1>Список книг</h1>
    <h2 v-if="isEmpty">Список порожній</h2>
  </div>
</template>

<script>
export default {
  name: 'BooksList',

  props: {
    booksList: {
      type: Array,
      default: () => [],
    },
  },

  computed: {
    isEmpty() {
      if (this.booksList.length === 0) return true
      else return false
    },
  },
}
</script>

<style lang="scss" scoped></style>
