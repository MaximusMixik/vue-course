<template>
  <books-list :books-list="books" />
</template>

<script>
import BooksList from './components/BooksList.vue'
import { books } from './constants/data'
export default {
  name: 'App',

  components: { BooksList },

  data() {
    return {
      books,
    }
  },
}
</script>

<style></style>
