<template>
  <books-list :books-list="books" />
  <books-filter-selector
    v-model:title="bookTitle"
    v-model:year="bookYear"
    v-model:author="bookAuthor"
  />

  <div>{{ bookTitle }} -- {{ bookYear }} --- {{ bookAuthor }}</div>
</template>

<script>
import BooksList from './components/BooksList.vue'
import BooksFilterSelector from './components/BooksFilterSelector.vue'

import { books } from './constants/data'
export default {
  name: 'App',

  components: { BooksList, BooksFilterSelector },

  data() {
    return {
      books,
      bookTitle: null,
      bookYear: null,
      bookAuthor: null,
    }
  },
}
</script>

<style></style>
