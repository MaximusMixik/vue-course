<template>
  <label>
    Login
    <input type="text" v-model="loginValue" />
  </label>
  <label>
    Card number
    <input ref="cardValue" type="text" :key="updateKey" v-model="cardValue" />
  </label>
</template>
<script>
export default {
  name: 'LoginForm',
  props: {
    login: { type: String },
    loginModifiers: { default: () => ({}) },
    cardNumber: { type: String },
    cardNumberModifiers: { default: () => ({}) },
  },
  data() {
    return {
      updateKey: 0,
    }
  },
  computed: {
    loginValue: {
      get() {
        return this.login
      },
      set(newVal) {
        if (this.loginModifiers.uppercase) newVal = newVal.toUpperCase()
        this.$emit('update:login', newVal)
      },
    },
    cardValue: {
      get() {
        return this.cardNumber
      },
      set(newVal) {
        console.log(this.cardNumberModifiers)
        if (this.cardNumberModifiers.digitsOnly) {
          newVal = newVal.replace(/\D/g, '')
          this.$nextTick(() => {
            this.updateKey++
            //   this.$nextTick(() => {
            //     this.$refs.cardValue.focus()
            //   })
          })
        }
        console.log('newVal 1')
        console.log(newVal)
        if (this.cardNumberModifiers.separate4Digits) {
          newVal = newVal.replace(/(\d{4}(?=.+))/g, '$1 ')
          console.log('newVal 2')

          console.log(newVal)
        }
        this.$emit('update:cardNumber', newVal)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
