<template>
  <label>
    {{ title }}
    <input type="text" v-model="currentValue" />
  </label>
</template>

<script>
export default {
  name: 'CustomInput',

  props: {
    title: {
      type: String,
      default: '',
    },
    modelValue: {
      type: String,
    },
  },

  computed: {
    currentValue: {
      get() {
        return this.modelValue
      },
      set(newVal) {
        this.$emit('update:modelValue', newVal)
      },
    },
  },
}
</script>

<style lang="css" scoped></style>
