<template>
    <div>
        <ul>
            <li v-for="bus in getBusesList" :key="bus.id">
                {{ bus.number }}
            </li>
        </ul>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'BussesView',

    computed: {
        ...mapGetters('buses', ['getBusesList']),
    },
}
</script>

<style lang="scss" scoped></style>
