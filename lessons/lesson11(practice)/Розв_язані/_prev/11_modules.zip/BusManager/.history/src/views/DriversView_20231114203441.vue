<template>
    <div class="home">
        <ul>
            <li v-for="driver in getDriversList" :key="driver.id">{{ driver.name }} - {{ driver.exp }}</li>
        </ul>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'DriversView',

    computed: {
        ...mapGetters('drivers', ['getDriversList']),
    },

    methods: {},
}
</script>
