import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        busesList: [
            {
                id: 1,
                number: 'AO2312HA',
            },
            {
                id: 2,
                number: 'AO237HA',
            },
        ],
    },
    getters: {
        getBusesList: (state) => state.busesList,
    },
    mutations: {},
    actions: {},
    modules: {},
})
