import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        assignmentsList: [
            {
                id: 1,
                driverId: 2,
                busId: 1,
            },
            {
                id: 2,
                driverId: 1,
                busId: 2,
            },
        ],
    },
    getters: {},
    mutations: {},
    actions: {},
    modules: {},
})
