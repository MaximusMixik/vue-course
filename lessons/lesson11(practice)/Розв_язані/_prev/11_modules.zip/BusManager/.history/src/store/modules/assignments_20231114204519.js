export default {
    namespaced: true,
    state: {
        assignmentsList: [
            {
                id: 1,
                driverId: 2,
                busId: 1,
            },
            {
                id: 2,
                driverId: 1,
                busId: 2,
            },
        ],
    },
    getters: {
        getAssignmentsList: (state) => state.assignmentsList,
    },
    mutations: {},
    actions: {},
    modules: {},
}
