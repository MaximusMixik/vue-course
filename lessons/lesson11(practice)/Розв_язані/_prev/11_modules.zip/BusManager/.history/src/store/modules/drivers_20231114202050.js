import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        driversList: [
            {
                id: 1,
                name: 'Ivan',
                exp: 12,
            },
            {
                id: 2,
                name: 'Petro',
                exp: 23,
            },
        ],
    },
    getters: {
        getDriversList: (state) => state.driversList,
    },
    mutations: {},
    actions: {},
    modules: {},
})
