<template>
    <div>My contacts</div>
</template>
<script>
export default {
    name: 'MyContacts',
}
</script>
<style lang="scss" scoped></style>
