<template>
    <div>
        {{ getFilteredCompaniesList }}
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'CompaniesList',
    computed: {
        ...mapGetters(['getFilteredCompaniesList']),
    },
}
</script>

<style lang="scss" scoped></style>
