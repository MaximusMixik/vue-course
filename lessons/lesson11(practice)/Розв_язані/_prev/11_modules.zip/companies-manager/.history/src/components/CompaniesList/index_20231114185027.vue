<template>
    <div>
        <company-item />
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import CompanyItem from './CompanyItem.vue'

export default {
    name: 'CompaniesList',

    components: {
        CompanyItem,
    },

    computed: {
        ...mapGetters(['getFilteredCompaniesList']),
    },
}
</script>

<style lang="scss" scoped></style>
