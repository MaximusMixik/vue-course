<template>
    <div class="company-container">
        <div>{{ company.title }}</div>
        <div>{{ company.taxRate }}</div>
        <div>{{ company.year }}</div>
        <div>{{ company.owner }}</div>
        <button>Edit</button>
        <button @click="removeCompany(company.id)">Delete</button>
    </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'CompanyItem',

    props: {
        company: {
            type: Object,
            required: true,
        },
    },

    methods: {
        ...mapActions(['removeCompany']),
    },
}
</script>

<style lang="scss" scoped>
.company-container {
    display: flex;
    width: 500px;
    justify-content: space-between;
}
</style>
