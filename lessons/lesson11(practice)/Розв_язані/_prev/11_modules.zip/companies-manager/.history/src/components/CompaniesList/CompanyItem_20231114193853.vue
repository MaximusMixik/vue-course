<template>
    <div class="company-container">
        <div>{{ company.title }}</div>
        <div>{{ company.taxRate }}</div>
        <div>{{ company.year }}</div>
        <div>{{ company.owner }}</div>
        <button @click="onEdit">Edit</button>
        <button @click="removeCompany(company.id)">Delete</button>
    </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'CompanyItem',

    props: {
        company: {
            type: Object,
            required: true,
        },
    },

    methods: {
        ...mapActions(['removeCompany']),
        onEdit() {
            this.$router.push({
                name: 'company',
                params: {
                    companyId: this.company.id,
                },
            })
        },
    },
}
</script>

<style lang="scss" scoped>
.company-container {
    display: flex;
    width: 500px;
    justify-content: space-between;
    & > div {
        width: 100px;
    }
}
</style>
