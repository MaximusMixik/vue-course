<template>
    <div>
        <companies-filter />
        <companies-list />
    </div>
</template>

<script>
import CompaniesFilter from './CompaniesFilter.vue'
import CompaniesList from './CompaniesList'

export default {
    name: 'CompaniesManager',
    components: { CompaniesFilter, CompaniesList },
}
</script>

<style lang="scss" scoped></style>
