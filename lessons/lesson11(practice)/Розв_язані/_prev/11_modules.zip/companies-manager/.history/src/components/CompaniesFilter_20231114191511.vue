<template>
    <div>
        <h1>Filter</h1>
        <div>
            <label>
                Title
                <input v-model="filterObj.title" type="text" />
            </label>
            <label>
                Tax rate
                <input v-model="filterObj.taxRate" type="text" />
            </label>
            <label>
                Year
                <input v-model="filterObj.year" type="text" />
            </label>
            <label>
                Owner
                <input v-model="filterObj.owner" type="text" />
            </label>
            <button @click="filterObj = {}">Reset</button>
        </div>
    </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'CompaniesFilter',

    data() {
        return {
            filterObj: {},
        }
    },

    watch: {
        filterObj: {
            handler(newValue) {
                this.updateFilter(newValue)
            },
            deep: true,
        },
    },

    methods: {
        ...mapActions(['updateFilter']),
    },
}
</script>

<style lang="scss" scoped></style>
