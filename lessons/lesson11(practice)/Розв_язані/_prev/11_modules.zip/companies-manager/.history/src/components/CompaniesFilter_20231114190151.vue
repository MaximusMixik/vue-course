<template>
    <div>
        <h1>Filter</h1>
        <div>
            <label>
                Title
                <input v-model="filterObj.title" type="text" />
            </label>
        </div>
    </div>
</template>

<script>
export default {
    name: 'CompaniesFilter',

    data() {
        return {
            filterObj: {},
        }
    },
}
</script>

<style lang="scss" scoped></style>
