import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        companiesList: [
            {
                id: 1,
                title: 'Com1',
                taxRate: 5,
                owner: 'Ivan',
            },
            {
                id: 2,
                title: 'Com2',
                taxRate: 15,
                owner: 'Olga',
            },
        ],
        filterObj: {},
    },
    getters: {
        getCompaniesList: (state) => state.companiesList,
        getFilterObj: (state) => state.filterObj,
        getCompanyById: (state) => (companyId) => state.companiesList.find((company) => company.id == companyId),
    },
    mutations: {},
    actions: {},
    modules: {},
})

// State:
//    companiesList : [ ]
//    filterObj: {}
// Getters:
//     getCompaniesList
//     getFilterObj
//     getCompanyById(companyId)
// Actions:
//    removeCompany(companyId)
//    updateFilter(filterData)
//    addCompany(company)
//    updateCompany(company)
