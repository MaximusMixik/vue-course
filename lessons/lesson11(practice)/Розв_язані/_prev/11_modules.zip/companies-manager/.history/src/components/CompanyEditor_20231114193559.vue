<template>
    <div>
        <label>
            Title
            <input v-model.lazy="company.title" type="text" />
        </label>
        <label>
            Tax rate
            <input v-model.lazy="company.taxRate" type="number" />
        </label>
        <label>
            Year
            <input v-model.lazy="company.year" type="number" />
        </label>
        <label>
            Owner
            <input v-model.lazy="company.owner" type="text" />
        </label>
        <button @click="onAction">
            {{ actionButtonTitle }}
        </button>
    </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'CompanyEditor',

    data() {
        return {
            company: {},
        }
    },

    computed: {
        receivedCompanyId() {
            return this.$route.params.companyId
        },
        actionButtonTitle() {
            return this.receivedCompanyId ? 'Save' : 'Create'
        },
    },

    methods: {
        ...mapActions(['addCompany']),
        onAction() {
            if(!this.receivedCompanyId)
            this.addCompany(this.company)

            this.$router.push(){
                name:'home'
            }

        }
    },
}
</script>

<style lang="scss" scoped></style>
