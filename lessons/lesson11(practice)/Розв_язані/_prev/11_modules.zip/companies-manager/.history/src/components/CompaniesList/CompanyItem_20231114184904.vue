<template>
    <div>
        <div>{{ company.title }}</div>
        <div>{{ company.taxRate }}</div>
        <div>{{ company.year }}</div>
        <div>{{ company.owner }}</div>
        <button>Edit</button>
        <button>Delete</button>
    </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'CompanyItem',

    props: {
        company: {
            type: Object,
            required: true,
        },
    },

    methods: {
        ...mapActions(['removeCompany']),
    },
}
</script>

<style lang="scss" scoped></style>
