<template>
    <div>
        <label>
            Title
            <input v-model.lazy="filterObj.title" type="text" />
        </label>
        <label>
            Tax rate
            <input v-model.lazy="filterObj.taxRate" type="number" />
        </label>
        <label>
            Year
            <input v-model.lazy="filterObj.year" type="number" />
        </label>
        <label>
            Owner
            <input v-model.lazy="filterObj.owner" type="text" />
        </label>
        <button @click="onReset">Reset</button>
    </div>
</template>

<script>
export default {
    name: 'CompanyEditor',
}
</script>

<style lang="scss" scoped></style>
