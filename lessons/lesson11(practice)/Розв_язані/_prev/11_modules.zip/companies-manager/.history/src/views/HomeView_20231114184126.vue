<template>
    <div class="home">
        <companies-list />
    </div>
</template>

<script>
import CompaniesList from '@/components/CompaniesList'
export default {
    name: 'HomeView',
    components: {
        CompaniesList,
    },

    methods: {},
}
</script>
