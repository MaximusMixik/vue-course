<template>
    <div>
        <h1>Filter</h1>
        <div>
            <label>
                Title
                <input type="text" v-model="filterObj.title" />
            </label>
        </div>
    </div>
</template>

<script>
export default {
    name: 'CompaniesFilter',

    data() {
        return {
            filterObj: {},
        }
    },
}
</script>

<style lang="scss" scoped></style>
