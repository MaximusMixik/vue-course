<template>
    <h1>Companies list</h1>
    <div>
        <company-item v-for="company in getFilteredCompaniesList" :key="company.id" :company="company" />
    </div>
    <!-- <button @click="onCreate">Create</button> -->
    <router-link :to="{ name: 'company' }"> Create </router-link>
</template>

<script>
import { mapGetters } from 'vuex'
import CompanyItem from './CompanyItem.vue'

export default {
    name: 'CompaniesList',

    components: {
        CompanyItem,
    },

    computed: {
        ...mapGetters(['getFilteredCompaniesList']),
    },

    methods: {
        onCreate() {
            this.$router.push({
                name: 'company',
            })
        },
    },
}
</script>

<style lang="scss" scoped></style>
