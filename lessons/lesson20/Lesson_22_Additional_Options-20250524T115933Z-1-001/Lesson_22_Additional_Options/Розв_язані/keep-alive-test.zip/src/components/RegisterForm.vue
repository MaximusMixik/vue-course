<template>
  <div>
    <div>
      <label>
        Name
        <input v-model="user.name" type="text" />
      </label>
    </div>
    <div>
      <label>
        Age
        <input v-model="user.age" type="text" />
      </label>
    </div>
    <div>
      <label>
        Address
        <input v-model="user.address" type="text" />
      </label>
    </div>
  </div>
  <div>
    <button>Зареєстувати</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const user = ref({})
</script>

<style lang="scss" scoped></style>
