<template>
  <div>
    <h1>Вітаємо на сайті конференції!</h1>
    <h2>Для участі необхідно надіслати заявку</h2>
    <div>
      <label>
        Використати дані поточного користувача
        <input v-model="isRegisted" type="checkbox" />
      </label>
    </div>
    <keep-alive>
      <div v-if="isRegisted">
        <button>Надіслати заявку</button>
      </div>
      <register-form v-else />
    </keep-alive>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import RegisterForm from '@/components/RegisterForm.vue'
const isRegisted = ref(true)
</script>

<style lang="scss" scoped></style>
