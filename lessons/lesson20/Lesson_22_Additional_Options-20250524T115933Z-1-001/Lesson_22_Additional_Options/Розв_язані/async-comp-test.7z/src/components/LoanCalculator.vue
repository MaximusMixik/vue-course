<template>
  <div>
    <h2>Calculator. Кредитна програма: {{ loanProgram.title }}</h2>
    <div>
      <label
        >Потрібна сума:
        <input v-model="loanAmount" type="number" id="loanAmount" />
      </label>
    </div>
    <div>Загальна сума кредиту: {{ totalRepayment }}</div>
    <div>Переплата: {{ interestAmount }}</div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useLoanProgramsStore } from '@/stores/loanPrograms.js'

const props = defineProps({
  creditProgramId: {
    type: Object,
    required: true
  }
})

// const { getProgramById } = storeToRefs(useLoanProgramsStore())
const { getProgramById } = useLoanProgramsStore()
console.log('getProgramById')
console.log(getProgramById(1))
const loanProgram = computed(() => getProgramById(props.creditProgramId))

const loanAmount = ref(0)

const totalRepayment = computed(() => {
  return loanAmount.value + (loanAmount.value * loanProgram.value.percentage) / 100
})

const interestAmount = computed(() => {
  return totalRepayment.value - loanAmount.value
})
</script>

<style scoped>
/* Add your component styles here */
</style>
