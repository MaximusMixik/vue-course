<template>
  <div>
    <h1>Ми допоможемо Вам вирішити ваші задачі</h1>
    <div>
      Ваша кредитна програма
      <select v-model="selectedLoanProgram">
        <option value="">Виберіть кредитну програму</option>
        <option v-for="program in loanPrograms" :key="program.id" :value="program">
          {{ program.title }}
        </option>
      </select>
    </div>
    <div>
      <button
        v-if="!isCalcVisible"
        :disabled="!selectedLoanProgram"
        @click="isCalcVisible = !isCalcVisible"
      >
        Кредитний калькулятор
      </button>
      <async-loan-calculator v-else :credit-program-id="selectedLoanProgram.id" />
    </div>
  </div>
</template>

<script setup>
import { ref, defineAsyncComponent } from 'vue'
import { storeToRefs } from 'pinia'

import { useLoanProgramsStore } from '@/stores/loanPrograms'
const { loanPrograms } = storeToRefs(useLoanProgramsStore())

const selectedLoanProgram = ref('')

const AsyncLoanCalculator = defineAsyncComponent(() => import('@/components/LoanCalculator.vue'))

const isCalcVisible = ref(false)
</script>

<style lang="scss" scoped></style>
