<script setup></script>

<template>
  <main>Home</main>
</template>
