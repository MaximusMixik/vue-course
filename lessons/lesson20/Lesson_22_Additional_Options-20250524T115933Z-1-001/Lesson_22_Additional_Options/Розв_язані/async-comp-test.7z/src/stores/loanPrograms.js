import { computed, ref } from 'vue'
import { defineStore } from 'pinia'

export const useLoanProgramsStore = defineStore('counter', () => {
  const loanPrograms = ref([
    {
      id: 1,
      title: 'Легка',
      percentage: 10,
      description: 'Зручна для купівлі товарів'
    },
    {
      id: 2,
      title: 'Розумна',
      percentage: 5,
      description: 'Зручна для великих капіталовкладень'
    },
    {
      id: 3,
      title: 'Відпочинок',
      percentage: 7,
      description: 'Можна виплачувати через 2 місяці'
    }
  ])
  const getProgramById = computed(
    () => (programId) => loanPrograms.value.find((program) => program.id === programId)
  )

  return { loanPrograms, getProgramById }
})
