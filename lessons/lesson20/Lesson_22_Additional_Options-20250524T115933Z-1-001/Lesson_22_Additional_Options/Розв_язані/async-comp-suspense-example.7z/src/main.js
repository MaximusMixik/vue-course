import './assets/main.css'

import { createApp } from 'vue'
import App from './App _4Comps_WithSuspense.vue'

createApp(App).mount('#app')
