<template>
  <div>
    <h1>Test</h1>
    <RandomDog />
  </div>
</template>

<script setup>
import { defineAsyncComponent, defineComponent } from 'vue'

const RandomDog = defineAsyncComponent(() => {
  return new Promise((resolve, reject) => {
    fetch('https://dog.ceo/api/breeds/image/random')
      .then((response) => response.json())
      .then((resData) => {
        resolve(
          defineComponent({
            data() {
              return { resData }
            },
            template: `
          <div>
            <h2>{{resData.message.split('/')[4]}}</h2>
            <img :src="resData.message" height="100" alt="A random dog" />
          </div>
        `
          })
        )
      })
      .catch((err) => {
        reject(err)
      })
  })
})
</script>
