<template>
  <h1>Найбільш популярнs породи сьогодні</h1>
  <RandomDog />
  <RandomDog />
</template>
<script setup>
import { defineAsyncComponent, defineComponent } from 'vue'
import LoadingComp from './components/LoadingComp.vue'
const RandomDog = defineAsyncComponent({
  loader: () =>
    new Promise((resolve, reject) => {
      fetch('https://dog.ceo/api/breeds/image/random')
        .then((response) => response.json())
        .then((resData) => {
          resolve(
            defineComponent({
              data() {
                return { resData }
              },
              template: `
          <div>
            <h2>{{resData.message.split('/')[4]}}</h2>
            <img :src="resData.message" height="100" alt="A random dog" />
          </div>
        `
            })
          )
        })
        .catch((err) => {
          reject(err)
        })
    }),
  delay: 200,
  loadingComponent: LoadingComp
})
</script>
