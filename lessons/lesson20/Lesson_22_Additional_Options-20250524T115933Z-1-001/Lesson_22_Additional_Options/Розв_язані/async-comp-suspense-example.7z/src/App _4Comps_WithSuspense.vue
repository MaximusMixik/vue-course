<template>
  <div>
    <h1>Test</h1>
    <suspense>
      <div>
        <RandomDog />
        <CurrentCurrencyRates />
      </div>
      <template #fallback>
        <loading-comp />
      </template>
    </suspense>
  </div>
</template>

<script setup>
import { defineAsyncComponent, defineComponent } from 'vue'
import LoadingComp from './components/LoadingComp.vue'

const RandomDog = defineAsyncComponent(() => {
  return new Promise((resolve, reject) => {
    fetch('https://dog.ceo/api/breeds/image/random')
      .then((response) => response.json())
      .then((resData) => {
        resolve(
          defineComponent({
            data() {
              return { resData }
            },
            template: `
          <div>
            <h2>{{resData.message.split('/')[4]}}</h2>
            <img :src="resData.message" height="100" alt="A random dog" />
          </div>
        `
          })
        )
      })
      .catch((err) => {
        reject(err)
      })
  })
})

const CurrentCurrencyRates = defineAsyncComponent(() => {
  return new Promise((resolve, reject) => {
    return fetch('https://api.exchangerate-api.com/v4/latest/USD')
      .then((response) => response.json())
      .then((resData) => {
        console.log(resData)
        resolve(
          defineComponent({
            data() {
              return { resData }
            },
            template: `
          <div>
            <h2>Current Currency Rates</h2>
            <table>
              <thead>
                <tr>
                  <th>Currency</th>
                  <th>Rate</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(rate, currency) in resData.rates" :key="currency">
                  <td>{{ currency }}</td>
                  <td>{{ rate }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        `
          })
        )
      })
      .catch((err) => {
        reject(err)
      })
  })
})
</script>
