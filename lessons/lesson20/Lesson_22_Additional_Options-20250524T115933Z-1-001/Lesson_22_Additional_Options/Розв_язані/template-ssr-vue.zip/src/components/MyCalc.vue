<template>
  <div>
    <div>
      Num1
      <input v-model="num1" type="number" />
    </div>
    <div>
      Num2
      <input v-model="num2" type="number" />
    </div>
    <div>{{ num1 + num2 }}</div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const num1 = ref(0)
const num2 = ref(0)
</script>

<style lang="scss" scoped></style>
