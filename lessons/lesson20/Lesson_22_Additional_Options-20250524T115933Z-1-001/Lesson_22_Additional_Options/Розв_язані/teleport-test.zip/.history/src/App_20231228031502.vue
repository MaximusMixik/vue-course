<script setup>
import CompWithModal from './components/CompWithModal.vue'
</script>

<template>
  <comp-with-modal />
</template>

<style scoped></style>
