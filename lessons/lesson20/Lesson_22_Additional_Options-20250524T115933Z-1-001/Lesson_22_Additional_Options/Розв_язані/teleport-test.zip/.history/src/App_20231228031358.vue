<script setup>
import TheWelcome from './components/CompWithModal.vue'
</script>

<template>

</template>

<style scoped>

</style>
