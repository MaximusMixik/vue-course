<script setup>
import CompWithModal from './components/CompWithModal.vue'
</script>

<template>
  <div class="header">
    <comp-with-modal />
  </div>
  <div>
    <ul>
      <li>Доставка піци</li>
      <li>Експрес-доставка суші</li>
      <li>Доставка бургерів та фрі</li>
      <li>Доставка італійської кухні</li>
      <li>Доставка вегетаріанських страв</li>
      <li>Доставка мексиканських та тайських страв</li>
      <li>Доставка десертів та кави</li>
      <li>Здорова їжа з доставкою</li>
      <li>Доставка свіжих салатів</li>
      <li>Гуртова доставка на події та заходи</li>
    </ul>
  </div>
</template>

<style scoped>
.header {
  height: 70px;
  overflow: hidden;
  position: relative;
}
</style>
