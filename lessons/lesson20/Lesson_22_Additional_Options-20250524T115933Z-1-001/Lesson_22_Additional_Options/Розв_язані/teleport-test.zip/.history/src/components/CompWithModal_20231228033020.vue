<template>
  <div>
    <h2>Вітаємо! Тут ви можете замовити послуги.</h2>
    <button @click="showModal = true">Додаткова інформація</button>
    <div v-if="showModal" class="modal">
      <h2>Важливо!!!</h2>
      <p>Швидко оплачуємо послуги.</p>
      <p>Отримуємо якісні послуги.</p>
      <p>Насолоджуємось життям.</p>
      <p>Успіхів!</p>
      <button @click="showModal = false">Закрити</button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const showModal = ref(false)
</script>

<style>
.modal {
  /* position: fixed; */
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: white;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  color: black;
}
</style>
