<script setup>
import CompWithModal from './components/CompWithModal.vue'
</script>

<template>
  <div>
    <comp-with-modal />
  </div>
  <div>
    <ul>
      <li>1. Доставка піци</li>
      <li>2. Експрес-доставка суші</li>
      <li>3. Доставка бургерів та фрі</li>
      <li>4. Доставка італійської кухні</li>
      <li>5. Доставка вегетаріанських страв</li>
      <li>6. Доставка мексиканських та тайських страв</li>
      <li>7. Доставка десертів та кави</li>
      <li>8. Здорова їжа з доставкою</li>
      <li>9. Доставка свіжих салатів</li>
      <li>10. Гуртова доставка на події та заходи</li>
    </ul>
  </div>
</template>

<style scoped></style>
