<script setup>
const vEllipses = {
  mounted: (el, binding) => {
    const contentStr = el.innerText
    let charsNumber = parseInt(binding.arg)
    if (el.innerText.length > charsNumber) {
      if (binding.modifiers['keep-word']) {
        const spaceOrPunctuation = /[\s\.,;:!?'"]/
        const position = contentStr.slice(charsNumber).search(spaceOrPunctuation)
        charsNumber = charsNumber + position
      }

      el.innerText = el.innerText.substring(0, charsNumber) + '...'
    }
  }
}
</script>

<template>
  <div>
    <h3>Використано 10 символів</h3>
    <div v-ellipses:10>Hello my dear friends! Welcome to my site.</div>
    <h3>Використано 15 символів</h3>
    <div v-ellipses:15.keep-word>Hello my dear friends! Welcome to my site.</div>

    <h3>Використано 10 символів (слова не перериваємо)</h3>
    <div v-ellipses:10.keep-word>Hello my dear friends! Welcome to my site.</div>

    <h3>Використано 10 символів</h3>
    <div v-ellipses:10="'___'">Hello my dear friends! Welcome to my site.</div>

    <h3>Використано 50 символів</h3>
    <div v-ellipses:50>Hello my dear friends! Welcome to my site.</div>
  </div>
</template>

<style scoped></style>
