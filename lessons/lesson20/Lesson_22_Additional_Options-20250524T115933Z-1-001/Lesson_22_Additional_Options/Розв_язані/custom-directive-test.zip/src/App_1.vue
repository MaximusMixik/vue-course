<script setup>
import { ref } from 'vue'

const vEllipses = {
  mounted: (el, binding) => {
    if (el.innerText.length > binding.arg)
      el.innerText = el.innerText.substring(0, binding.arg) + '...'
  }
}
const isInpVisible = ref(true)

const vSave = {
  mounted: (el, binding) => {
    if (localStorage.getItem(binding.arg)) el.value = localStorage.getItem(binding.arg)
  },
  beforeUnmount: (el, binding) => {
    localStorage.setItem(binding.arg, el.value)
  }
}
</script>

<template>
  <div>
    <div v-if="isInpVisible">
      Info
      <input v-save:superData type="text" />
    </div>
    <div v-if="isInpVisible">
      Info 2
      <input v-save:superData2 type="text" />
    </div>
    <button @click="isInpVisible = !isInpVisible">Switch input</button>
    <h3>Використано 10 символів</h3>
    <div v-ellipses:12>Hello my dear friends! Welcome to my side.</div>

    <h3>Використано 15 символів</h3>
    <div v-ellipses:15>Hello my dear friends! Welcome to my side.</div>

    <p v-ellipses:5>123456789</p>
  </div>
</template>

<style scoped></style>
