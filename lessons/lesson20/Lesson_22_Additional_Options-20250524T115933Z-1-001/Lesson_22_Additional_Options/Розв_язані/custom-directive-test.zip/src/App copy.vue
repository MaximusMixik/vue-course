<script setup>
const vEllipses = {
  mounted: (el, binding) => {
    const contentStr = el.innerText
    let charsNumber = parseInt(binding.arg)
    if (el.innerText.length > charsNumber) {
      if (binding.modifiers['keep-word']) {
        const spaceOrPunctuation = /[\s\.,;:!?'"]/
        const position = contentStr.slice(charsNumber).search(spaceOrPunctuation)
        charsNumber = charsNumber + position
      }

      el.innerText = el.innerText.substring(0, charsNumber) + (binding.value ?? '...')
    }
  }
}
</script>

<template>
  <div>
    <h3>Використано 15 символів</h3>
    <div v-ellipses:15>Hello my dear friends! Welcome to my site.</div>

    <h3>Використано 10 символів (слова не перериваємо)</h3>
    <div v-ellipses:10.keep-word>Hello my dear friends! Welcome to my site.</div>

    <h3>Використано 10 символів</h3>
    <div v-ellipses:10.keep-word="'___'">Hello my dear friends! Welcome to my site.</div>
  </div>
</template>

<style scoped></style>
