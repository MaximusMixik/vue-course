// cypress/e2e/specs/specialistsPage.cy.js
import SpecialistsPage from '../pageObjects/SpecialistsPage.js'
import LoginPage from '../pageObjects/LoginPage.js'
import AppointmentsPage from '../pageObjects/AppointmentsPage.js'

describe('Specialists Page', () => {
  // // 1) Перевірка чи відкривається сторінка при переході
  // it('should open Specialists Page successfully', () => {
  //   SpecialistsPage.visit()
  //   cy.url().should('eq', `${Cypress.config('baseUrl')}/specialists`)
  //   cy.get('.specialists-container').should('be.visible')
  // })

  // // 2) Переходимо без залогіненого користувача, кнопки запису мають бути неактивними
  // it('should disable appointment buttons and show empty list message when not logged in', () => {
  //   SpecialistsPage.visit()
  //   cy.setLang('en')

  //   // Перевірка, чи кнопка "Make an appointment" неактивна
  //   SpecialistsPage.specialistsList.then(($list) => {
  //     if ($list.find('button:contains("Make an appointment")').length > 0) {
  //       cy.wrap($list)
  //         .find('button')
  //         .contains('Make an appointment')
  //         .should('be.disabled')
  //     } else {
  //       // Якщо немає спеціалістів, перевіряємо повідомлення "Список порожній"

  //       SpecialistsPage.verifyEmptyListMessage('en')
  //     }
  //   })
  // })

  // // 3) Логінимось як звичайний користувач: немає кнопки додавання, але кнопки запису активні
  // it('should not show Add button, enable appointment buttons or show empty list for common user', () => {
  //   LoginPage.loginAs('commonUser')
  //   SpecialistsPage.visit()
  //   cy.setLang('en')

  //   // Перевірка відсутності кнопки "Add"
  //   SpecialistsPage.addButton.should('not.exist')

  //   // Перевірка стану кнопки "Make an appointment" або повідомлення про порожній список
  //   SpecialistsPage.specialistsList.then(($list) => {
  //     if ($list.find('button:contains("Make an appointment")').length > 0) {
  //       cy.wrap($list)
  //         .find('button')
  //         .contains('Make an appointment')
  //         .should('not.be.disabled')
  //     } else {
  //       SpecialistsPage.verifyEmptyListMessage('en')
  //     }
  //   })
  // })

  // // 4) Логінимось як адмін: активна кнопка додавання, активні кнопки редагування і запису
  // it('should show Add button, enable edit/appointment buttons or show empty list for admin', () => {
  //   LoginPage.loginAs('admin')
  //   SpecialistsPage.visit()
  //   cy.setLang('en')

  //   // Перевірка наявності та активності кнопки "Add"
  //   SpecialistsPage.addButton.should('be.visible').and('not.be.disabled')

  //   // Перевірка стану кнопок редагування/запису або повідомлення про порожній список
  //   SpecialistsPage.specialistsList.then(($list) => {
  //     if ($list.find('button:contains("Make an appointment")').length > 0) {
  //       cy.wrap($list).within(() => {
  //         cy.get('svg.fa-pen-to-square').should('be.visible') // Іконка редагування
  //         cy.get('button')
  //           .contains('Make an appointment')
  //           .should('not.be.disabled') // Кнопка запису
  //       })
  //     } else {
  //       SpecialistsPage.verifyEmptyListMessage('en')
  //     }
  //   })
  // })

  // 5) Логінимось як звичайний користувач, видаляємо записи, додаємо запис, перевіряємо Appointments Page
  it('should add appointment after clearing and verify non-empty list', () => {
    // Логін як звичайний користувач
    LoginPage.loginAs('commonUser')
    cy.setLang('en')

    // Переходимо на Appointments Page і видаляємо всі записи
    AppointmentsPage.visit()
    cy.wait(1000)
    cy.waitForLoader()

    cy.get('body').then(($body) => {
      if ($body.find('.appointments-list .container').length > 0) {
        // Якщо є записи, видаляємо їх усі
        cy.get('button.cancel-btn').each(($btn) => {
          cy.wrap($btn).click()
        })
      }
      // Перевіряємо повідомлення "Немає візитів", якщо список порожній
      AppointmentsPage.verifyEmptyListMessage('en')
    })

    // Переходимо на Specialists Page
    SpecialistsPage.visit()

    // Перевіряємо, чи є спеціалісти, і додаємо запис, або бачимо порожній список
    SpecialistsPage.specialistsList.then(($list) => {
      cy.log('====>>> $list.length')
      cy.log($list.length)
      // if ($list.find('button:contains("Make an appointment")').length > 0) {
      if ($list.length > 0) {
        cy.wrap($list)
          .first()
          .find('button')
          .contains('Make an appointment')
          .click()
      } else {
        SpecialistsPage.verifyEmptyListMessage('en')
        // Якщо список порожній, тест завершиться з повідомленням
        cy.log('No specialists available to make an appointment.')
      }
    })

    // Переходимо назад на Appointments Page
    AppointmentsPage.visit()
    // cy.wait(1000)
    cy.waitForLoader()

    // Перевіряємо, що список призначень не порожній (якщо був доданий запис)
    cy.get('body').then(($body) => {
      if ($body.find('.appointments-list .container').length > 0) {
        AppointmentsPage.appointmentsList.should('have.length.greaterThan', 0)
        AppointmentsPage.emptyListMessage.should('not.exist')
      } else {
        cy.setLang('en')
        AppointmentsPage.verifyEmptyListMessage('en')
      }
    })
  })
})
