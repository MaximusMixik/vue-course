class LoginPage {
  get emailField() {
    return cy.get('input[name="email"]')
  }

  get passwordField() {
    return cy.get('input[name="password"]')
  }

  get loginButton() {
    return cy.get('button').contains('Login')
  }

  get homeButton() {
    return cy.get('.home-link')
  }

  visit() {
    cy.visit('/login')
  }

  login(email, password) {
    this.emailField.type(email)
    this.passwordField.type(password)
    this.loginButton.click()
  }

  loginAs(userType) {
    cy.loginAs(userType)
  }

  verifyLoginButtonText(lang = 'ua') {
    const texts = {
      ua: 'Увійти',
      en: 'Login',
    }
    this.loginButton.should('have.text', texts[lang])
  }
}

export default new LoginPage()
