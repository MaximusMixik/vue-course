// cypress/e2e/specs/appointmentsPage.cy.js
import AppointmentsPage from '../pageObjects/AppointmentsPage.js'
import LoginPage from '../pageObjects/LoginPage.js'
import SpecialistsPage from '../pageObjects/SpecialistsPage.js'

describe('Appointments Page', () => {
  // 1) Перехід без авторизації: меню переходу на сторінку відсутнє
  it('should not show Appointments menu item when not logged in', () => {
    cy.visit('/') // Переходимо на головну сторінку
    cy.waitForLoader()
    cy.get('nav .menu-link')
      .contains('Візити') // Текст із i18n: pages.appointments.title.menu (ua)
      .should('not.exist')
  })

  // 2) Вхід як звичайний користувач, видалення всіх призначень, перевірка повідомлення
  it('should delete all appointments and show empty list message for common user', () => {
    LoginPage.loginAs('commonUser')
    AppointmentsPage.visit()
    cy.waitForLoader()
    cy.setLang('en')

    // Перевіряємо наявність призначень і видаляємо їх по одному
    cy.get('body').then(($body) => {
      const initialAppointments = $body.find(
        '.appointments-list .container'
      ).length
      if (initialAppointments > 0) {
        // Рекурсивно видаляємо всі призначення
        const deleteAllAppointments = () => {
          cy.get('body').then(($currentBody) => {
            if ($currentBody.find('button.cancel-btn').length > 0) {
              cy.get('button.cancel-btn').first().click()
              cy.waitForLoader() // Чекаємо оновлення сторінки після видалення
              deleteAllAppointments() // Повторюємо, поки є кнопки
            }
          })
        }
        deleteAllAppointments()
      }

      // Перевіряємо повідомлення про відсутність призначень
      cy.waitForLoader() // Чекаємо остаточного оновлення сторінки
      AppointmentsPage.verifyEmptyListMessage('en')
    })
  })

  // 3) Вхід як звичайний користувач, додавання 2 призначень, видалення 1
  it('should add two appointments, verify list, and delete one', () => {
    LoginPage.loginAs('commonUser')

    // Переходимо на Specialists Page і додаємо два призначення
    SpecialistsPage.visit()
    cy.waitForLoader()
    cy.setLang('en')

    SpecialistsPage.specialistsList.then(($list) => {
      if ($list.length > 0) {
        // Додаємо перше призначення
        cy.get('[data-cy="specialist"]')
          .first()
          .find('button')
          .contains('Make an appointment')
          .click()
        cy.waitForLoader()

        // Додаємо друге призначення
        cy.get('[data-cy="specialist"]')
          .first()
          .find('button')
          .contains('Make an appointment')
          .click()
        cy.waitForLoader()
      } else {
        SpecialistsPage.verifyEmptyListMessage('en')
        cy.log('No specialists available to make appointments.')
        return // Завершуємо тест, якщо немає спеціалістів
      }
    })

    // Переходимо на Appointments Page
    AppointmentsPage.visit()
    cy.waitForLoader()

    // Перевіряємо, що список не порожній і має >= 2 записи
    AppointmentsPage.appointmentsList.should('have.length.gte', 2)
    AppointmentsPage.emptyListMessage.should('not.exist')

    // Зберігаємо початкову кількість записів і продовжуємо ланцюжок
    cy.then(() => {
      return AppointmentsPage.appointmentsList.then(($list) => {
        const initialCount = $list.length // Зберігаємо кількість
        cy.log(`Initial count: ${initialCount}`) // Для дебагу

        // Видаляємо одне призначення
        AppointmentsPage.cancelAppointment()
        cy.waitForLoader()

        // Перевіряємо, що кількість зменшилась на 1
        AppointmentsPage.appointmentsList.should(
          'have.length',
          initialCount - 1
        )
      })
    })
  })
})
