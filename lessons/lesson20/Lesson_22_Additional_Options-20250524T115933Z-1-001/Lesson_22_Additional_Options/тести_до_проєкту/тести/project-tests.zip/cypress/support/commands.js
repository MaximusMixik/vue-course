// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
Cypress.Commands.add('loginAs', (userType, redirectPath = '/') => {
  const users = {
    admin: {
      email: Cypress.env('ADMIN_EMAIL'),
      password: Cypress.env('ADMIN_PASSWORD'),
    },
    commonUser: {
      email: Cypress.env('COMMON_USER_EMAIL'),
      password: Cypress.env('COMMON_USER_PASSWORD'),
    },
  }

  if (!users[userType]) {
    throw new Error(`User type "${userType}" is not defined`)
  }

  const { email, password } = users[userType]

  cy.visit('/login')
  cy.get('input[name="email"]').type(email)
  cy.get('input[name="password"]').type(password)
  cy.get('button').contains('Login').click()

  cy.url().should('eq', `${Cypress.config('baseUrl')}${redirectPath}`)
})

Cypress.Commands.add('setLang', (lang) => {
  cy.get('.lang span').contains(lang.toUpperCase()).click()
  cy.get('.lang span.selected').should('contain', lang.toUpperCase())
})

//команда для очікування лоадера
Cypress.Commands.add('waitForLoader', (timeout = 10000) => {
  // Чекаємо, поки лоадер з’явиться (якщо він є)
  cy.wait(1000)
  cy.get('.loading-container', { timeout }).should('not.exist')
})
export {}
