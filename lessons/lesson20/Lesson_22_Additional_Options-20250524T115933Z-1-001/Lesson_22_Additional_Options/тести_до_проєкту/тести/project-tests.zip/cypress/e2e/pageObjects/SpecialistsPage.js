class SpecialistsPage {
  get addButton() {
    return cy.get('button').contains('Add')
  }

  get specialistsList() {
    return cy.get('[data-cy="specialist"]')
  }

  get emptyListMessage() {
    return cy.get('h3').contains('List is empty')
  }

  visit() {
    cy.visit('/specialists')
  }

  clickAddButton() {
    this.addButton.click()
  }

  verifyEmptyListMessage(lang = 'ua') {
    const messages = {
      ua: 'Список порожній',
      en: 'List is empty',
    }
    this.emptyListMessage.should('have.text', messages[lang])
  }
}

export default new SpecialistsPage()
