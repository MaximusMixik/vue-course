// cypress/e2e/pageObjects/AppointmentsPage.js
class AppointmentsPage {
  get appointmentsList() {
    return cy.get('.appointments-list .container')
  }

  get emptyListMessage() {
    return cy.get('.empty-message')
  }

  get cancelButton() {
    return cy.get('button.cancel-btn')
  }

  visit() {
    cy.visit('/appointments')
  }

  cancelAppointment() {
    this.cancelButton.first().click()
  }

  verifyEmptyListMessage(lang = 'ua') {
    const messages = {
      ua: 'Немає візитів',
      en: 'No visits',
    }
    this.emptyListMessage.should('have.text', messages[lang])
  }
}

export default new AppointmentsPage()
