class HomePage {
  get welcomeMessage() {
    return cy.get('.home-container h1')
  }

  get subtitle() {
    return cy.get('.subtitle')
  }

  visit() {
    cy.visit('/')
  }

  verifyWelcomeMessage(lang = 'en') {
    const messages = {
      ua: 'Ласкаво просимо!',
      en: 'Welcome!',
    }
    this.welcomeMessage.should('have.text', messages[lang])
  }
}

export default new HomePage()
