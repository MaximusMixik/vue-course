import HomePage from '../pageObjects/HomePage'

describe('Home Page', () => {
  beforeEach(() => {
    HomePage.visit()
  })

  it('should display welcome message in Ukrainian by default', () => {
    // cy.get('.lang span').contains('UA').click()
    cy.setLang('ua')
    HomePage.verifyWelcomeMessage('ua')
  })

  it('should display welcome message in English after language switch', () => {
    // cy.get('.lang span').contains('EN').click()
    cy.setLang('en')
    HomePage.verifyWelcomeMessage('en')
  })
})
