import LoginPage from '../pageObjects/LoginPage.js'

describe('Login Page', () => {
  beforeEach(() => {
    LoginPage.visit()
  })

  it('should display login button with English text', () => {
    LoginPage.verifyLoginButtonText('en')
  })

  it('should allow admin login and show Users menu item', () => {
    // Вхід як адмін через loginAs
    LoginPage.loginAs('admin')

    // Перевірка редіректу на головну сторінку
    cy.url().should('eq', `${`Cypress.config('baseUrl')`}/`)

    cy.setLang('ua')

    // Перевірка наявності пункту "Користувачі" у меню
    cy.get('nav .menu-link')
      .contains('Користувачі') // Текст із i18n: pages.users.title.menu (ua)
      .should('be.visible')
  })

  it('should allow common user login and not show Users menu item', () => {
    // Вхід як звичайний користувач через loginAs
    LoginPage.loginAs('commonUser')

    // Перевірка редіректу на головну сторінку
    cy.url().should('eq', `${Cypress.config('baseUrl')}/`)

    cy.setLang('ua')

    // Перевірка відсутності пункту "Користувачі" у меню
    cy.get('nav .menu-link').contains('Користувачі').should('not.exist')
  })
})
