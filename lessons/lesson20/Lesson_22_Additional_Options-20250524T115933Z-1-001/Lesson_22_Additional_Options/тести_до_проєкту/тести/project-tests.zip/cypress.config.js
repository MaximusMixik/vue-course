// cypress.config.js
import { defineConfig } from 'cypress'
import dotenv from 'dotenv'

dotenv.config()

export default defineConfig({
  e2e: {
    baseUrl: 'http://localhost:5173',
    specPattern: 'cypress/e2e/**/*.cy.{js,jsx,ts,tsx}',
    supportFile: 'cypress/support/e2e.js',
    setupNodeEvents(on, config) {
      config.env.ADMIN_EMAIL = process.env.ADMIN_EMAIL
      config.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD
      config.env.COMMON_USER_EMAIL = process.env.COMMON_USER_EMAIL
      config.env.COMMON_USER_PASSWORD = process.env.COMMON_USER_PASSWORD
      return config
    },
  },
})
