export const permissionsList = ['create', 'read', 'update', 'delete']
