<template>
  <main-master-page>
    <div class="editor-container">
      <h1>
        {{
          specialistId ? $t('pages.specialists.title.edit') : $t('pages.specialists.title.create')
        }}
      </h1>
      <Form :validation-schema="schema" :initial-values="form" @submit="onSubmit">
        <div class="form-group">
          <label>{{ $t('pages.specialists.fields.name.label') }}</label>
          <Field
            name="title"
            v-model="form.title"
            type="text"
            :placeholder="$t('pages.specialists.fields.name.placeholder')"
          />
          <ErrorMessage name="title" class="error" />
        </div>
        <div class="form-group image">
          <div class="image-preview">
            <img v-if="form.img" :src="form.img" class="img" />
            <font-awesome-icon v-else :icon="['fas', 'user']" size="4x" class="icon" />
          </div>
          <label>{{ $t('pages.specialists.fields.image.label') }}</label>
          <input type="file" @change="loadImage" />
        </div>
        <div class="form-group">
          <label>{{ $t('pages.specialists.fields.category.label') }}</label>
          <Field name="category" as="select" v-model="form.category">
            <option value="" disabled>
              {{ $t('pages.specialists.fields.category.placeholder') }}
            </option>
            <option v-for="categoryId in categoriesList" :key="categoryId" :value="categoryId">
              {{ $t(`categories.${categoryId}`) }}
            </option>
          </Field>
          <ErrorMessage name="category" class="error" />
        </div>
        <div class="actions">
          <button type="submit" :disabled="isSubmitting">{{ btnTitle }}</button>
        </div>
      </Form>
    </div>
  </main-master-page>
</template>

<script setup>
import { Form, Field, ErrorMessage, useForm } from 'vee-validate'
import * as yup from 'yup'
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useSpecialistsStore } from '@/stores/specialists'
import MainMasterPage from '@/masterpages/MainMasterPage.vue'
import { categories } from './settings'
import { useI18n } from 'vue-i18n'

const { t } = useI18n({ useScope: 'global' })
const route = useRoute()
const router = useRouter()
const specialistsStore = useSpecialistsStore()

const specialistId = computed(() => route.params.id)
const categoriesList = computed(() => Object.keys(categories))

// Ініціалізація форми
const form = ref({
  title: '',
  img: '',
  category: ''
})

// Схема валідації
const schema = yup.object({
  title: yup.string().required('Name is required'),
  category: yup.string().required('Category is required')
})

// Налаштування vee-validate форми
const { setValues } = useForm({
  initialValues: form.value,
  validationSchema: schema
})

// Стан відправки
const isSubmitting = computed(() => specialistsStore.isLoading || false)

onMounted(async () => {
  if (specialistId.value) {
    const specialist = await specialistsStore.loadItemById(specialistId.value)

    form.value = { ...specialist } // Оновлюємо ref
    setValues({ ...specialist }) // Оновлюємо стан форми vee-validate
  }
})

const loadImage = (event) => {
  const file = event.target.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      form.value.img = e.target.result
      setValues({ ...form.value }) // Оновлюємо форму після зміни зображення
    }
    reader.readAsDataURL(file)
  }
}

const btnTitle = computed(() => (specialistId.value ? t('buttons.save') : t('buttons.create')))

const onSubmit = async (values) => {
  try {
    const payload = { ...values, img: form.value.img }
    if (specialistId.value) {
      await specialistsStore.updateItem(specialistId.value, payload)
    } else {
      await specialistsStore.addItem(payload)
    }
    router.push({ name: 'specialists' })
  } catch (error) {
    console.error('Submission failed:', error.message)
  }
}
</script>

<style lang="scss" scoped>
/* Стилі залишилися без змін */
</style>
