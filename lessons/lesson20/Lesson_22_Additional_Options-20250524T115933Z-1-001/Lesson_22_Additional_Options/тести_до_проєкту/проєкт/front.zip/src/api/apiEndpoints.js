const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

// Об'єкти для кожної сутності
const apiEndpoints = {
  auth: {
    login: () => `${API_URL}/auth/login`,
    register: () => `${API_URL}/auth/register`,
    profileByToken: () => `${API_URL}/auth/profile`
  },
  users: {
    getAll: () => `${API_URL}/users`,
    getById: (id) => `${API_URL}/users/${id}`,
    update: (id) => `${API_URL}/users/${id}`,
    delete: (id) => `${API_URL}/users/${id}`
  },
  specialists: {
    getAll: () => `${API_URL}/specialists`,
    getById: (id) => `${API_URL}/specialists/${id}`,
    create: () => `${API_URL}/specialists`,
    update: (id) => `${API_URL}/specialists/${id}`,
    delete: (id) => `${API_URL}/specialists/${id}`
  },
  appointments: {
    getAll: () => `${API_URL}/appointments`,
    create: () => `${API_URL}/appointments`,
    delete: (specialistId) => `${API_URL}/appointments/${specialistId}`
  }
}

export default apiEndpoints
