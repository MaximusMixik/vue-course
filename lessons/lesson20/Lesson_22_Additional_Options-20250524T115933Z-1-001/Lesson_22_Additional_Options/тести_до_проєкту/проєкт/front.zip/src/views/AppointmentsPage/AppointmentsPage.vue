<template>
  <main-master-page>
    <div class="appointments-container">
      <div v-if="itemsList.length" class="appointments-list">
        <specialist-item v-for="item in itemsList" :key="item.id" :specialist="item">
          <template #action>
            <button @click="onCancel(item.id)" class="cancel-btn">
              {{ $t('buttons.cancel') }}
            </button>
          </template>
        </specialist-item>
      </div>
      <div v-else class="empty-message">
        {{ $t('pages.appointments.messages.empty-list') }}
      </div>
    </div>
  </main-master-page>
</template>

<script setup>
import { onMounted } from 'vue'
import MainMasterPage from '@/masterpages/MainMasterPage.vue'
import SpecialistItem from '@/views/Specialists/SpecialistItem.vue'
import { useAppointmentsStore } from '@/stores/appointments'
import { storeToRefs } from 'pinia'

const appointmentsStore = useAppointmentsStore()
const { itemsList } = storeToRefs(appointmentsStore)

onMounted(() => {
  appointmentsStore.loadItemsList()
})

const onCancel = (specialistId) => {
  appointmentsStore.deleteItem(specialistId)
}
</script>

<style lang="scss" scoped>
/* Стилі залишилися без змін */
</style>
