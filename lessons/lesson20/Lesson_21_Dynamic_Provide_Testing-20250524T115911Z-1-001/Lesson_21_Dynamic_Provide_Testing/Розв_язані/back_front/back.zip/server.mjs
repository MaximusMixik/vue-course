import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import apiRoutes from './routes/index.mjs' // Підключаємо лише об'єднаний файл маршрутів

const app = express()

app.use(helmet())
app.use(cors())
app.use(express.json())

// Використовуємо об'єднаний роутер з префіксом /api
app.use('/api', apiRoutes)

app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ message: `Internal server error: ${err.message}` })
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => console.log(`Server running on port ${PORT}`))
