import db from '../config/db'

class DbOperations {
  constructor(table) {
    this.table = table
  }

  async loadItemsList() {
    const [rows] = await db.query(`SELECT * FROM ${this.table}`)
    return rows
  }

  async getItemById(id) {
    const [rows] = await db.query(`SELECT * FROM ${this.table} WHERE id = ?`, [
      id,
    ])
    return rows[0] || {}
  }

  async addItem(item) {
    const [result] = await db.query(`INSERT INTO ${this.table} SET ?`, item)
    return result.insertId
  }

  async addItemWithCustomId(id, item) {
    await db.query(`INSERT INTO ${this.table} (id, ?) VALUES (?, ?)`, [
      id,
      item,
      id,
    ])
    return true
  }

  async updateItem(id, data) {
    const [result] = await db.query(`UPDATE ${this.table} SET ? WHERE id = ?`, [
      data,
      id,
    ])
    return result.affectedRows > 0
  }

  async deleteItem(id) {
    const [result] = await db.query(`DELETE FROM ${this.table} WHERE id = ?`, [
      id,
    ])
    return result.affectedRows > 0
  }

  async loadFilteredData(field, operator, value) {
    const [rows] = await db.query(
      `SELECT * FROM ${this.table} WHERE ${field} ${operator} ?`,
      [value]
    )
    return rows
  }
}

module.exports = DbOperations
