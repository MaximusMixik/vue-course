import express from 'express'
import SpecialistController from '../controllers/specialistController.mjs'
import SpecialistValidator from '../validators/specialistValidator.mjs'
import {
  authMiddleware,
  checkPermission,
} from '../middleware/authMiddleware.mjs'

const router = express.Router()

router.get('/', SpecialistController.getSpecialists)
router.get('/:id', SpecialistController.getSpecialistById)
router.post(
  '/',
  authMiddleware,
  checkPermission('create'),
  SpecialistValidator.validate('create'),
  SpecialistController.createSpecialist
)
router.put(
  '/:id',
  authMiddleware,
  checkPermission('update'),
  SpecialistValidator.validate('update'),
  SpecialistController.updateSpecialist
)
router.delete(
  '/:id',
  authMiddleware,
  checkPermission('delete'),
  SpecialistController.deleteSpecialist
)

export default router
