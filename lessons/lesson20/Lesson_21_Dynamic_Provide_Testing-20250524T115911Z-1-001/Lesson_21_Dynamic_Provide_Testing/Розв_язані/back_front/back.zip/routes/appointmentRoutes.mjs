import express from 'express'
import AppointmentController from '../controllers/appointmentController.mjs'
import AppointmentValidator from '../validators/appointmentValidator.mjs'
import {
  authMiddleware,
  checkPermission,
} from '../middleware/authMiddleware.mjs'

const router = express.Router()

router.use(authMiddleware)
router.get('/', checkPermission('read'), AppointmentController.getAppointments)
router.post(
  '/',
  checkPermission('read'),
  AppointmentValidator.validate('create'),
  AppointmentController.createAppointment
)
router.delete(
  '/:appointmentId',
  checkPermission('read'),
  AppointmentController.deleteAppointment
)

export default router
