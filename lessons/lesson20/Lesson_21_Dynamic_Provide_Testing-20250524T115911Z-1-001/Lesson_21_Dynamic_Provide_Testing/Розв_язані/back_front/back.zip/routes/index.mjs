import express from 'express'
import authRoutes from './authRoutes.mjs'
import userRoutes from './userRoutes.mjs'
import specialistRoutes from './specialistRoutes.mjs'
import appointmentRoutes from './appointmentRoutes.mjs'

const router = express.Router()

// Підключення всіх маршрутів
router.use('/auth', authRoutes)
router.use('/users', userRoutes)
router.use('/specialists', specialistRoutes)
router.use('/appointments', appointmentRoutes)

export default router
