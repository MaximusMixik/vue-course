import express from 'express'
import UserController from '../controllers/userController.mjs'
import UserValidator from '../validators/userValidator.mjs'
import {
  authMiddleware,
  checkPermission,
} from '../middleware/authMiddleware.mjs'

const router = express.Router()

router.use(authMiddleware)

router.get('/', checkPermission('read'), UserController.getUsers)
router.get('/:id', checkPermission('read'), UserController.getUserById)
router.post(
  '/',
  UserValidator.validate('create'),
  checkPermission('isAdmin'),
  UserController.createUser
)

router.put(
  '/:id',
  checkPermission('isAdmin'),
  UserValidator.validate('update'),
  UserController.updateUser
)
router.delete('/:id', checkPermission('isAdmin'), UserController.deleteUser)

export default router
