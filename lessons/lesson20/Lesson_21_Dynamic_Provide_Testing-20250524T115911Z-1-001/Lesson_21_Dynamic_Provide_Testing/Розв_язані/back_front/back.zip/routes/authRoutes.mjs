import express from 'express'
import AuthController from '../controllers/authController.mjs'
import UserValidator from '../validators/userValidator.mjs'
import {
  authMiddleware,
  checkPermission,
} from '../middleware/authMiddleware.mjs'

const router = express.Router()

router.post('/login', UserValidator.validate('login'), AuthController.login)
router.post(
  '/register',
  UserValidator.validate('create'),
  AuthController.register
)

router.get(
  '/profile',
  authMiddleware,
  checkPermission('read'),
  AuthController.getProfile
)

export default router
