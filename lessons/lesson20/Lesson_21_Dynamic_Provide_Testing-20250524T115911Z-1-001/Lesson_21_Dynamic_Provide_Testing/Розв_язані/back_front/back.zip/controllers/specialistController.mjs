import SpecialistModel from '../models/specialistModel.mjs'

class SpecialistController {
  static async getSpecialists(req, res) {
    try {
      const specialists = await SpecialistModel.getAll()
      res.json(specialists)
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async getSpecialistById(req, res) {
    try {
      const specialist = await SpecialistModel.findById(req.params.id)
      res.json(specialist)
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async createSpecialist(req, res) {
    try {
      const data = req.validatedData
      const id = await SpecialistModel.create(data)
      res.status(201).json({ id, ...data })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async updateSpecialist(req, res) {
    try {
      const data = req.validatedData
      await SpecialistModel.update(req.params.id, data)
      res.json({ message: 'Specialist updated' })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async deleteSpecialist(req, res) {
    try {
      await SpecialistModel.delete(req.params.id)
      res.json({ message: 'Specialist deleted' })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }
}

export default SpecialistController
