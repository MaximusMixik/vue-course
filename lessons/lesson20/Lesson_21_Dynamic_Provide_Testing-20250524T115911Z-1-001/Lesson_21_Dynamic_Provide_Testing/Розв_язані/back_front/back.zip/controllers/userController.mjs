import bcrypt from 'bcryptjs'
import UserModel from '../models/userModel.mjs'

class UserController {
  static async getUsers(req, res) {
    try {
      const users = await UserModel.getAll()
      res.json(
        users.map((user) => ({
          ...user,
          permissions: JSON.parse(user.permissions),
        }))
      )
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async getUserById(req, res) {
    try {
      const user = await UserModel.findById(req.params.id)
      if (!user) return res.status(404).json({ message: 'User not found' })
      res.json({ ...user, permissions: JSON.parse(user.permissions) })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async createUser(req, res) {
    try {
      const data = req.validatedData

      if (data.password) data.password = await bcrypt.hash(data.password, 10)
      await UserModel.create(data)
      res.json({ message: 'User updated' })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async updateUser(req, res) {
    try {
      const data = req.validatedData
      if (data.permissions) data.permissions = JSON.stringify(data.permissions)
      if (data.password) data.password = await bcrypt.hash(data.password, 10)
      await UserModel.update(req.params.id, data)
      res.json({ message: 'User updated' })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async deleteUser(req, res) {
    try {
      await UserModel.delete(req.params.id)
      res.json({ message: 'User deleted' })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }
}

export default UserController
