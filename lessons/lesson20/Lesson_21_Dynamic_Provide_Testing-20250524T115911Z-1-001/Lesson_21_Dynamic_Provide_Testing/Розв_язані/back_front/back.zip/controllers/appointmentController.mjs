import AppointmentModel from '../models/appointmentModel.mjs'
import SpecialistModel from '../models/specialistModel.mjs'

class AppointmentController {
  static async getAppointments(req, res) {
    try {
      const appointments = await AppointmentModel.findByUserId(req.user.id)
      res.json(appointments)
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async createAppointment(req, res) {
    try {
      const { specialistId } = req.validatedData
      const id = await AppointmentModel.create({
        userId: req.user.id,
        specialistId,
      })
      res.status(201).json({ id, userId: req.user.id, specialistId })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }

  static async deleteAppointment(req, res) {
    try {
      await AppointmentModel.delete(req.user.id, req.params.appointmentId)
      res.json({ message: 'Appointment deleted' })
    } catch (error) {
      res
        .status(500)
        .json({ message: `Internal server error: ${error.message}` })
    }
  }
}

export default AppointmentController
