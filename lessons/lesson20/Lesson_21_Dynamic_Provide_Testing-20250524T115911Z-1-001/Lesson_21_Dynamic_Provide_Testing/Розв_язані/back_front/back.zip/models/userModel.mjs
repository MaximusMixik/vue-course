import db from '../config/db.mjs'

class UserModel {
  static async create({ email, password }) {
    try {
      const [result] = await db.query(
        'INSERT INTO users (email, password, permissions) VALUES (?, ?, ?)',
        [
          email,
          password,
          JSON.stringify({
            create: false,
            read: true,
            update: false,
            delete: false,
            isAdmin: false,
          }),
        ]
      )
      return result.insertId
    } catch (error) {
      throw new Error(`Failed to create user: ${error.message}`)
    }
  }

  static async findByEmail(email) {
    try {
      const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [
        email,
      ])
      return rows[0]
    } catch (error) {
      throw new Error(`Failed to find user by email: ${error.message}`)
    }
  }

  static async findById(id) {
    try {
      const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [id])
      return rows[0]
    } catch (error) {
      throw new Error(`Failed to find user by ID: ${error.message}`)
    }
  }

  static async update(id, data) {
    try {
      const [result] = await db.query('UPDATE users SET ? WHERE id = ?', [
        data,
        id,
      ])
      if (result.affectedRows === 0) throw new Error('User not found')
      return true
    } catch (error) {
      throw new Error(`Failed to update user: ${error.message}`)
    }
  }

  static async delete(id) {
    try {
      const [result] = await db.query('DELETE FROM users WHERE id = ?', [id])
      if (result.affectedRows === 0) throw new Error('User not found')
      return true
    } catch (error) {
      throw new Error(`Failed to delete user: ${error.message}`)
    }
  }

  static async getAll() {
    try {
      const [rows] = await db.query('SELECT * FROM users')
      return rows
    } catch (error) {
      throw new Error(`Failed to fetch users: ${error.message}`)
    }
  }
}

export default UserModel
