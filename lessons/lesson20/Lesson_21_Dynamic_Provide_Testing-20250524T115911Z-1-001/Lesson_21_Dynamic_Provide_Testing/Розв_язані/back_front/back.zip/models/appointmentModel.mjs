import db from '../config/db.mjs'

class AppointmentModel {
  static async create({ userId, specialistId }) {
    try {
      const [result] = await db.query(
        'INSERT INTO appointments (user_id, specialist_id) VALUES (?, ?)',
        [userId, specialistId]
      )
      return result.insertId
    } catch (error) {
      throw new Error(`Failed to create appointment: ${error.message}`)
    }
  }

  static async findByUserId(userId) {
    try {
      const [rows] = await db.query(
        `SELECT
          appointments.id,
          specialists.id as specialists_id,
          specialists.title,
          specialists.category,
          specialists.img,
          specialists.rating
        FROM appointments
        LEFT JOIN specialists ON appointments.specialist_id = specialists.id
        WHERE appointments.user_id = ?
        `,
        [userId]
      )
      return rows
    } catch (error) {
      throw new Error(`Failed to fetch appointments: ${error.message}`)
    }
  }

  static async delete(userId, appointmentId) {
    try {
      const [result] = await db.query(
        'DELETE FROM appointments WHERE user_id = ? AND id = ?',
        [userId, appointmentId]
      )
      if (result.affectedRows === 0) throw new Error('Appointment not found')
      return true
    } catch (error) {
      throw new Error(`Failed to delete appointment: ${error.message}`)
    }
  }
}

export default AppointmentModel
