import db from '../config/db.mjs'

class SpecialistModel {
  static async create({ title, img, category, rating }) {
    try {
      const [result] = await db.query(
        'INSERT INTO specialists (title, img, category, rating) VALUES (?, ?, ?, ?)',
        [title, img, category, rating || null]
      )
      return result.insertId
    } catch (error) {
      throw new Error(`Failed to create specialist: ${error.message}`)
    }
  }

  static async findById(id) {
    try {
      const [rows] = await db.query('SELECT * FROM specialists WHERE id = ?', [
        id,
      ])
      if (!rows[0]) throw new Error('Specialist not found')
      return rows[0]
    } catch (error) {
      throw new Error(`Failed to find specialist by ID: ${error.message}`)
    }
  }

  static async getAll() {
    try {
      const [rows] = await db.query('SELECT * FROM specialists')
      return rows
    } catch (error) {
      throw new Error(`Failed to fetch specialists: ${error.message}`)
    }
  }

  static async update(id, data) {
    try {
      const [result] = await db.query('UPDATE specialists SET ? WHERE id = ?', [
        data,
        id,
      ])
      if (result.affectedRows === 0) throw new Error('Specialist not found')
      return true
    } catch (error) {
      throw new Error(`Failed to update specialist: ${error.message}`)
    }
  }

  static async delete(id) {
    try {
      const [result] = await db.query('DELETE FROM specialists WHERE id = ?', [
        id,
      ])
      if (result.affectedRows === 0) throw new Error('Specialist not found')
      return true
    } catch (error) {
      throw new Error(`Failed to delete specialist: ${error.message}`)
    }
  }
}

export default SpecialistModel
