import Joi from 'joi'

class AppointmentValidator {
  static schemas = {
    create: Joi.object({
      specialistId: Joi.number().integer().required().messages({
        'any.required': 'Specialist ID is required',
        'number.base': 'Specialist ID must be a number',
      }),
    }),
  }

  static validate(schemaName) {
    return async (req, res, next) => {
      try {
        const schema = this.schemas[schemaName]
        const { error, value } = schema.validate(req.body, {
          abortEarly: false,
        })
        if (error) {
          return res.status(400).json({
            message: 'Validation failed',
            errors: error.details.map((detail) => detail.message),
          })
        }
        req.validatedData = value
        next()
      } catch (error) {
        res
          .status(500)
          .json({ message: `Internal validation error: ${error.message}` })
      }
    }
  }
}

export default AppointmentValidator
