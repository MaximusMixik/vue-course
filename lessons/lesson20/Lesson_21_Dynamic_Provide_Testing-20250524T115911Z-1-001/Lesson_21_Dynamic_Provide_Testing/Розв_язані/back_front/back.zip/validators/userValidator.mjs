import Joi from 'joi'

class UserValidator {
  static schemas = {
    create: Joi.object({
      email: Joi.string().email().required().messages({
        'string.email': 'Invalid email format',
        'any.required': 'Email is required',
      }),
      password: Joi.string().min(2).required().messages({
        'string.min': 'Password must be at least 6 characters',
        'any.required': 'Password is required',
      }),
    }),
    update: Joi.object({
      email: Joi.string().email().optional(),
      password: Joi.string().min(2).optional(),
      permissions: Joi.object({
        create: Joi.boolean(),
        read: Joi.boolean(),
        update: Joi.boolean(),
        delete: Joi.boolean(),
        isAdmin: Joi.boolean(),
      }).optional(),
    }),
    login: Joi.object({
      email: Joi.string().email().required().messages({
        'string.email': 'Invalid email format',
        'any.required': 'Email is required',
      }),
      password: Joi.string().min(2).required().messages({
        'string.min': 'Password must be at least 6 characters',
        'any.required': 'Password is required',
      }),
    }),
  }

  static validate(schemaName) {
    return async (req, res, next) => {
      try {
        const schema = this.schemas[schemaName]
        const { error, value } = schema.validate(req.body, {
          abortEarly: false,
        })
        if (error) {
          return res.status(400).json({
            message: 'Validation failed',
            errors: error.details.map((detail) => detail.message),
          })
        }
        req.validatedData = value
        next()
      } catch (error) {
        res
          .status(500)
          .json({ message: `Internal validation error: ${error.message}` })
      }
    }
  }
}

export default UserValidator
