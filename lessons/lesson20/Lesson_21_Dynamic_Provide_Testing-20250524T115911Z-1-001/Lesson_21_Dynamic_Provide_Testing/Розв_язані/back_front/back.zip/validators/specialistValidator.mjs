import Joi from 'joi'

class SpecialistValidator {
  static schemas = {
    create: Joi.object({
      title: Joi.string().required().messages({
        'any.required': 'Title is required',
      }),
      img: Joi.string().optional(),
      category: Joi.string().required().messages({
        'any.required': 'Category is required',
      }),
      rating: Joi.number().min(0).max(5).optional(),
    }),
    update: Joi.object({
      title: Joi.string().optional(),
      img: Joi.string().optional(),
      category: Joi.string().optional(),
      rating: Joi.number().min(0).max(5).optional(),
    }),
  }

  static validate(schemaName) {
    return async (req, res, next) => {
      try {
        const schema = this.schemas[schemaName]
        const { error, value } = schema.validate(req.body, {
          abortEarly: false,
        })
        if (error) {
          return res.status(400).json({
            message: 'Validation failed',
            errors: error.details.map((detail) => detail.message),
          })
        }
        req.validatedData = value
        next()
      } catch (error) {
        res
          .status(500)
          .json({ message: `Internal validation error: ${error.message}` })
      }
    }
  }
}

export default SpecialistValidator
