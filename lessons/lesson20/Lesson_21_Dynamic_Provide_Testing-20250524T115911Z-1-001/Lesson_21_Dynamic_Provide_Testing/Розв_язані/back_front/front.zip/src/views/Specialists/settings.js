export const categories = {
  therapist: {
    icon: ['fas', 'fa-stethoscope'],
    color: 'brown'
  },
  cardiologist: {
    icon: ['fas', 'fa-heartbeat'],
    color: 'red'
  },
  urologist: { icon: ['fas', 'fa-user-md'], color: 'orange' },
  psychologist: { icon: ['fas', 'fa-brain'], color: 'green' },
  dentist: {
    icon: ['fas', 'fa-tooth'],

    color: 'blue'
  }
}
