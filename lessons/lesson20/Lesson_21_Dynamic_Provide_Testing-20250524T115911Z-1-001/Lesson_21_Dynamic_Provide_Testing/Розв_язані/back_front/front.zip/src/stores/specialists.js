import { defineStore } from 'pinia'
import getStoreTemplate from './helpers/storeTemplate'

export const useSpecialistsStore = defineStore('specialists', () => {
  return getStoreTemplate('specialists')
})
