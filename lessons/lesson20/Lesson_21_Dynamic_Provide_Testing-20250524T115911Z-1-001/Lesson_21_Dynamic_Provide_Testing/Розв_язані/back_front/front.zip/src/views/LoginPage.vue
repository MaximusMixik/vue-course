<template>
  <simple-master-page>
    <div class="login-container">
      <Form
        v-slot="{ values }"
        :validation-schema="schema"
        :initial-values="form"
        @submit="onSubmit"
      >
        <div class="form-group">
          <label>{{ $t('pages.login.fields.email.label') }}</label>
          <Field
            name="email"
            type="email"
            :placeholder="$t('pages.login.fields.email.placeholder')"
          />
          <ErrorMessage name="email" class="error" />
        </div>
        <div class="form-group">
          <label>{{ $t('pages.login.fields.password.label') }}</label>
          <Field
            name="password"
            type="password"
            :placeholder="$t('pages.login.fields.password.placeholder')"
          />
          <ErrorMessage name="password" class="error" />
        </div>
        <div class="actions">
          <button type="submit" :disabled="isSubmitting">{{ $t('buttons.login') }}</button>
          <button type="button" @click="goToRegister(values)">{{ $t('buttons.register') }}</button>
        </div>
      </Form>
    </div>
  </simple-master-page>
</template>

<script setup>
import { Form, Field, ErrorMessage, useForm } from 'vee-validate'
import * as yup from 'yup'
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import SimpleMasterPage from '@/masterpages/SimpleMasterPage.vue'
import { storeToRefs } from 'pinia'

// Ініціалізація форми
const form = ref({
  email: '',
  password: ''
})

// Схема валідації
const schema = yup.object({
  email: yup.string().email('Invalid email format').required('Email is required'),
  password: yup
    .string()
    .min(2, 'Password must be at least 6 characters')
    .required('Password is required')
})

// Використання useForm для доступу до стану форми
const { values } = useForm({
  initialValues: form.value,
  validationSchema: schema
})

// Ініціалізація роутера та стора
const router = useRouter()
const authStore = useAuthStore()

// Обчислювана властивість для стану відправки
const isSubmitting = computed(() => authStore.isLoading)

// Метод для логіну
const onSubmit = async (formValues) => {
  try {
    await authStore.login(formValues.email, formValues.password)
    const redirect = router.currentRoute.value.query.redirect || '/'
    router.push(redirect)
  } catch (error) {
    console.error('Login failed:', error.message)
  }
}

// Метод для переходу на реєстрацію з доступом до даних форми
const goToRegister = async (values) => {
  try {
    await authStore.register(values.email, values.password)
    const redirect = router.currentRoute.value.query.redirect || '/'
    router.push(redirect)
  } catch (error) {
    console.error('Login failed:', error.message)
  }
}
</script>

<style lang="scss" scoped>
.login-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 24px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);

  .form-group {
    margin-bottom: 16px;

    label {
      display: block;
      font-weight: 500;
      margin-bottom: 8px;
    }

    input {
      width: 100%;
      padding: 10px;
      border: 1px solid #bdc3c7;
      border-radius: 4px;
    }

    .error {
      color: #e74c3c;
      font-size: 0.9rem;
      margin-top: 4px;
    }
  }

  .actions {
    display: flex;
    justify-content: center;
    gap: 16px;

    button {
      background-color: #3498db;
      padding: 10px 20px;
      border: none;
      color: white;
      border-radius: 4px;

      &:hover {
        background-color: #2980b9;
      }

      &:disabled {
        background-color: #bdc3c7;
      }
    }

    button[type='button'] {
      background-color: #2ecc71;

      &:hover {
        background-color: #27ae60;
      }
    }
  }
}
</style>
