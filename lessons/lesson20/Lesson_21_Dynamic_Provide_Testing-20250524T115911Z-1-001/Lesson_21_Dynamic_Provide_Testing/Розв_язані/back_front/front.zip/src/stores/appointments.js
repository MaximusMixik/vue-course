import { defineStore } from 'pinia'
import getStoreTemplate from './helpers/storeTemplate'

export const useAppointmentsStore = defineStore('appointments', () => {
  const template = getStoreTemplate('appointments')

  return {
    ...template
  }
})
