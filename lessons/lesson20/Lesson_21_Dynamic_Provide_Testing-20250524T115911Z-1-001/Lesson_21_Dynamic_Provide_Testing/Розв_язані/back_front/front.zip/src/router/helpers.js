import { useAuthStore } from '@/stores/auth'
import { storeToRefs } from 'pinia'

export function isAuthenticated() {
  return useAuthStore().getUser
}

export function isRouteAvailable(routeItem) {
  const { getCurrentUserPermissions, user } = storeToRefs(useAuthStore())

  return (
    !routeItem.meta?.requireAuth ||
    (routeItem.meta?.hasAccess && routeItem.meta.hasAccess(getCurrentUserPermissions.value)) ||
    (!routeItem.meta?.hasAccess && user.value)
  )
}
