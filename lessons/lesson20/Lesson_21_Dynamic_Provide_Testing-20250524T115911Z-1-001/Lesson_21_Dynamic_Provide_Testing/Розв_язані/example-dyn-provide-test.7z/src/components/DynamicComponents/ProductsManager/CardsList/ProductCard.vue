<!-- ProductCard.vue -->
<template>
  <div class="product-card">
    <img :src="product.imgSrc" alt="Product Image" />
    <h3>{{ product.title }}</h3>
    <p>Ціна: {{ product.price }} грн</p>
  </div>
</template>

<script setup>
defineProps(['product'])
</script>

<style scoped>
.product-card {
  height: 250px;
  width: 200px;
  padding: 15px;
  border: 2px solid green;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  border-radius: 12px;
  margin: 20px;
}
img {
  height: 80px;
}
</style>
