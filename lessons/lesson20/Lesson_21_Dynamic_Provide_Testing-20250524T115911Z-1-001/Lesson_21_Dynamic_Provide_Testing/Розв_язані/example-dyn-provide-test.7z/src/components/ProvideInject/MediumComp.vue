<template>
  <div>
    <h2>Medium Component</h2>
    <!-- Не використовуємо isActive у цьому компоненті -->
    <ChildComp />
  </div>
</template>

<script setup>
import ChildComp from './ChildComp.vue'
</script>
