<!-- ProductRow.vue -->
<template>
  <div class="product-row">
    <div class="product-info">
      <h3>{{ product.title }}</h3>
      <p>Ціна: {{ product.price }} грн</p>
    </div>
    <img :src="product.imgSrc" alt="Product Image" />
  </div>
</template>

<script setup>
defineProps(['product'])
</script>

<style scoped>
.product-row {
  display: flex;
  width: 600px;
  align-self: center;
  justify-content: space-between;
  margin: 20px;
  border: 2px solid green;
  border-radius: 12px;
  padding: 15px;
}
img {
  height: 80px;
}
</style>
