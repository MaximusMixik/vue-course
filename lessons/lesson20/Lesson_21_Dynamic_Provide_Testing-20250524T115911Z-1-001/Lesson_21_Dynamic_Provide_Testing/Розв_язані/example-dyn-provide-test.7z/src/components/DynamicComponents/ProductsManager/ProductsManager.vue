<!-- ProductsManager.vue -->
<template>
  <div>
    <h1>{{ title }}</h1>
    <component :is="currentComponent" :products="products" />
    <button @click="addNewProduct">Додати новий товар</button>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import CardsList from './CardsList/CardsList.vue'
import RowsList from './RowsList/RowsList.vue'
import TableRows from './TableRows/TableRows.vue'

const title = 'Менеджер Продуктів'
const props = defineProps({
  products: {
    type: Array,
    required: true
  },
  mode: {
    type: String,
    default: 'cards'
  }
})

const currentComponent = computed(() => {
  switch (props.mode) {
    case 'cards':
      return CardsList
    case 'rows':
      return RowsList
    case 'table':
      return TableRows
    default:
      return CardsList
  }
})

function addNewProduct() {
  //додавання
}
</script>
