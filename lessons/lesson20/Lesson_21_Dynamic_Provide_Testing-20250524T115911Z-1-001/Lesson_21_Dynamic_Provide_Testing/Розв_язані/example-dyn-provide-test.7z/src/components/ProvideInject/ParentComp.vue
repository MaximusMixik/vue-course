<template>
  <div>
    <h1>Parent Component</h1>
    <p>
      isActive:
      <input v-model="isActive" type="checkbox" />
    </p>
    <MediumComp />
  </div>
</template>

<script setup>
import { ref, provide } from 'vue'
import MediumComp from './MediumComp.vue'

const isActive = ref(true)
provide('isActive', isActive)
</script>
