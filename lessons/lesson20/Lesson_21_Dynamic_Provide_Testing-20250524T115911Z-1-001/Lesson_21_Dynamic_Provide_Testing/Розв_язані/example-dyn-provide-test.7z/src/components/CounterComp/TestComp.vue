<template>
  <div>
    <button :disabled="isDecrementDisabled" @click="decrement">Decrement</button>
    <span>{{ count }}</span>
    <button :disabled="isIncrementDisabled" @click="increment">Increment</button>
  </div>
</template>

<script setup>
import { ref, computed, defineProps, defineEmits } from 'vue'

const props = defineProps(['min', 'max', 'initialValue'])
const emits = defineEmits(['increment', 'decrement'])

const count = ref(props.initialValue || 0)

const isDecrementDisabled = computed(() => count.value <= props.min)
const isIncrementDisabled = computed(() => count.value >= props.max)

const increment = () => {
  if (count.value < props.max) {
    count.value++
    emits('increment', count.value)
  }
}

const decrement = () => {
  if (count.value > props.min) {
    count.value--
    emits('decrement', count.value)
  }
}
</script>

<style scoped>
/* Ваші стилі тут */
</style>
