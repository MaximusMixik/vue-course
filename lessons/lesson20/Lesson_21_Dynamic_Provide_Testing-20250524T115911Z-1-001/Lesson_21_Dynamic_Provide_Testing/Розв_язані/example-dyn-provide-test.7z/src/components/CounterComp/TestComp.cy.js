/* eslint-disable cypress/unsafe-to-chain-command */
import TestComp from './TestComp.vue'

describe('<TestComp />', () => {
  it('sending props', () => {
    const onDecrementSpy = cy.spy().as('onDecrementSpy')
    const onIncrementSpy = cy.spy().as('onIncrementSpy')
    cy.mount(TestComp, {
      props: {
        min: 0,
        max: 10,
        initialValue: 3,

        onIncrement: onIncrementSpy,
        onDecrement: onDecrementSpy
      }
    })

    cy.get('button').eq(1).click()
    cy.contains('span', '4').should('exist')

    cy.get('button').eq(0).click()
    cy.contains('span', '3').should('exist')
  })
})
