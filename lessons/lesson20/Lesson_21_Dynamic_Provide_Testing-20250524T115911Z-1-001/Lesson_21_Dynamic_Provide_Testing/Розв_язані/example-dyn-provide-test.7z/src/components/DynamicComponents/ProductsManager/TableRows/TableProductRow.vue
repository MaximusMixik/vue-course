<!-- TableProductRow.vue -->
<template>
  <tr>
    <td>{{ product.title }}</td>
    <td>{{ product.price }} грн</td>
    <td><img :src="product.imgSrc" alt="Product Image" /></td>
  </tr>
</template>

<script setup>
defineProps(['product'])
</script>

<style scoped>
/* Стилізуйте за потребою */
</style>
