<template>
  <div>
    <h3>Child Component</h3>
    <p>isActive from Parent: {{ isActive }}</p>
  </div>
</template>

<script setup>
import { inject } from 'vue'
const isActive = inject('isActive')
</script>

<style>
/* Ваші стилі тут */
</style>
