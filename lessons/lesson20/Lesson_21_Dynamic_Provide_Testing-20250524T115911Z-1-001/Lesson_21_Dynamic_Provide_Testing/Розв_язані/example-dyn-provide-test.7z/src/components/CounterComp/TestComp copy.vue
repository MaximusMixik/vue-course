<template>
  <div>
    <div>
      <label> Num1 <input v-model="num1" type="number" /> </label>
    </div>
    <div>
      <label> Num2 <input v-model="num2" type="number" /> </label>
    </div>
    <div>Sum = {{ sum }}</div>
    <div>prod = {{ prod }}</div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'

const props = defineProps({
  initNum1: {
    type: Number,
    default: 0
  },
  initNum2: {
    type: Number,
    default: 0
  }
})

const num1 = ref(props.initNum1)
const num2 = ref(props.initNum2)

const sum = computed(() => num1.value + num2.value)
const prod = computed(() => num1.value * num2.value)
</script>

<style lang="scss" scoped></style>
