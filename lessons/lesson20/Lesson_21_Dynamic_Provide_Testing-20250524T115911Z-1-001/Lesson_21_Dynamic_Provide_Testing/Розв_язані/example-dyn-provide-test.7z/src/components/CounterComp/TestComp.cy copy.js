/* eslint-disable cypress/unsafe-to-chain-command */
import TestComp from './TestComp.vue'

describe('<TestComp />', () => {
  beforeEach(() => {
    cy.mount(TestComp, {
      props: {
        initNum1: 11,
        initNum2: 22
      }
    })
  })
  it('renders', () => {
    cy.get('label').contains('Num1').should('exist')
  })
  it('sending props', () => {
    cy.get('label').contains('Num1').should('exist')

    cy.get('input').eq(0).should('have.value', '11')
    cy.get('input').eq(1).should('have.value', '22')
  })

  // it('check input values', () => {
  //   cy.get('input').eq(0).clear()
  //   cy.get('input').eq(0).type('2asdasd{enter}')
  //   cy.get('input').eq(0).should('have.value', '2')

  //   cy.get('input').eq(1).type('3{enter}')
  // })
  // it('check operation results', () => {
  //   cy.get('input').eq(0).clear().type('2{enter}')
  //   cy.get('input').eq(1).clear().type('3{enter}')
  //   cy.get('div').contains('5').should('exist')
  //   cy.get('div').contains('6').should('exist')
  // })
})
