<!-- RowsList.vue -->
<template>
  <div class="rows-list">
    <ProductRow v-for="product in products" :key="product.id" :product="product" />
  </div>
</template>

<script setup>
import ProductRow from './ProductRow.vue'
defineProps(['products'])
</script>

<style scoped>
/* Стилізуйте за потребою */
</style>
