<!-- CardsList.vue -->
<template>
  <div class="cards-list">
    <ProductCard v-for="product in products" :key="product.id" :product="product" />
  </div>
</template>

<script setup>
import ProductCard from './ProductCard.vue'
defineProps(['products'])
</script>

<style scoped>
.cards-list {
  display: flex;
  flex-wrap: wrap;
}
</style>
