<!-- TableRows.vue -->
<template>
  <table class="table-rows">
    <thead>
      <tr>
        <th>Title</th>
        <th>Price</th>
        <th>Image</th>
      </tr>
    </thead>
    <tbody>
      <TableProductRow v-for="product in products" :key="product.id" :product="product" />
    </tbody>
  </table>
</template>

<script setup>
import TableProductRow from './TableProductRow.vue'
defineProps(['products'])
</script>

<style scoped>
.table-rows {
  border-collapse: collapse;
  width: 100%;
  background-color: aqua;
  color: black;
  width: 600px;
}

/* Стилі для клітинок таблиці */
td,
th {
  border: 1px solid green; /* Рамка клітинки */
  padding: 0; /* Відсутність внутрішнього відступу */
  width: 60px; /* Ширина клітинки */
  text-align: center; /* Вирівнювання тексту у центр */
}

/* Додаткові стилі (опціонально) */
th {
  background-color: red; /* Фон заголовку таблиці */
  font-weight: bold; /* Жирний шрифт у заголовку таблиці */
}

/* Стилі для зебрового рядка (опціонально) */
tr:nth-child(even) {
  background-color: #f9f9f9; /* Фон зебрового рядка */
}
</style>
