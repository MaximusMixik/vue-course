export function sum(a, b) {
  return a + b
}
export function product(a, b) {
  return a * b
}
export function complexFunction(x) {
  return 3 * Math.sin(x) + Math.cos(Math.sqrt(x))
}
