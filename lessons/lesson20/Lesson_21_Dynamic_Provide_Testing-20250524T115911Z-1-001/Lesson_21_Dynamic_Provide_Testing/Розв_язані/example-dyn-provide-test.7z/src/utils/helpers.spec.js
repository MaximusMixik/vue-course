import { describe, it, expect } from 'vitest'
import { sum, product, complexFunction } from './helpers'

describe('Test helpers', () => {
  it('Sum func', () => {
    expect(sum(2, 1)).toBe(3)
  })

  it('product func', () => {
    expect(product(2, 1)).toBe(2)
  })

  it('complexFunction func', () => {
    expect(complexFunction(3.5)).toMatchSnapshot()
  })
})
