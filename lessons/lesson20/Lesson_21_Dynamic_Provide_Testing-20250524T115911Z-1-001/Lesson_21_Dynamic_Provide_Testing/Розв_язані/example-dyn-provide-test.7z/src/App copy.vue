<script setup>
import ParentComp from './components/ProvideInject/ParentComp.vue'
</script>

<template>
  <div>
    <parent-comp />
  </div>
</template>

<style scoped></style>
