// https://on.cypress.io/api

describe('My First Test', () => {
  it('visits the app root url', () => {
    cy.visit('/')
    cy.contains('About').click()
    cy.contains('h1', 'This is an about page1').should('exist')
  })
})
