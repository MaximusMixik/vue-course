/* eslint-disable cypress/unsafe-to-chain-command */
describe('Rozetka Search Test', () => {
  it('should filter products when searching for Samsung', () => {
    // 1. Відвідуємо головну сторінку
    cy.visit('https://allo.ua')

    // 2. У полі пошуку вводимо Samsung
    cy.get('#search-form__input').type('Samsung').type('{enter}')

    // Зачекайте на завантаження результатів пошуку
    cy.get('.products-layout__container').should('be.visible')

    // 3. Перевіряємо, чи відбулась фільтрація
    cy.get('[data-product-id]')
      .should('be.visible') // Перевірка видимості товарів
      .each(($title) => {
        expect($title.text().toLowerCase()).to.include('samsung')
      }) // Перевірка, що кожен товар має слово Samsung у назві
  })
})
