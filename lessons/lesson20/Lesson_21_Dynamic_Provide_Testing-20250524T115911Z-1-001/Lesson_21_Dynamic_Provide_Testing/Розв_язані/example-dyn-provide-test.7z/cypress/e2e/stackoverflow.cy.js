/* eslint-disable cypress/unsafe-to-chain-command */
describe('Stack Overflow Search Test', () => {
  it('should filter content when searching for "cypress e2e"', () => {
    // 1. Відвідуємо головну сторінку Stack Overflow
    cy.visit('https://stackoverflow.com/')

    // 2. У полі пошуку вводимо "cypress e2e"
    cy.get('#search').type('cypress e2e').type('{enter}')

    // Зачекайте на завантаження результатів пошуку
    cy.get('.question-summary').should('be.visible')

    // 3. Перевіряємо, чи відбулась фільтрація
    cy.get('.question-summary')
      .should('be.visible') // Перевірка видимості знайдених питань
      .each(($question) => {
        expect($question.text().toLowerCase()).to.include('cypress e2e')
      }) // Перевірка, що кожне питання містить "cypress e2e" у вмісті
  })
})
