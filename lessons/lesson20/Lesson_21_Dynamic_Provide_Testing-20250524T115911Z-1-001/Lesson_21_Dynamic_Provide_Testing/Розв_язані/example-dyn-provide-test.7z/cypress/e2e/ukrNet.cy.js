/* eslint-disable cypress/unsafe-to-chain-command */
describe('Ukrnet Search Test', () => {
  it('should filter content when searching for "New Year"', () => {
    // 1. Відвідуємо головну сторінку Ukrnet
    cy.visit('https://www.ukr.net/')
    // cy.wait(10000)
    // 2. У полі пошуку вводимо "New Year"
    cy.get('#search-input').type('New Year')
    cy.wait(1000)
    cy.get('#search-input').type('{enter}')
    cy.wait(5000)

    // Зачекайте на завантаження результатів пошуку
    cy.get('.gsc-resultsbox-visible').should('be.visible')

    // 3. Перевіряємо, чи відбулась фільтрація
    cy.get('.gsc-resultsbox-visible')
      .should('be.visible') // Перевірка видимості знайдених елементів
      .each(($item) => {
        expect($item.text().toLowerCase()).to.include('new year')
      }) // Перевірка, що кожен елемент має слово "New Year" у вмісті
  })
})
