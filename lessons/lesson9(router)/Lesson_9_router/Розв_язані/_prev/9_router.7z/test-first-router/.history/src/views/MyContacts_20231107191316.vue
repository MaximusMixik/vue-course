<template>
    <div>My Super Contacts</div>
</template>

<script>
const workers = {
    managers: {
        m1: {
            name: 'Ivanov',
            salary: 2132323,
        },
        w7: {
            name: 'Olga',
            salary: 67767546,
        },
    },
    editors: {
        f23: {
            name: 'Peter',
            salary: 677,
        },
        qqq: {
            name: 'Sara',
            salary: 67734,
        },
    },
}
export default {
    name: 'MyContacts',
}
</script>

<style lang="scss" scoped></style>
