<template>
    <div>My Super Contacts</div>
</template>

<script>
const workers = {
    managers: {
        m1: {
            name: 'Ivanov',
            salary: 2132323,
        },
        w7: {
            name: 'Olga',
            salary: 67767546,
        },
    },
}
export default {
    name: 'MyContacts',
}
</script>

<style lang="scss" scoped></style>
