<template>
    <div>{{ targetValue }}</div>
</template>

<script>
const sequrityCodesList = {
    phone: '1111',
    notebook: '0000',
    fridge: '7777',
}
export default {
    name: 'SuperSequrityPage',

    computed: {
        targetValue() {
            return this.$route.params.target
        },
        currentTargetCode() {
            if (this.targetValue in sequrityCodesList) return sequrityCodesList[this.targetValue]
            else return 'Sorry no code'
        },
    },
}
</script>

<style lang="scss" scoped></style>
