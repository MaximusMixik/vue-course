<template>
    <div>{{ targetValue }}</div>
</template>

<script>
// const sequrityCodesList={
//     phone:'1111',
//     notebook:'0000',
//     fridge:'7777'
// }
export default {
    name: 'SuperSequrityPage',

    computed: {
        targetValue() {
            return this.$route.params.target
        },
    },
}
</script>

<style lang="scss" scoped></style>
