<template>
    <div>My Super Contacts</div>
    <h1>{{ message }}</h1>
    <div>{{ currentCategory }}</div>
</template>

<script>
const workers = {
    managers: {
        m1: {
            name: 'Ivanov',
            salary: 2132323,
        },
        w7: {
            name: 'Olga',
            salary: 67767546,
        },
    },
    editors: {
        f23: {
            name: 'Peter',
            salary: 677,
        },
        qqq: {
            name: 'Sara',
            salary: 67734,
        },
    },
}
export default {
    name: 'MyContacts',

    computed: {
        currentCategory() {
            return this.$router.params.category
        },
        personId() {
            return this.$router.params.person_id
        },
        message() {
            // if (this.personId) {
            //     const person = workers[this.currentCategory][this.personId]
            //     return `${person.name} - ${person.salary}`
            // } else {
            //     return ` Category :${this.currentCategory}  `
            // }
            return 'Ok'
        },
    },
}
</script>

<style lang="scss" scoped></style>
