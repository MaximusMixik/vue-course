<template>
    <div>My Super Contacts</div>
</template>

<script>
const workers = {
    managers: {
        m1: {
            name: 'Ivanov',
            salary: 2132323,
        },
        w7: {
            name: 'Olga',
            salary: 67767546,
        },
    },
    editors: {
        f23: {
            name: 'Peter',
            salary: 677,
        },
        qqq: {
            name: 'Sara',
            salary: 67734,
        },
    },
}
export default {
    name: 'MyContacts',

    computed: {
        currentCategory() {
            return this.$router.params.category
        },
        personId() {
            return this.$router.params.person_id
        },
    },
}
</script>

<style lang="scss" scoped></style>
