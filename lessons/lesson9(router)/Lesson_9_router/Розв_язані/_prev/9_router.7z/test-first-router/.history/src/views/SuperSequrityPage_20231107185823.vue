<template>
    <div>0000 - super code</div>
</template>

<script>
// const sequrityCodesList={
//     phone:'1111',
//     notebook:'0000',
//     fridge:'7777'
// }
export default {
    name: 'SuperSequrityPage',
}
</script>

<style lang="scss" scoped></style>
