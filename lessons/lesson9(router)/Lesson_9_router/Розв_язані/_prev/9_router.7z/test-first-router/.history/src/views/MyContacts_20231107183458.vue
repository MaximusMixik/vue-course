<template>
    <div>My Super Contacts</div>
</template>

<script>
export default {
    name: 'MyContacts',
}
</script>

<style lang="scss" scoped></style>
