<template>
    <div>0000 - super code</div>
</template>

<script>
export default {
    name: 'SuperSequrityPage',
}
</script>

<style lang="scss" scoped></style>
