<template>
    <div class="home">
        <div @click="goToIvanov">Ivanov</div>
        <div @click="goToOlga">Olga</div>
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {
        goToIvanov() {
            this.$router.push({
                name: 'contacts',
                params: {
                    category: 'managers',
                    person_id: 'm1',
                },
            })
        },
        goToOlga() {
            this.$router.push({
                name: 'contacts',
                params: {
                    category: 'managers',
                    person_id: 'w7',
                },
            })
        },
    },
}
</script>
