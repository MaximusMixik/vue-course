<template>
    <div>
        <div>Користувач : {{ currentUser.name }}</div>
        <div>Стаж : {{ currentUser.experience }}</div>
        <div>Посада : {{ currentUser.position }}</div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'UserPage',

    data() {
        return {
            currentUser: {},
        }
    },

    computed: {
        ...mapGetters(['getUserById']),
        userId() {
            return this.$route.params.userId
        },
    },

    created() {
        this.currentUser = this.getUserById(this.userId)
    },
}
</script>

<style lang="scss" scoped></style>
