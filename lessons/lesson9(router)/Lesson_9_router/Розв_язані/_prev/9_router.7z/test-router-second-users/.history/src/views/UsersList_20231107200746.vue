<template>
    <div v-for="user in getUsersList" :key="user.id" @click="onUserClick(user.id)">
        {{ user.name }}
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'UsersList',

    computed: {
        ...mapGetters(['getUsersList']),
    },

    methods: {
        onUserClick(id) {
            this.$router.push({
                name: 'user',
                params: {
                    userId: id,
                },
            })
        },
    },
}
</script>

<style lang="scss" scoped></style>
