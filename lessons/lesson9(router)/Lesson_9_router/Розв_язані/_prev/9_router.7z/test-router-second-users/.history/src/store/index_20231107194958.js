import { createStore } from 'vuex'

export default createStore({
    state: {
        usersList: [
            { name: 'Олексій', experience: 5, position: 'Програміст' },
            { name: 'Ірина', experience: 3, position: 'Дизайнер' },
            { name: 'Марія', experience: 2, position: 'Тестер' },
            { name: 'Віталій', experience: 4, position: 'Менеджер' },
            { name: 'Андрій', experience: 6, position: 'Аналітик' },
        ],
    },
    getters: {
        getUsersList: (state) => state.usersList,
    },
    mutations: {},
    actions: {},
    modules: {},
})
