<template>
    <div>
        <div>
            Користувач :
            <input v-model="currentUser.name" type="text" />
        </div>
        <div>
            Стаж :
            <input v-model="currentUser.experience" type="number" />
        </div>
        <div>
            Посада :
            <input v-model="currentUser.position" type="text" />
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'UserPage',

    data() {
        return {
            currentUser: {},
        }
    },

    computed: {
        ...mapGetters(['getUserById']),
        userId() {
            return this.$route.params.userId
        },
    },

    created() {
        this.currentUser = this.getUserById(this.userId)
    },
}
</script>

<style lang="scss" scoped></style>
