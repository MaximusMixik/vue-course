<template>
    <div>
        <div>Користувач : {{ currentUser.name }}</div>
        <div>Стаж : {{ currentUser.experience }}</div>
        <div>Посада : {{ currentUser.position }}</div>
    </div>
</template>

<script>
export default {
    name: 'UserPage',

    data() {
        return {
            currentUser: {},
        }
    },
}
</script>

<style lang="scss" scoped></style>
