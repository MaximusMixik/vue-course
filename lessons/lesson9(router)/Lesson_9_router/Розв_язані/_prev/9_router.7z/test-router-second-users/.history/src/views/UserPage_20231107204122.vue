<template>
    <div>
        <div>
            Користувач :
            <input v-model="currentUser.name" type="text" />
        </div>
        <div>
            Стаж :
            <input v-model="currentUser.experience" type="number" />
        </div>
        <div>
            Посада :
            <input v-model="currentUser.position" type="text" />
        </div>
    </div>
    <button @click="onUpdate">Save</button>
    <button @click="onCancel">Cancel</button>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'UserPage',

    data() {
        return {
            currentUser: {},
        }
    },

    computed: {
        ...mapGetters(['getUserById']),
        userId() {
            return this.$route.params.userId
        },
    },

    created() {
        this.currentUser = this.getUserById(this.userId)
    },

    methods: {
        ...mapActions(['onUserUpdate']),
        onUpdate() {
            this.onUserUpdate(this.currentUser)
            this.$router.push({
                name: 'users',
            })
        },
        onCancel() {
            this.$router.push({
                name: 'users',
            })
        },
    },
}
</script>

<style lang="scss" scoped></style>
