<template>
    <div>
        {{ getUsersList }}
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'UsersList',

    computed: {
        ...mapGetters(['getUsersList']),
    },
}
</script>

<style lang="scss" scoped></style>
