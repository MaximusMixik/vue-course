import { createStore } from 'vuex'

export default createStore({
    state: {
        usersList: [
            { id: 1, name: 'Олексій', experience: 5, position: 'Програміст' },
            { id: 2, name: 'Ірина', experience: 3, position: 'Дизайнер' },
            { id: 3, name: 'Марія', experience: 2, position: 'Тестер' },
            { id: 4, name: 'Віталій', experience: 4, position: 'Менеджер' },
            { id: 5, name: 'Андрій', experience: 6, position: 'Аналітик' },
        ],
    },
    getters: {
        getUsersList: (state) => state.usersList,
        getUserById: (state) => {
            return (userId) => {
                return { ...state.usersList.find((user) => user.id == userId) }
            }
        },
    },
    mutations: {},
    actions: {},
    modules: {},
})
