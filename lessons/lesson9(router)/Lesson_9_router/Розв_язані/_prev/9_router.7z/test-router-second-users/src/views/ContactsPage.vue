<template>
    <div>
        <h1>Наша адреса:</h1>
        <h1>Найкраща, наймиліша, непереборна країна-Україна</h1>
    </div>
</template>

<script>
export default {
    name: 'ContactsPage',
}
</script>

<style lang="scss" scoped></style>
