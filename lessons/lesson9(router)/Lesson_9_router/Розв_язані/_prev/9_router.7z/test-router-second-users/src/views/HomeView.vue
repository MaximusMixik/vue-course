<template>
    <div class="home">Вітаємо на сайті</div>
</template>

<script>
export default {
    name: 'HomeView',
}
</script>
