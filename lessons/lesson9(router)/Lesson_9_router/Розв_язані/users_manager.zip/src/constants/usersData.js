export const employees = [
    { id: 1, name: 'Олександр Іванов', experience: 5, position: 'Менеджер з продажу' },
    { id: 2, name: 'Ольга Петрова', experience: 10, position: 'Керівник проекту' },
    { id: 3, name: 'Андрій Сидоренко', experience: 3, position: 'Програміст' },
    { id: 4, name: 'Наталія Смирнова', experience: 7, position: 'Маркетолог' },
    { id: 5, name: 'Дмитро Ковальчук', experience: 2, position: 'Дизайнер' },
    { id: 6, name: 'Ірина Кравченко', experience: 8, position: 'Аналітик' },
    { id: 7, name: 'Микола Гончар', experience: 12, position: 'Фінансовий директор' },
    { id: 8, name: 'Юлія Бондаренко', experience: 4, position: 'SEO-спеціаліст' },
    { id: 9, name: 'Василь Левченко', experience: 6, position: 'Системний адміністратор' },
    { id: 10, name: 'Марія Васильєва', experience: 9, position: 'HR-менеджер' },
]
