<template>
  <div>
    <gane-cell />
  </div>
</template>

<script>
import GaneCell from './GaneCell.vue'
export default {
  components: { GaneCell },
}
</script>

<style lang="scss" scoped></style>
