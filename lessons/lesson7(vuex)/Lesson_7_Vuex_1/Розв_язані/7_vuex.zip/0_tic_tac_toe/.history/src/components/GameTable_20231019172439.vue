<template>
  <div v-for="(row, index) in field" :key="index" class="row">
    <gane-cell
      v-for="(cell, ind) in row"
      :key="ind"
      :status-value="cell"
      @select="$emit('select', { row: index, col: ind })"
    />
  </div>
  <div v-for="(h, ind) in hist" :key="ind">
    <button @click="$emit('hist', ind)">Step {{ ind }}</button>
  </div>
</template>

<script>
import GaneCell from './GaneCell.vue'

export default {
  components: { GaneCell },

  props: {
    field: {
      type: Array,
      default: () => [],
    },
    hist: {
      type: Array,
      default: () => [],
    },
  },
}
</script>

<style lang="css" scoped>
.row {
  display: flex;
  align-items: center;
}
</style>
