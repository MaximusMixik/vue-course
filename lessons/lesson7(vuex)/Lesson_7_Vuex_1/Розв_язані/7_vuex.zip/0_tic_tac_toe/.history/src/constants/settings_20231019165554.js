export const imagesLinks = {
  circle:
    'https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Red_circle.svg/2048px-Red_circle.svg.png',
  cross: 'https://cdn.pixabay.com/photo/2022/03/23/02/48/cross-7086307_640.png',
}
