<template>
  <div v-for="rowIndex in 3" :key="rowIndex" class="cell-row">
    <div v-for="colIndex in 3" :key="colIndex">
      <game-cell :status="0" />
    </div>
  </div>
</template>

<script>
import GameCell from './GameCell.vue'
export default {
  name: 'GameTable',

  components: {
    GameCell,
  },

  props: {
    gameField: {
      type: Array,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped>
.cell-row {
  display: flex;
}
</style>
