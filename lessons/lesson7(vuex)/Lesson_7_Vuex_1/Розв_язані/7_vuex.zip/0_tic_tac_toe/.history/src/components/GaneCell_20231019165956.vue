<template>
  <div class="cell">
    <img :src="imgSrc" alt="" />
  </div>
</template>

<script>
import { imagesLinks } from '../constants/settings'

export default {
  name: 'GameCell',
  statusValue: {
    type: String,
    default: null,
  },

  computed: {
    imgSrc() {
      return this.statusValue ? imagesLinks[this.statusValue] : null
    },
  },
}
</script>

<style lang="css" scoped>
.cell {
  display: inline-block;
  border: 2px solid black;
  width: 50px;
  height: 50px;
  margin: 20px;
}
</style>
