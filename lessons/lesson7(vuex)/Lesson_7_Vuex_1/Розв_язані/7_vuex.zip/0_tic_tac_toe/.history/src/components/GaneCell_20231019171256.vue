<template>
  <div class="cell">
    <img v-if="imgSrc" :src="imgSrc" class="image" />
  </div>
</template>

<script>
import { imagesLinks } from '../constants/settings'

export default {
  name: 'GameCell',

  props: {
    statusValue: {
      type: Number,
      default: null,
    },
  },

  computed: {
    imgSrc() {
      return this.statusValue
        ? imagesLinks[Object.keys(this.statusValue - 1)]
        : ''
    },
  },
}
</script>

<style lang="css" scoped>
.cell {
  display: inline-block;
  border: 2px solid black;
  width: 50px;
  height: 50px;
  margin: 20px;
}
.image {
  width: 50px;
  height: 50px;
}
</style>
