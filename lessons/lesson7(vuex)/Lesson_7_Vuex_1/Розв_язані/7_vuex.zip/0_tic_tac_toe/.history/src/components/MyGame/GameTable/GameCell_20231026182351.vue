<template>
  <div></div>
</template>

<script>
export default {
  name: 'GameCell',

  props: {
    status: {
      type: Number,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped></style>
