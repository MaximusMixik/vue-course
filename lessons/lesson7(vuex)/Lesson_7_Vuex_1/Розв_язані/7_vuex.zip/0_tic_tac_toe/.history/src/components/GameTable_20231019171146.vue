<template>
  <div v-for="(row, index) in field" :key="index" class="">
    <div v-for="(cell, ind) in row" :key="ind" class="row">
      <gane-cell :status-value="cell" />
    </div>
  </div>
</template>

<script>
import GaneCell from './GaneCell.vue'

export default {
  components: { GaneCell },

  props: {
    field: {
      type: Array,
      default: () => [],
    },
  },
}
</script>

<style lang="css" scoped>
.row {
  display: flex;
}
</style>
