<template>
  <game-table :game-field="gameField" @cell-select="onCellSelect" />
  <div>
    <button
      v-for="(step, index) in history"
      :key="index"
      @click="gotoStep(index)"
    >
      Step {{ index }}
    </button>
  </div>
</template>

<script>
import GameTable from './GameTable'
export default {
  name: 'MyGame',

  components: {
    GameTable,
  },

  data() {
    //0-вільна клітинка, 1-нолік, 2-хрестик
    return {
      gameField: [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
      ],
      // 1 -нолік, 2-хрестик
      currentSign: null,

      history: [],
    }
  },

  methods: {
    gotoStep(index) {
      this.gameField = this.history[index].gameField
      this.currentSign = this.history[index].currentSign
      this.history.splice(index, this.history.length - index)
    },
    addToHistory() {
      this.history.push({
        gameField: JSON.parse(JSON.stringify(this.gameField)),
        currentSign: this.currentSign,
      })
    },
    onCellSelect({ rowIndex, colIndex }) {
      this.addToHistory()
      this.gameField[rowIndex][colIndex] = this.currentSign
      // if(this.currentSign===1) this.currentSign=2
      // else this.currentSign=1
      this.currentSign = 3 - this.currentSign
    },
  },

  created() {
    this.currentSign = 1 + Math.floor(Math.random(2))
  },
}
</script>

<style lang="scss" scoped></style>
