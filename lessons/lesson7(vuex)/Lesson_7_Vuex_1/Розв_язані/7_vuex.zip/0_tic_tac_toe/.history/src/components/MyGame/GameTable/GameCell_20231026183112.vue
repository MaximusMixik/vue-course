<template>
  <div>
    <img v-if="status" :src="currentImgSrc" alt="" />
  </div>
</template>

<script>
import { imagesLinks } from '@/constants/settings'
export default {
  name: 'GameCell',

  props: {
    status: {
      type: Number,
      required: true,
    },
  },

  computed: {
    currentImgSrc() {
      switch (this.status) {
        case 1:
          return imagesLinks.circle
        case 2:
          return imagesLinks.cross
      }
      return null
    },
  },
}
</script>

<style lang="scss" scoped></style>
