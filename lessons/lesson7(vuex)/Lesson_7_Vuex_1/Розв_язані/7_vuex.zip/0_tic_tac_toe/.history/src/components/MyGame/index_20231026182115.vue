<template>
  <game-table :game-field="gameField" />
</template>

<script>
import GameTable from './GameTable'
export default {
  name: 'MyGame',

  components: {
    GameTable,
  },

  data() {
    //0-вільна клітинка, 1-коло, 2-хрестик
    return {
      gameField: [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
      ],
    }
  },
}
</script>

<style lang="scss" scoped></style>
