<template>
  <div>
    <game-cell :status="1" />
  </div>
</template>

<script>
import GameCell from './GameCell.vue'
export default {
  name: 'GameTable',

  components: {
    GameCell,
  },

  props: {
    gameField: {
      type: Array,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped></style>
