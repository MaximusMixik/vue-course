<template>
  <game-table :game-field="gameField" @cell-select="onCellSelect" />
</template>

<script>
import GameTable from './GameTable'
export default {
  name: 'MyGame',

  components: {
    GameTable,
  },

  data() {
    //0-вільна клітинка, 1-коло, 2-хрестик
    return {
      gameField: [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
      ],
      currentSign: null,

      history: [],
    }
  },

  methods: {
    addToHistory() {
      this.history.push({
        gameField: this.gameField,
        currentSign: this.currentSign,
      })
    },
    onCellSelect({ rowIndex, colIndex }) {
      this.addToHistory()
      this.gameField[rowIndex][colIndex] = this.currentSign
      // if(this.currentSign===1) this.currentSign=2
      // else this.currentSign=1
      this.currentSign = 3 - this.currentSign
    },
  },

  created() {
    this.currentSign = 1 + Math.floor(Math.random(2))
  },
}
</script>

<style lang="scss" scoped></style>
