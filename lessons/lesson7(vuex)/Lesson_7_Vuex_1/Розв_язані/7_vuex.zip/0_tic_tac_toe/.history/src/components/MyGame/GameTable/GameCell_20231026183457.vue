<template>
  <div class="cell">
    <img v-if="status" :src="currentImgSrc" class="cell-image" />
  </div>
</template>

<script>
import { imagesLinks } from '@/constants/settings'
export default {
  name: 'GameCell',

  props: {
    status: {
      type: Number,
      required: true,
    },
  },

  computed: {
    currentImgSrc() {
      switch (this.status) {
        case 1:
          return imagesLinks.circle
        case 2:
          return imagesLinks.cross
      }
      return null
    },
  },
}
</script>

<style lang="css" scoped>
.cell {
  width: 100px;
  height: 100px;
  margin: 15px;
  border: 2px solid black;
}
.cell-image {
  width: 100px;
  height: 100px;
}
</style>
