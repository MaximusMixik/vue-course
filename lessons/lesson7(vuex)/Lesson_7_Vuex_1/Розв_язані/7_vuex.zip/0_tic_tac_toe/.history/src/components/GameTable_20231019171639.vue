<template>
  <div v-for="(row, index) in field" :key="index" class="row">
    <gane-cell
      v-for="(cell, ind) in row"
      :key="ind"
      :status-value="cell"
      @select="$emit('select', { row: index, col: ind })"
    />
  </div>
</template>

<script>
import GaneCell from './GaneCell.vue'

export default {
  components: { GaneCell },

  props: {
    field: {
      type: Array,
      default: () => [],
    },
  },
}
</script>

<style lang="css" scoped>
.row {
  display: flex;
  align-items: center;
}
</style>
