<template>
  <div></div>
</template>

<script>
export default {
  name: 'MyGame',

  data() {
    return {
      gameField: [
        [-1, 1, -1],
        [0, -1, -1],
        [-1, -1, -1],
      ],
    }
  },
}
</script>

<style lang="scss" scoped></style>
