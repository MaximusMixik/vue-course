<template>
  <div>
    {{ gameField }}
  </div>
</template>

<script>
export default {
  name: 'GameTable',

  props: {
    gameField: {
      type: Array,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped></style>
