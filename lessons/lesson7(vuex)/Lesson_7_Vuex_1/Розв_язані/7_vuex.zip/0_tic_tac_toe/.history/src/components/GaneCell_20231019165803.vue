<template>
  <div class="cell"></div>
</template>

<script>
export default {
  name: 'GameCell',
  statusValue: {
    type: Number,
    default: null,
  },
}
</script>

<style lang="css" scoped>
.cell {
  display: inline-block;
  border: 2px solid black;
  width: 50px;
  height: 50px;
  margin: 20px;
}
</style>
