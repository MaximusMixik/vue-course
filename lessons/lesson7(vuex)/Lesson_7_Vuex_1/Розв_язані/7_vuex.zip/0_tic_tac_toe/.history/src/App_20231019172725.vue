<template>
  <game-table :field="ff" @select="select" @hist="onHist" :hist="hist" />
</template>

<script>
import GameTable from './components/GameTable.vue'

export default {
  name: 'App',
  components: {
    GameTable,
  },

  data() {
    return {
      ff: [
        [0, 0, 0],
        [0, 0, 0],
        [1, 0, 2],
      ],
      hist: [],
      currentVal: 1,
    }
  },

  methods: {
    select(cell) {
      this.hist.push(JSON.parse(JSON.stringify(this.ff)))

      this.ff[cell.row][cell.col] = this.currentVal
      this.currentVal = this.currentVal + 1
      if (this.currentVal === 3) this.currentVal = 1
    },
    onHist(ind) {
      this.tt = this.hist[ind]
      this.splice(ind, this.hist.length - ind)
    },
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
