<template>
  <div></div>
</template>

<script>
export default {
  name: 'MyGame',

  data() {
    return {
      gameField: [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
      ],
    }
  },
}
</script>

<style lang="scss" scoped></style>
