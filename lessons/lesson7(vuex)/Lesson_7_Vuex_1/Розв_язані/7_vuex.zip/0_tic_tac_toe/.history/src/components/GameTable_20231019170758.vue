<template>
  <div v-for="(row, index) in field" :key="index">
    <div v-for="(cell, ind) in row" :key="ind">
      <gane-cell />
    </div>
  </div>
</template>

<script>
import GaneCell from './GaneCell.vue'

export default {
  components: { GaneCell },

  props: {
    field: {
      type: Array,
      default: () => [],
    },
  },
}
</script>

<style lang="scss" scoped></style>
