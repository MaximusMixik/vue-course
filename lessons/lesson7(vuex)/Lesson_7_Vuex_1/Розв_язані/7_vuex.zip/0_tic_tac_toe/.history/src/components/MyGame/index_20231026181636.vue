<template>
  <div></div>
</template>

<script>
export default {
  name: 'MyGame',

  data() {
    //0-вільна клітинка, 1-коло, 2-хрестик
    return {
      gameField: [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
      ],
    }
  },
}
</script>

<style lang="scss" scoped></style>
