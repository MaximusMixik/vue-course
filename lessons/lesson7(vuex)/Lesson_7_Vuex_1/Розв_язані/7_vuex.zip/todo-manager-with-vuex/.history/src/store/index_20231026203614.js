import { createStore } from 'vuex'

export default createStore({
    //місце збереження даних
    state: {
        tasksList: [],
    },
    //обчислювальні властивості
    getters: {},
    //фукнції, які можуть змінюувати state
    mutations: {},
    //функції, які виклиаємо з компонентів
    actions: {},
})
