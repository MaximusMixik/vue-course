<template>
  <todo-form @add="addTask" />
  <todo-list :tasks-list="todoListData" @done="onDone" @delete="onDelete" />
</template>

<script>
import TodoForm from './TodoForm.vue'
import TodoList from './TodoList.vue'
export default {
  name: 'TodoManager',

  components: { TodoForm, TodoList },

  data() {
    return {
      todoListData: [],
    }
  },

  methods: {
    addTask(taskData) {
      this.todoListData.push({
        id: new Date().getTime(),
        isDone: false,
        ...taskData,
      })
    },
    onDone(taskId) {
      this.todoListData.find((task) => task.id === taskId).isDone = true
    },
    onDelete(taskId) {
      this.todoListData = this.todoListData.filter((task) => task.id !== taskId)
    },
  },
}
</script>
TodoForm

<style lang="scss" scoped></style>
