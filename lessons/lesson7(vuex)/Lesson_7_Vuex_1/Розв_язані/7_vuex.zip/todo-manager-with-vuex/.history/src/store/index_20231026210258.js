import { createStore } from 'vuex'

export default createStore({
    //місце збереження даних
    state: {
        tasksList: [],
    },
    //обчислювальні властивості
    getters: {
        todoTasksList: ({ tasksList }) => tasksList,
    },
    //фукнції, які можуть змінюувати state
    mutations: {
        addTask(state, task) {
            state.tasksList.push(task)
        },
        setTaskAsDone(state, taskId) {
            const taskObj = state.tasksList.find((task) => task.id === taskId)
            taskObj.isDone = true
        },
        deleteTaskById(state, taskId) {
            state.tasksList = state.tasksList.filter((task) => task.id !== taskId)
        },
    },
    //функції, які виклиаємо з компонентів
    actions: {
        addNewTask({ commit }, taskData) {
            commit('addTask', {
                id: new Date().getTime(),
                ...taskData,
            })
        },
        setDone({ commit }, taskId) {
            commit('setTaskAsDone', taskId)
        },
        deleteTask({ commit }, taskId) {
            commit('deleteTaskById', taskId)
        },
    },
})
