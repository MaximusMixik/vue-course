import { createStore } from 'vuex'

export default createStore({
    state: {
        userName: 'Ivan',
        age: 21,
    },
    getters: {
        age10(state) {
            return state.age * 10
        },
        age2: ({ age }) => age * 2,
    },
    mutations: {
        add1(state) {
            state.age += 1
        },
    },
    actions: {},
})
