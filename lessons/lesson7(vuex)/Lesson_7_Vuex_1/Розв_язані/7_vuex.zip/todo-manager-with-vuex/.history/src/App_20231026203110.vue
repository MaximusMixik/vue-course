<template>
    <div>{{ userName }} -{{ age }}</div>
    <div>
        {{ age10 }}
    </div>
    <div>
        {{ age2 }}
    </div>
    <button @click="onAdd">Add 1</button>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'

export default {
    name: 'App',

    computed: {
        ...mapState(['userName', 'age']),
        ...mapGetters(['age10', 'age2']),
    },

    methods: {
        ...mapActions(['addAge1']),

        onAdd() {
            // this.$store.commit('add1')
            this.addAge1()
        },
    },
}
</script>

<style lang="scss">
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}
</style>
