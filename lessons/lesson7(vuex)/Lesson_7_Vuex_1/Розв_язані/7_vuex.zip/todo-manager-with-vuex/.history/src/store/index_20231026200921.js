import { createStore } from 'vuex'

export default createStore({
    state: {
        userName: 'Ivan',
        age: 21,
    },
    getters: {
        age10(state) {
            return state.age * 10
        },
    },
    mutations: {},
    actions: {},
    modules: {},
})
