import { createStore } from 'vuex'

export default createStore({
    //місце збереження даних
    state: {
        tasksList: [],
    },
    //обчислювальні властивості
    getters: {},
    //фукнції, які можуть змінюувати state
    mutations: {
        addTask(state, task) {
            state.tasksList.push(task)
        },
    },
    //функції, які виклиаємо з компонентів
    actions: {},
})
