import { createStore } from 'vuex'

export default createStore({
    state: {
        userName: 'Ivan',
        age: 21,
    },
    getters: {},
    mutations: {},
    actions: {},
    modules: {},
})
