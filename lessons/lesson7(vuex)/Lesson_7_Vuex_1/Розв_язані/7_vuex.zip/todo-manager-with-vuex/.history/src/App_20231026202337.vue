<template>
    <div>{{ userName }} -{{ age }}</div>
    <div>
        {{ $store.getters.age10 }}
    </div>
    <div>
        {{ $store.getters.age2 }}
    </div>
    <button @click="onAdd">Add 1</button>
</template>

<script>
import { mapState } from 'vuex'

export default {
    name: 'App',

    computed: {
        ...mapState(['userName', 'age']),
    },

    methods: {
        onAdd() {
            // this.$store.commit('add1')
            this.$store.dispatch('addAge1')
        },
    },
}
</script>

<style lang="scss">
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}
</style>
