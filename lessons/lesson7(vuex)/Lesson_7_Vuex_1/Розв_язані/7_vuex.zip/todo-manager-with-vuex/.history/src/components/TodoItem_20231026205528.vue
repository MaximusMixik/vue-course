<template>
    <div class="task-container">
        <div>{{ task.title }} - {{ task.priority }}</div>
        <div>
            <button v-if="!isDone" @click="setDone(task.id)">Done</button>
            <button @click="deleteTask(task.id)">Delete</button>
        </div>
    </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
    name: 'CustomInput',

    props: {
        task: {
            type: Object,
            required: true,
        },
    },

    computed: {
        isDone() {
            return this.task.isDone
        },
    },

    methods: {
        ...mapActions(['setDone', 'deleteTask']),
    },
}
</script>

<style lang="css" scoped>
.task-container {
    width: 300px;
    display: flex;
    justify-content: space-between;
    border: 2px solid black;
    margin: 10px;
    padding: 5px;
}
</style>
