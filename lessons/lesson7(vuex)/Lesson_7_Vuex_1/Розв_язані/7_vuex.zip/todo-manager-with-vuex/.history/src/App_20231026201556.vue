<template>
    <div>
        {{ $store.state.userName }}
    </div>
    <div>
        {{ $store.getters.age10 }}
    </div>
    <div>
        {{ $store.getters.age2 }}
    </div>
    <button @click="onAdd">Add 1</button>
</template>

<script>
export default {
    name: 'App',

    methods: {
        onAdd() {
            // this.$store.commit('add1')
            this.$store.dipatch('addAge1')
        },
    },
}
</script>

<style lang="scss">
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}
</style>
