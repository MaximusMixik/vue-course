<template>
  <todo-manager />
</template>

<script>
import TodoManager from './components/TodoManager.vue'

export default {
  name: 'App',

  components: {
    TodoManager,
  },
}
</script>

<style></style>
