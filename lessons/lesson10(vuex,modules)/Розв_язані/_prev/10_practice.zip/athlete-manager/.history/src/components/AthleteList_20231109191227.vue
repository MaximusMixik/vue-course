<template>
    <div>
        <div v-for="athlete in athleteList" :key="athlete.id" class="">
            <div>{{ athlete.name }}</div>
            <div>{{ actionButton }}</div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'AthleteList',

    props: {
        athleteList: {
            type: Array,
            default: () => [],
        },
        isSelected: {
            type: Boolean,
            default: false,
        },
    },

    computed: {
        actionButton() {
            return this.isSelected ? '-' : '+'
        },
    },
}
</script>

<style lang="scss" scoped></style>
