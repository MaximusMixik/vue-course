import { createStore } from "vuex";

export default createStore({
  state: {
    generalList:[
      {
        id: 1,
        name: 'Андрій',
    },
    {
        id: 2,
        name: 'Олена',
    },
    {
        id: 3,
        name: 'Сергій',
    },
    {
        id: 4,
        name: 'Василь',
    },
    {
        id: 5,
        name: 'Баба Галя',
    }
    ],
    notSelectedListId:[1,3,5],
    selectedListId:[]
  },
  getters: {
    getNotSelectedList: state=>state.generalList.filter(athlete=>state.notSelectedListId.includes(athlete.id)),
    getSelectedList:state=>()
  },
  mutations: {},
  actions: {},
  modules: {},
});
