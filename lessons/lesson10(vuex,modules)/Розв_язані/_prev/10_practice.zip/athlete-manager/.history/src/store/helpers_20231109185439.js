export function moveElementBetweenArrays(element, listToRemoveElement, listToAddElement) {
    listToRemoveElement = listToRemoveElement.filter((item) => item !== element)
    listToAddElement = [...listToAddElement, element]
}
