<template>
    <div></div>
</template>

<script>
export default {
    name: 'AthleteList',

    props: {
        athleteList: {
            type: Array,
            default: () => [],
        },
        isSelected: {
            type: Boolean,
            default: false,
        },
    },
}
</script>

<style lang="scss" scoped></style>
