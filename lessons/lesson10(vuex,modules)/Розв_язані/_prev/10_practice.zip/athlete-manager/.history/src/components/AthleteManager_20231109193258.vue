<template>
    <div>
        <athlete-list title="Загальний список" :athlete-list="getNotSelectedList" />
        <athlete-list title="Список обраних" :athlete-list="getSelectedList" is-selected />
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import AthleteList from './AthleteList.vue'

export default {
    name: 'AthleteManager',
    components: {
        AthleteList,
    },

    computed: {
        ...mapGetters(['getNotSelectedList', 'getSelectedList']),
    },
}
</script>

<style lang="scss" scoped></style>
