<template>
    <div>
        <athlete-list title="Загальний список" :athlete-list="getNotSelectedList" @select="selectAthlete" />
        <athlete-list title="Список обраних" :athlete-list="getSelectedList" is-selected @select="deselectAthlete" />
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import AthleteList from './AthleteList.vue'

export default {
    name: 'AthleteManager',
    components: {
        AthleteList,
    },

    computed: {
        ...mapGetters(['getNotSelectedList', 'getSelectedList']),
    },

    methods: {
        ...mapActions(['selectAthlete', 'deselectAthlete']),
    },
}
</script>

<style lang="scss" scoped></style>
