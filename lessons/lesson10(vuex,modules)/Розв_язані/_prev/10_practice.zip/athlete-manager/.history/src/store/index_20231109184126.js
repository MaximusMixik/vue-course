import { createStore } from "vuex";

export default createStore({
  state: {
    generalList:[
      {
        id: 1,
        name: 'Андрій',
    },
    {
        id: 2,
        name: 'Олена',
    },
    {
        id: 3,
        name: 'Сергій',
    },
    {
        id: 4,
        name: 'Василь',
    },
    {
        id: 5,
        name: 'Баба Галя',
    }
    ],
    notSelectedListId:[],
    selectedListId:[]
  },
  getters: {
    getNotSelectedList: state=>{

    }
    getSelectedList
  },
  mutations: {},
  actions: {},
  modules: {},
});
