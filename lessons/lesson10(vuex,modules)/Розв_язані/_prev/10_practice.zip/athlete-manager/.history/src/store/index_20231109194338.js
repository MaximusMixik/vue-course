import { createStore } from 'vuex'
import { athletesList } from '@/data/9_athletes'
// import { moveElementBetweenArrays } from './helpers'
export default createStore({
    state: {
        generalList: [],
        notSelectedListId: [],
        selectedListId: [],
    },
    getters: {
        getNotSelectedList: (state) =>
            state.generalList.filter((athlete) => state.notSelectedListId.includes(athlete.id)),
        getSelectedList: (state) => state.generalList.filter((athlete) => state.selectedListId.includes(athlete.id)),
    },
    mutations: {
        selectAthleteMutation(state, athleteId) {
            state.notSelectedListId = state.notSelectedListId.filter((id) => id !== athleteId)
            state.selectedListId.push(athleteId)

            // const resObj = moveElementBetweenArrays(athleteId, state.notSelectedListId, state.selectedListId)
            // state.notSelectedListId = resObj.newListToRemoveElement
            // state.selectedListId = resObj.newListToAddElement
        },
        deselectAthleteMutation(state, athleteId) {
            state.selectedListId = state.selectedListId.filter((id) => id !== athleteId)
            state.notSelectedListId.push(athleteId)
        },
        initDataMutation(state, initData) {
            state.generalList = initData
            state.notSelectedListId = initData.map((item) => item.id)
        },
    },
    actions: {
        selectAthlete({ commit }, athleteId) {
            commit('selectAthleteMutation', athleteId)
        },
        deselectAthlete({ commit }, athleteId) {
            commit('deselectAthleteMutation', athleteId)
        },
        initData({ commit }) {
            commit('initDataMutation')
        },
    },
    modules: {},
})
