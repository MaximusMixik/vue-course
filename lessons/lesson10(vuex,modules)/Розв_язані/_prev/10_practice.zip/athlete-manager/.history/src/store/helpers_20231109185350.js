export function moveElementBetweenArrays(element, listToRemoveElement, listToAddElementr) {
    listToRemoveElement = listToRemoveElement.filter((item) => item !== element)
    listToAddElementr.push(element)
}
