<template>
    <athlete-list title="test" :athlete-list="$store.getters.getNotSelectedList" />
</template>

<script>
import AthleteList from './components/AthleteList.vue'

export default {
    name: 'App',
    components: {
        AthleteList,
    },
}
</script>

<style lang="scss">
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}
</style>
