export const athletesList = [
  {
    id: 1,
    name: 'Андрій',
  },
  {
    id: 2,
    name: 'Олена',
  },
  {
    id: 3,
    name: 'Сергій',
  },
  {
    id: 4,
    name: 'Василь',
  },
  {
    id: 5,
    name: 'Баба Галя',
  },
]
