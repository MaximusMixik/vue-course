export const shopsList = [
    {
        id: 1,
        title: 'Головне відділення',
    },
    {
        id: 2,
        title: 'Оптовий',
    },
    {
        id: 3,
        title: 'Магазин №1',
    },
    {
        id: 4,
        title: 'Магазин №2',
    },
    {
        id: 5,
        title: 'Магазин №3',
    },
]
export const productsList = [
    {
        id: 10,
        title: 'Телефони',
    },
    {
        id: 12,
        title: 'Телевізори',
    },
    {
        id: 13,
        title: 'Мікрохвильові печі',
    },
    {
        id: 14,
        title: 'Пральні машини',
    },
    {
        id: 15,
        title: 'Фени',
    },
    {
        id: 16,
        title: 'Чайники',
    },
]
