<template>
    <div>
        <input type="text" />
    </div>
</template>

<script>
export default {
    props: {
        moduleValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: String,
            default: () => ({}),
        },
    },
}
</script>

<style lang="scss" scoped></style>
