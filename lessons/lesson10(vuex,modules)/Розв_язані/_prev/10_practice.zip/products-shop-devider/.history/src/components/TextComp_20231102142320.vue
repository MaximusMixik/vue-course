<template>
    <div>
        <input ref="inp" v-model="localValue" type="text" @keydown="onkeyDown" @click="onClick" />
    </div>
</template>

<script>
export default {
    props: {
        modelValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: Object,
            default: () => ({}),
        },
    },
    emits: ['update:modelValue'],

    data() {
        return {
            localValue: '',
        }
    },

    watch: {
        localValue(newValue, oldValue) {
            if (newValue.length === 2 && oldValue.length === 1) {
                newValue += '/'
                this.localValue = newValue
            } else if (oldValue.length === 3 && newValue.length === 2) {
                newValue = newValue[0]
                this.localValue = newValue
            }
            this.$emit('update:modelValue', newValue)
        },
    },

    methods: {
        onClick() {
            this.$refs.inp.selectionStart = this.modelValue.length
        },
        onkeyDown(e) {
            const isDigit = e.key >= '0' && e.key <= '9'
            const isBackspace = e.key === 'Backspace'
            if (!(isDigit || isBackspace)) {
                e.preventDefault()
                return
            }

            if (!isBackspace && this.localValue.length === 5) {
                e.preventDefault()
                return
            }
        },
    },
}
</script>

<style lang="scss" scoped></style>
