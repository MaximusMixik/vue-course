<template>
    <div>
        <text-comp v-model="modText" />
        <h1>modText</h1>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import TextComp from './components/TextComp.vue'
export default {
    name: 'App',

    components: {
        TextComp,
    },

    data() {
        return {
            modText: '',
        }
    },

    computed: {
        ...mapGetters(['getCount']),
    },

    methods: {
        ...mapActions(['incrementCount', 'decrementCount']),
    },
}
</script>

<style lang="scss"></style>
