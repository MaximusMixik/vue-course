<template>
    <!-- Властивість з state -->
    <div>{{ count }}</div>
    <!-- Звертання до геттера -->

    <div>{{ $store.getters.doubleCount }}</div>
    <div>
        <button @click="$store.dispatch('incrementCount')">Add</button>
        <button @click="$store.dispatch('decrementCount')">Subtract</button>
    </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
    name: 'App',

    computed: {
        ...mapState(['count']),
    },

    mounted() {
        console.log(this.$store)
    },
}
</script>

<style lang="scss"></style>
