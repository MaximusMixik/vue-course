import { createStore } from 'vuex'

// Create a new store instance.
const store = createStore({
    state() {
        return {}
    },
    getters: {},
    mutations: {},
    actions: {},
})
export default store
