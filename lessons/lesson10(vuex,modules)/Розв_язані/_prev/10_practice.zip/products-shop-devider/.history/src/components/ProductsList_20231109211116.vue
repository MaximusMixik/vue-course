<template>
    <h1>{{ title }}</h1>
    <div class="products-container">
        <div
            v-for="product in getProductsList"
            :key="product.id"
            class="product"
            :class="{
                'is-selected': isSelected(product.id),
            }"
            @click="selectProduct(product.id)"
        >
            {{ product.title }}
        </div>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'ProductsList',
    props: {
        title: {
            type: String,
            default: 'Список товарів',
        },
    },

    computed: {
        ...mapGetters(['getProductsList', 'getSelectedShopProducts']),
    },

    methods: {
        ...mapActions(['selectProduct']),
        isSelected(productId) {
            return this.getSelectedShopProducts.includes(productId)
        },
    },
}
</script>

<style lang="scss" scoped>
.products-container {
    border: 2px solid black;
    padding: 5px;
    .product {
        margin: 5px;
        cursor: pointer;
    }
    .is-selected {
        background-color: aqua;
    }
}
</style>
