<template>
    <shops-list />
    <products-list />
</template>

<script>
import { mapActions } from 'vuex'
import ShopsList from '@/components/ShopsList.vue'
import ProductsList from '@/components/ProductsList.vue'

export default {
    name: 'App',

    components: {
        ShopsList,
        ProductsList,
    },

    data() {
        return {}
    },

    computed: {},

    created() {
        this.loadData()
    },

    methods: {
        ...mapActions(['loadData']),
    },
}
</script>

<style lang="scss"></style>
