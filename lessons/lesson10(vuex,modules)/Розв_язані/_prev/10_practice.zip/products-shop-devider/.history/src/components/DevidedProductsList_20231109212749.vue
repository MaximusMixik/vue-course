<template>
    <h1>{{ titile }}</h1>
    <div>
        <div v-for="selection in getSelectedProducts" :key="selection.shopId">
            <h3>{{ getShopById(selection.shopId).title }}</h3>
            <div v-for="prodId in selection.productsIdList" :key="prodId">
                {{ getProductById(prodId) }}
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'DevidedProductsList',

    props: {
        title: {
            type: String,
            default: 'Розподілені товари',
        },
    },

    computed: {
        ...mapGetters(['getSelectedProducts', 'getShopById', 'getProductById']),
    },
}
</script>

<style lang="scss" scoped></style>
