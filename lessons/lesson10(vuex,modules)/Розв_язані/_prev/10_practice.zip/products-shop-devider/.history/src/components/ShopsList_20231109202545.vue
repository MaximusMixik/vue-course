<template>
    <div>
        <h1>{{ title }}</h1>
        <div>
            <div v-for="shop in getShopsList" :key="shop.id">
                {{ shop.title }}
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'ShopsList',

    props: {
        title: {
            type: String,
            default: 'Відділення',
        },
    },

    computed: {
        ...mapGetters(['getShopsList']),
    },
}
</script>

<style lang="scss" scoped></style>
