<template>
    <h1>{{ titile }}</h1>
    <div>
        <div v-for="selection in getSelectedProducts" :key="selection.shopId"></div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'DevidedProductsList',

    props: {
        title: {
            type: String,
            default: 'Розподілені товари',
        },
    },

    computed: {
        ...mapGetters(['getSelectedProducts']),
    },
}
</script>

<style lang="scss" scoped></style>
