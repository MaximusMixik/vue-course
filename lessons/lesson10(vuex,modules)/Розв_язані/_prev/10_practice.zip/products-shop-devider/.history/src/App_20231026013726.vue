<template>
    <div>{{ getCount }}</div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'App',

    computed: {
        ...mapGetters(['getCount']),
    },
}
</script>

<style lang="scss"></style>
