import { createStore } from 'vuex'

// Create a new store instance.
const store = createStore({
    state() {
        return {
            shopsList: [],
            productsList: [],
            selectedProducts: [],
            // {
            //    shopId:2,
            //    productsIdList:[3,5,2]
            // }
            // ],
            selectedShopId: null,
        }
    },
    getters: {},
    mutations: {
        setData(state, { shopsList, productsList }) {
            state.shopsList = shopsList
            state.productsList = productsList
        },
    },
    actions: {
        // loadData()
    },
})
export default store

// getters
// getShopsList
// getProductsList
// getSelectedProducts
// actions
// selectShop(id)
// selectProduct(id)
// removeProduct(shopId, productId)
//
