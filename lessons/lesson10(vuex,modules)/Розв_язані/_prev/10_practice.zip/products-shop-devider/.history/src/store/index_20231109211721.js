import { createStore } from 'vuex'
import { shopsList, productsList } from '@/data/12_shops'
// Create a new store instance.
const store = createStore({
    state() {
        return {
            shopsList: [],
            productsList: [],
            selectedProducts: [
                {
                    shopId: 2,
                    productsIdList: [10, 12],
                },
            ],
            selectedShopId: null,
        }
    },
    getters: {
        getShopsList: (state) => state.shopsList,
        getProductsList: ({ productsList }) => productsList,
        getSelectedShopId: ({ selectedShopId }) => selectedShopId,
        isShopSelected: (state) => (shopId) => shopId === state.selectedShopId,
        currentSelectionShopObj: (state) => {
            if (state.selectedShopId) return state.selectedProducts.find((item) => item.shopId === state.selectedShopId)
            else return null
        },
        getSelectedShopProducts: (state) => {
            if (!state.selectedShopId) return []
            const selectedShopObj = state.selectedProducts.find((item) => item.shopId === state.selectedShopId)
            console.log('selectedShopObj')
            console.log(selectedShopObj)
            if (selectedShopObj) return selectedShopObj.productsIdList
            return []
        },
    },
    mutations: {
        setData(state, { shopsList, productsList }) {
            state.shopsList = shopsList
            state.productsList = productsList
        },
        selectShop(state, shopId) {
            if (state.selectedShopId === shopId) state.selectedShopId = null
            else state.selectedShopId = shopId
        },
        selectProduct(state, productId) {
            if (!state.selectedShopId) return
            let shopSelectionObj = state.selectedProducts.find((item) => item.shopId === state.selectedShopId)
            if (!shopSelectionObj)
                state.selectedProducts.push({
                    shopId: state.selectedShopId,
                    productsIdList: [productId],
                })
            else {
                if (shopSelectionObj.productsIdList.includes(productId))
                    shopSelectionObj.productsIdList = shopSelectionObj.productsIdList.filter(
                        (item) => item !== productId
                    )
                else shopSelectionObj.productsIdList.push(productId)
            }
        },
    },
    actions: {
        loadData({ commit }) {
            commit('setData', { shopsList, productsList })
        },
        selectShop({ commit }, shopId) {
            commit('selectShop', shopId)
        },
        selectProduct({ commit }, id) {
            commit('selectProduct', id)
        },
    },
})
export default store

// getters

// getSelectedProducts
// actions
//
//
// removeProduct(shopId, productId)
//
