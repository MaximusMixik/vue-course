<template>
    <div>
        <h1>{{ title }}</h1>
        <div class="shops-container">
            <div
                v-for="shop in getShopsList"
                :key="shop.id"
                class="shop"
                :class="{
                    'is-selected': isSelected(shop.id),
                }"
            >
                {{ shop.title }}
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'ShopsList',

    props: {
        title: {
            type: String,
            default: 'Відділення',
        },
    },

    computed: {
        ...mapGetters(['getShopsList', 'getSelectedShopId']),
    },

    methods: {
        isSelected(shopId) {
            return shopId === this.getSelectedShopId
        },
    },
}
</script>

<style lang="scss" scoped>
.shops-container {
    border: 2px solid black;
    padding: 5px;
    .shop {
        margin: 5px;
    }
    .is-selected {
        background-color: blue;
    }
}
</style>
