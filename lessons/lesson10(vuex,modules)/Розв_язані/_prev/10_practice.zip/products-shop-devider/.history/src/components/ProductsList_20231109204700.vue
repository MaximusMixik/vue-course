<template>
    <h1>{{ title }}</h1>
    <div class="products-container">
        <div v-for="product in getProductsList" :key="product.id" class="product">
            {{ product.title }}
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'ProductsList',
    props: {
        title: {
            type: String,
            default: 'Список товарів',
        },
    },

    computed: {
        ...mapGetters(['getProductsList']),
    },
}
</script>

<style lang="scss" scoped>
.products-container {
    border: 2px solid black;
    padding: 5px;
    .product {
        margin: 5px;
    }
}
</style>
