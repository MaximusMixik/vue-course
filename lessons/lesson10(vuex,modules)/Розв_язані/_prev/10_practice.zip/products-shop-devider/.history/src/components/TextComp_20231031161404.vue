<template>
    <div>
        <input v-model="currentValue" type="text" @keydown="onkeyDown" />
    </div>
</template>

<script>
export default {
    props: {
        modelValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: Object,
            default: () => ({}),
        },
    },
    emits: ['update:modelValue'],

    computed: {
        currentValue: {
            get() {
                return this.modelValue
            },
            set(val) {
                console.log('====== val')
                console.log(val)
                if (val.length === 2) val += '/'
                console.log('------ val')
                console.log(val)

                this.$emit('update:modelValue', val)
            },
        },
    },

    methods: {
        onkeyDown(e) {
            const isDigit = e.key >= '0' && e.key <= '9'
            const isBackspace = e.key === 'Backspace'
            if (!(isDigit || isBackspace)) {
                e.preventDefault()
            } else {
                let val = this.modelValue
                if (isBackspace && val.length === 3) {
                    val = val[0]
                }
                this.$emit('update:modelValue', val)
            }
        },
    },
}
</script>

<style lang="scss" scoped></style>
