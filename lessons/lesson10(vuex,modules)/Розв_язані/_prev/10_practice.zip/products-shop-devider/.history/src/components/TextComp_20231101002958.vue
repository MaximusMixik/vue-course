<template>
    <div>
        <input v-model="localValue" type="text" @keydown="onkeyDown" />
    </div>
</template>

<script>
export default {
    props: {
        modelValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: Object,
            default: () => ({}),
        },
    },
    emits: ['update:modelValue'],

    data() {
        return {
            localValue: '',
        }
    },

    computed: {
        currentValue: {
            get() {
                return this.localValue ?? this.modelValue
            },
            set(val) {
                //     console.log('====== val')
                //     console.log(val)
                if (val.length === 2) val += '/'
                console.log('------ val')
                console.log(val)

                this.$emit('update:modelValue', val)
            },
        },
    },

    // watch: {
    //     localValue(newValue) {},
    // },

    methods: {
        onkeyDown(e) {
            const isDigit = e.key >= '0' && e.key <= '9'
            const isBackspace = e.key === 'Backspace'
            if (!(isDigit || isBackspace)) {
                e.preventDefault()
                return
            }

            if (!isBackspace && this.localValue.length === 5) {
                e.preventDefault()
                return
            }

            let val
            if (!isBackspace) {
                val = this.localValue + e.key
                if (val.length === 2) val += '/'
            } else {
                if (this.localValue.length === 3) val = val[0]
            }
            this.localValue = val
            this.$emit('update:modelValue', this.localValue)
        },
    },
}
</script>

<style lang="scss" scoped></style>
