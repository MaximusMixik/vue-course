<template>
    <shops-list />
</template>

<script>
import { mapActions } from 'vuex'
import ShopsList from '@/components/ShopsList.vue'

export default {
    name: 'App',

    components: {
        ShopsList,
    },

    data() {
        return {}
    },

    computed: {},

    created() {
        this.loadData()
    },

    methods: {
        ...mapActions(['loadData']),
    },
}
</script>

<style lang="scss"></style>
