<template>
    <div>
        <h1>{{ title }}</h1>
        <div class="shops-container">
            <div
                v-for="shop in getShopsList"
                :key="shop.id"
                class="shop"
                :class="{
                    'is-selected': isShopSelected(shop.id),
                }"
                @click="selectShop(shop.id)"
            >
                {{ shop.title }}
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'ShopsList',

    props: {
        title: {
            type: String,
            default: 'Відділення',
        },
    },

    computed: {
        ...mapGetters(['getShopsList', 'isShopSelected']),
    },

    methods: {
        ...mapActions(['selectShop']),
    },
}
</script>

<style lang="scss" scoped>
.shops-container {
    border: 2px solid black;
    padding: 5px;
    .shop {
        margin: 5px;
    }
    .is-selected {
        background-color: blue;
    }
}
</style>
