<template>
    <div>{{ $store.state.count }}</div>
    <div>{{ $store.getters.doubleCount }}</div>
    <div>
        <button @click="$store.dispatch('incrementCount')">Add</button>
        <button @click="$store.dispatch('decrementCount')">Subtract</button>
    </div>
</template>

<script>
export default {
    name: 'App',

    mounted() {
        console.log(this.$store)
    },
}
</script>

<style lang="scss"></style>
