<template>
    <h1>{{ title }}</h1>
    <div>
        <div v-for="product in "></div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'ProductsList',
    props: {
        title: {
            type: String,
            default: 'Список товарів',
        },
    },

    computed: {
        ...mapGetters('getProductsList'),
    },
}
</script>

<style lang="scss" scoped></style>
