<template>
    <div>{{ $store.state.getCount }}</div>
    <div>
        <button @click="$store.incrementCount">Add</button>
        <button @click="$storedecrementCount">Subtract</button>
    </div>
</template>

<script>
export default {
    name: 'App',

    mounted() {
        console.log(this.$store)
    },
}
</script>

<style lang="scss"></style>
