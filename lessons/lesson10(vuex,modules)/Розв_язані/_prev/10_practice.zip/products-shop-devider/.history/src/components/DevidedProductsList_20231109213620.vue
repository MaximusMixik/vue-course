<template>
    <h1>{{ title }}</h1>
    <div>
        <div v-for="selection in getSelectedProducts" :key="selection.shopId">
            <h3>{{ getShopById(selection.shopId).title }}</h3>
            <div
                v-for="prodId in selection.productsIdList"
                :key="prodId"
                @click="
                    removeProductFromShop({
                        shopId: selection.shopId,
                        prodId,
                    })
                "
            >
                {{ getProductById(prodId).title }}
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'DevidedProductsList',

    props: {
        title: {
            type: String,
            default: 'Розподілені товари',
        },
    },

    computed: {
        ...mapGetters(['getSelectedProducts', 'getShopById', 'getProductById']),
    },

    methods: {
        ...mapActions(['removeProductFromShop']),
    },
}
</script>

<style lang="scss" scoped></style>
