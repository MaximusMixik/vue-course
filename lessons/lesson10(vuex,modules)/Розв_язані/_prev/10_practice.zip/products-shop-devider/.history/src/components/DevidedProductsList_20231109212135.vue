<template>
    <h1>{{ titile }}</h1>
    <div></div>
</template>

<script>
export default {
    name: 'DevidedProductsList',

    props: {
        title: {
            type: String,
            default: 'Розподілені товари',
        },
    },
}
</script>

<style lang="scss" scoped></style>
