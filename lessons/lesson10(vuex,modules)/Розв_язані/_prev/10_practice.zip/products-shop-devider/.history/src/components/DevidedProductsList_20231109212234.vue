<template>
    <h1>{{ titile }}</h1>
    <div></div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'DevidedProductsList',

    props: {
        title: {
            type: String,
            default: 'Розподілені товари',
        },
    },

    computed: {
        ...mapGetters(['getSelectedProducts']),
    },
}
</script>

<style lang="scss" scoped></style>
