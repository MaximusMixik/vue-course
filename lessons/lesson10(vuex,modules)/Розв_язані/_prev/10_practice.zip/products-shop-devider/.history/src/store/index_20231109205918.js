import { createStore } from 'vuex'
import { shopsList, productsList } from '@/data/12_shops'
// Create a new store instance.
const store = createStore({
    state() {
        return {
            shopsList: [],
            productsList: [],
            selectedProducts: [
                {
                    shopId: 2,
                    productsIdList: [10, 12],
                },
            ],
            selectedShopId: null,
        }
    },
    getters: {
        getShopsList: (state) => state.shopsList,
        getProductsList: ({ productsList }) => productsList,
        getSelectedShopId: ({ selectedShopId }) => selectedShopId,
        isShopSelected: (state) => (shopId) => shopId === state.selectedShopId,
        getSelectedShopProducts: (state) => {
            if (!state.selectedShopId) return []
            const selectedShopObj = state.selectedProducts.find((item) => item.shopId === state.selectedShopId)
            if (selectedShopObj) return selectedShopObj.productsIdList
            return []
        },
    },
    mutations: {
        setData(state, { shopsList, productsList }) {
            state.shopsList = shopsList
            state.productsList = productsList
        },
        selectShop(state, shopId) {
            if (state.selectedShopId === shopId) state.selectedShopId = null
            else state.selectedShopId = shopId
        },
    },
    actions: {
        loadData({ commit }) {
            commit('setData', { shopsList, productsList })
        },
        selectShop({ commit }, shopId) {
            commit('selectShop', shopId)
        },
    },
})
export default store

// getters

// getSelectedProducts
// actions
//
// selectProduct(id)
// removeProduct(shopId, productId)
//
