<template>
    <div>
        <input v-model="localValue" type="text" @keyup="onkeyDown" />
    </div>
</template>

<script>
export default {
    props: {
        modelValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: Object,
            default: () => ({}),
        },
    },
    emits: ['update:modelValue'],

    data() {
        return {
            localValue: '',
        }
    },

    computed: {
        currentValue: {
            get() {
                return this.localValue ?? this.modelValue
            },
            set(val) {
                //     console.log('====== val')
                //     console.log(val)
                if (val.length === 2) val += '/'
                console.log('------ val')
                console.log(val)

                this.$emit('update:modelValue', val)
            },
        },
    },

    // watch: {
    //     localValue(newValue) {},
    // },

    methods: {
        onkeyDown(e) {
            const isDigit = e.key >= '0' && e.key <= '9'
            const isBackspace = e.key === 'Backspace'
            if (!(isDigit || isBackspace)) {
                e.preventDefault()
            } else {
                let val = this.localValue
                console.log('------ val 2')
                console.log(val)
                if (!isBackspace && val.length === 5) e.preventDefault()
                else {
                    if (isBackspace && val.length === 3) {
                        console.log('del')
                        console.log(val)
                        console.log(val[0])
                        this.localValue = val[0]
                    } else if (val.length === 2) this.localValue += '/'
                    this.$emit('update:modelValue', val)
                }
            }
        },
    },
}
</script>

<style lang="scss" scoped></style>
