export const boysList = [
  {
    id: 1,
    name: 'Головне відділення',
  },
  {
    id: 2,
    name: 'Оптовий',
  },
  {
    id: 3,
    name: 'Магазин №1',
  },
  {
    id: 4,
    name: 'Магазин №2',
  },
  {
    id: 5,
    name: 'Магазин №3',
  },
]
export const productsList = [
  {
    id: 10,
    name: 'Телефони',
  },
  {
    id: 12,
    name: 'Телевізори',
  },
  {
    id: 13,
    name: 'Мікрохвильові печі',
  },
  {
    id: 14,
    name: 'Пральні машини',
  },
  {
    id: 15,
    name: 'Фени',
  },
  {
    id: 16,
    name: 'Чайники',
  },
]
