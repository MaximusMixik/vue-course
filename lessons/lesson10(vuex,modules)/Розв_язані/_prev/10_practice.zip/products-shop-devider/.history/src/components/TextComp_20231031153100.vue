<template>
    <div>
        <input v-model="currentValue" type="text" @keydown="onkeyDown" />
    </div>
</template>

<script>
export default {
    props: {
        modelValue: {
            type: String,
            default: '',
        },
        moduleValueModifiers: {
            type: Object,
            default: () => ({}),
        },
    },
    emits: ['update:modelValue'],

    computed: {
        currentValue: {
            get() {
                return this.modelValue
            },
            set(val) {
                if (val.length === 2) val += '/'
                this.$emit('update:modelValue', val)
            },
        },
    },

    methods: {
        onkeyDown(e) {
            console.log(e.key)
            // if(e.key)
        },
    },
}
</script>

<style lang="scss" scoped></style>
