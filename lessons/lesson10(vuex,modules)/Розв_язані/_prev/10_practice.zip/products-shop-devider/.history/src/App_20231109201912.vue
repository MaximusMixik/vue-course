<template>
    <div></div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'App',

    components: {},

    data() {
        return {}
    },

    computed: {},

    created() {
        this.loadData()
    },

    methods: {
        ...mapActions(['loadData']),
    },
}
</script>

<style lang="scss"></style>
