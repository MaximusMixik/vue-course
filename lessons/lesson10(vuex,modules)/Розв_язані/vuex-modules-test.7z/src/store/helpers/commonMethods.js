export const commonMutations = {
  setData(state, objData) {
    state[objData.propTitle] = objData.propValue
  },
}
