<template>
  <div class="task-container">
    <div>{{ title }}</div>
    <div>{{ likes }}</div>
    <button @click="onLike">Like</button>
    <button @click="onDislike">Dislike</button>
  </div>
</template>

<script>
export default {
  name: 'BlogPost',

  props: {
    title: {
      type: String,
      default: 'Guest',
    },
    likes: {
      type: Number,
      default: 0,
    },
  },

  methods: {
    onLike() {
      this.$emit('like')
    },
    onDislike() {
      this.$emit('dislike')
    },
  },
}
</script>

<style lang="css" scoped>
.task-container {
  display: flex;
  justify-content: space-between;
  width: 500px;
}
</style>
