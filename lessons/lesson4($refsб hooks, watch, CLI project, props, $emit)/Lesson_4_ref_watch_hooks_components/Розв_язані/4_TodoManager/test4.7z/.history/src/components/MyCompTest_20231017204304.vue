<template>
  <div>
    <h1>My comp test</h1>
    <h2>Hello {{ userNAme }}</h2>
  </div>
</template>

<script>
export default {
  name: 'MyCompTest',

  props: {
    userNAme: {
      type: String,
      default: 'Guest',
    },
  },
}
</script>

<style lang="scss" scoped></style>
