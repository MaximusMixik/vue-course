<template>
  <div>
    <div>
      <label>
        Задача
        <input type="text" v-model="title" />
      </label>
    </div>
    <div>
      <label>
        Пріоритер
        <input type="number" v-model="priority" />
      </label>
    </div>
    <button @click="onAdd">Додати</button>
  </div>
</template>

<script>
export default {
  name: 'TodoForm',

  data() {
    return {
      title: null,
      priority: null,
    }
  },
}
</script>

<style lang="scss" scoped></style>
