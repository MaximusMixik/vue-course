<template>
  <div>
    <h1>My comp test</h1>
  </div>
</template>

<script>
export default {
  name: 'MyCompTest',
}
</script>

<style lang="scss" scoped></style>
