<template>
  <div>
    <todo-form @add="addTask" />
    <todo-item />
  </div>
</template>

<script>
import TodoForm from './TodoForm.vue'
import TodoItem from './TodoItem.vue'

export default {
  name: 'TodoManager',

  data() {
    return {
      todoList: [],
    }
  },

  components: {
    TodoForm,
    TodoItem,
  },

  methods: {
    addTask(task) {
      this.todoList.push(task)
    },
  },
}
</script>

<style lang="scss" scoped></style>
