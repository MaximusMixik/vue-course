<template>
  <div></div>
</template>

<script>
export default {
  name: 'TodoItem',

  props: {
    task: {
      type: Object,
      default: () => ({}),
    },
  },
}
</script>

<style lang="scss" scoped></style>
