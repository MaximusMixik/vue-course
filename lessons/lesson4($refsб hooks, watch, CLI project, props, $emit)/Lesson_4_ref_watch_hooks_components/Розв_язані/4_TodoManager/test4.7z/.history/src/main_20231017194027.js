import { createApp } from 'vue'
import App from './App1.vue'

createApp(App).mount('#app')
