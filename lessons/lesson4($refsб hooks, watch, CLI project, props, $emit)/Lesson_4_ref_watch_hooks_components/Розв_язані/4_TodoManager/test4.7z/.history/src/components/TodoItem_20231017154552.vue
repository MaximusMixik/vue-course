<template>
  <div>
    <div>{{ task.title }}</div>
    <div>{{ task.priority }}</div>
    <button @click="onDelete">Delete</button>
  </div>
</template>

<script>
export default {
  name: 'TodoItem',

  props: {
    task: {
      type: Object,
      default: () => ({}),
    },
  },

  methods: {
    onDelete() {
      this.$emit('delete', this.task.id)
    },
  },
}
</script>

<style lang="scss" scoped></style>
