<template>
  <div>
    <h1>My comp test</h1>
    <h2>Hello {{ userName }}</h2>
  </div>
</template>

<script>
export default {
  name: 'MyCompTest',

  props: {
    userName: {
      type: String,
      default: 'Guest',
    },
  },
}
</script>

<style lang="scss" scoped></style>
