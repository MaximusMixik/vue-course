<template>
  <div>
    <h1>My comp test</h1>
    <h2>Hello {{ userName }}</h2>
    <h2>AGE : {{ userAge }}</h2>
  </div>
</template>

<script>
export default {
  name: 'MyCompTest',

  props: {
    userName: {
      type: String,
      default: 'Guest',
    },
    userAge: {
      type: Number,
      required: true,
    },
  },
}
</script>

<style lang="scss" scoped></style>
