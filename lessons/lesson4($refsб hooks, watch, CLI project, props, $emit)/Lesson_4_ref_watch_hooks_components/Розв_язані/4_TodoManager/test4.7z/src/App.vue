<template>
  <!-- <my-comp-test user-name="Ivan" :user-age="23" /> -->
  <todo-manager />
</template>

<script>
import TodoManager from './components/TodoManager.vue'

// import MyCompTest from '@/components/MyCompTest.vue'

export default {
  name: 'App',
  components: {
    TodoManager,
    // MyCompTest,
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
  margin-top: 60px;
}
</style>
