<template>
    <div v-for="author in authors" :key="author.id">{{ author.name }} - {{ author.genre }}</div>
</template>
<script>
import { mapState } from 'vuex'

export default {
    name: 'BooksView',

    computed: {
        ...mapState(['authors']),
    },
}
</script>
