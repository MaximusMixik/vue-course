<template>
    <div>NotFound</div>
</template>

<script>
export default {
    name: 'NotFound',
}
</script>

<style lang="scss" scoped></style>
