import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LibraryView from '../views/LibraryView.vue'
import BooksView from '../views/BooksView.vue'
import AuthorsView from '../views/AuthorsView.vue'
import NotFound from '@/components/NotFound.vue'
import BookItem from '@/components/BookItem.vue'
import store from '@/store'

const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,
    },
    {
        path: 'books/:id',
        name: 'books',
        component: BookItem,
        beforeEnter(to) {
            const bookExists = store.state.books.find((book) => book.id == to.params.id)
            if (!bookExists) return { name: 'NotFound' }
        },
    },
    {
        path: '/library',
        name: 'library',
        component: LibraryView,
        children: [
            {
                path: 'books',
                name: 'booksl',
                component: BooksView,
            },
            {
                path: 'authors',
                name: 'authors',
                component: AuthorsView,
            },
        ],
    },
    {
        path: '/:pathMatch(.*)*',
        name: 'NotFound',
        component: NotFound,
    },
]

const router = createRouter({
    history: createWebHistory(),
    mode: 'history',
    routes,
})

export default router
