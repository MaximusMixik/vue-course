import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LibraryView from '../views/LibraryView.vue'
import BooksView from '../views/BooksView.vue'
import AuthorsView from '../views/AuthorsView.vue'

const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,
    },
    {
        path: '/library',
        name: 'library',
        component: LibraryView,
        children: [
            {
                path: '/library/books',
                name: 'books',
                component: BooksView,
            },
            {
                path: '/library/authors',
                name: 'authors',
                component: AuthorsView,
            },
        ],
    },
]

const router = createRouter({
    history: createWebHistory(),
    mode: 'history',
    routes,
})

export default router
