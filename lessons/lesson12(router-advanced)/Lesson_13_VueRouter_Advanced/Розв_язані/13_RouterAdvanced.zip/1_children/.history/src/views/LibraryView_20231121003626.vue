<template>
    <router-link :to="{ name: 'books' }">Books</router-link>
    <router-link :to="{ name: 'authors' }">Authors</router-link>
    hr
    <router-view />
</template>
<script>
export default {
    name: 'LibraryView',
}
</script>
<style lang="scss" scoped></style>
