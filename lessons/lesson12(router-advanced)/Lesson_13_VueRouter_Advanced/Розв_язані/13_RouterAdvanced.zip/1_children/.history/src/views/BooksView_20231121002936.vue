<template>
    <h1>Books :</h1>
    <div v-for="book in books" :key="book.id">{{ book.title }} - {{ book.price }}</div>
</template>
<script>
import { mapState } from 'vuex'

export default {
    name: 'BooksView',
    computed: {
        ...mapState(['books']),
    },
}
</script>
<style lang="scss" scoped></style>
