import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,
    },
    {
        path: '/books/:id',
        name: 'books',
        component: () => import('../views/BooksView.vue'),
        meta: { requiresAuth: false },
    },
    {
        path: '/authors/:id',
        name: 'authors',
        component: () => import('../views/AuthorsView.vue'),
        meta: { requiresAuth: true },
    },
    {
        path: '/login',
        name: 'LoginPage',
        component: () => import('../views/LoginPage.vue'),
        meta: { requiresAuth: false },
    },
]

const router = createRouter({
    history: createWebHistory(),
    mode: 'history',
    routes,
})

router.beforeEach((to) => {
    const isAuthenticated = window.userName
    if (to.meta.requiresAuth && !isAuthenticated) {
        return {
            name: 'LoginPage',
            query: { redirect: to.fullPath },
        }
    }
})

export default router
