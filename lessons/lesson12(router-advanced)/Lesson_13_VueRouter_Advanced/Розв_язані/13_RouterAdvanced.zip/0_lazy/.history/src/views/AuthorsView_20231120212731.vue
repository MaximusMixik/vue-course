<template>
    <div></div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
    name: 'BooksView',

    computed: {
        ...mapGetters(['getAuthorById']),
        authorId() {
            return this.$route.params.id
        },
        author() {
            return this.getAuthorById(this.authorId)
        },
    },
}
</script>
