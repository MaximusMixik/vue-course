<template>
    <div>{{ getBookById(id) }}</div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'BookItem',

    props: {
        id: {
            type: String,
            required: true,
        },
    },

    computed: {
        ...mapGetters(['getBookById']),
    },
}
</script>

<style lang="scss" scoped></style>
