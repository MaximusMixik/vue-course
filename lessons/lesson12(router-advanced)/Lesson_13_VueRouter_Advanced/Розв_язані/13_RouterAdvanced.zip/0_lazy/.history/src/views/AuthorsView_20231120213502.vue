<template>
    <div>aaa - {{ genre }}</div>
    <div v-for="author in authors" :key="author.id">{{ author.name }} - {{ author.genre }}</div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
    name: 'BooksView',

    computed: {
        ...mapGetters(['getAuthorByGenre']),
        genre() {
            return this.$route.params.id
        },
        authors() {
            return this.getAuthorByGenre(this.genre)
        },
    },
}
</script>
