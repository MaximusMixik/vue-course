<template>
    <book-item :id="bookId" />
</template>
<script>
import BookItem from '@/components/BookItem.vue'

export default {
    name: 'BooksView',

    components: { BookItem },

    computed: {
        bookId() {
            return this.$route.params.id
        },
    },
}
</script>
<style lang="scss" scoped></style>
