<template>
    <book-item :id="book.id" v-for="book in books" :key="book.id" />
</template>
<script>
import BookItem from '@/components/BookItem.vue'
import { mapState } from 'vuex'
export default {
    components: { BookItem },
    name: 'BooksView',

    computed: {
        ...mapState(['books']),
    },
}
</script>
<style lang="scss" scoped></style>
