<template>
    <div></div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
    name: 'BooksView',

    computed: {
        ...mapGetters(['getAuthorByGenre']),
        genre() {
            return this.$route.params.id
        },
        author() {
            return this.getAuthorByGenre(this.genre)
        },
    },
}
</script>
