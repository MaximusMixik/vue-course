<template>
    <div>{{ getBookById(id) }}</div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'BookItem',

    props: {
        id: {
            type: [String, Number],
            required: true,
        },
    },

    computed: {
        ...mapGetters(['getBookById']),
    },
}
</script>

<style lang="scss" scoped></style>
