import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        books: [
            { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', price: 15.99 },
            { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 12.5 },
            { id: 3, title: '1984', author: 'George Orwell', price: 10.99 },
            { id: 4, title: 'The Hobbit', author: 'J.R.R. Tolkien', price: 18.75 },
            { id: 5, title: 'The Catcher in the Rye', author: 'J.D. Salinger', price: 14.25 },
        ],
        authors: [
            { id: 1, name: 'Jane Austen', genre: 'Classic' },
            { id: 2, name: 'George R.R. Martin', genre: 'Fantasy' },
            { id: 3, name: 'Haruki Murakami', genre: 'Magical' },
            { id: 4, name: 'Agatha Christie', genre: 'Mystery' },
            { id: 5, name: 'J.K. Rowling', genre: 'Fantasy' },
        ],
    },
    getters: {
        getBookById: (state) => (bookId) => state.books.find((book) => book.id == bookId),
        getAuthorByGenre: (state) => (genre) => state.authors.filter((author) => genre && author.genre == genre),
    },
    mutations: {},
    actions: {},
    modules: {},
})
