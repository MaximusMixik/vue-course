<template>
    <div>My books</div>
</template>
<script>
export default {
    name: 'BooksView',
}
</script>
<style lang="scss" scoped></style>
