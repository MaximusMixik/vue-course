<template>
    <div class="about">
        <h1>Authors</h1>
    </div>
</template>
<script>
export default {
    name: 'BooksView',

    computed: {
        bookId() {
            return this.$route.params.id
        },
    },
}
</script>
