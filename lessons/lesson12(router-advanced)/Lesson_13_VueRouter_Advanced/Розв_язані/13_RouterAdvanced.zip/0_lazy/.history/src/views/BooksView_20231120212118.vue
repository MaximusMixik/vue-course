<template>
    {{ bookId }}
    <book-item v-for="id in bookId" :key="id" :book-id="id" />
</template>
<script>
import BookItem from '@/components/BookItem.vue'

export default {
    name: 'BooksView',

    components: { BookItem },

    computed: {
        bookId() {
            return this.$route.params.id
        },
    },
}
</script>
<style lang="scss" scoped></style>
