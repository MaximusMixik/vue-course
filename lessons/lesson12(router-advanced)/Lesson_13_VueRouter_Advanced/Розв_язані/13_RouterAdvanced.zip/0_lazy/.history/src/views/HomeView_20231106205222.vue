<template>
    <div class="home">
        <h1>About</h1>
        <img alt="Vue logo" src="../assets/logo.png" />
    </div>
</template>

<script>
export default {
    name: 'HomeView',
}
</script>
