<template>
    <book-item v-for="book in books" :key="book.id" :id="book.id" />
</template>
<script>
import BookItem from '@/components/BookItem.vue'
import { mapState } from 'vuex'
export default {
    name: 'BooksView',

    components: { BookItem },

    computed: {
        ...mapState(['books']),
    },
}
</script>
<style lang="scss" scoped></style>
