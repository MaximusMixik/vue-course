import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        books: [
            { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', price: 15.99 },
            { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 12.5 },
            { id: 3, title: '1984', author: 'George Orwell', price: 10.99 },
            { id: 4, title: 'The Hobbit', author: 'J.R.R. Tolkien', price: 18.75 },
            { id: 5, title: 'The Catcher in the Rye', author: 'J.D. Salinger', price: 14.25 },
        ],
        authors: [
            { id: 1, author: 'Jane Austen', genre: 'Classic Literature' },
            { id: 2, author: 'George R.R. Martin', genre: 'Fantasy' },
            { id: 3, author: 'Haruki Murakami', genre: 'Magical Realism' },
            { id: 4, author: 'Agatha Christie', genre: 'Mystery' },
            { id: 5, author: 'J.K. Rowling', genre: 'Fantasy' },
        ],
    },
    getters: {},
    mutations: {},
    actions: {},
    modules: {},
})
