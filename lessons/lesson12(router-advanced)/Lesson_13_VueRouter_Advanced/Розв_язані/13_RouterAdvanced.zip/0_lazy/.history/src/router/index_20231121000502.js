import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,
    },
    {
        path: '/books/:id',
        name: 'books',
        component: () => import('../views/BooksView.vue'),
    },
    {
        path: '/authors/:id',
        name: 'authors',
        component: () => import(/* webpackChunkName: "authors" */ '../views/AuthorsView.vue'),
    },
]

const router = createRouter({
    history: createWebHistory(),
    mode: 'history',
    routes,
})

export default router
