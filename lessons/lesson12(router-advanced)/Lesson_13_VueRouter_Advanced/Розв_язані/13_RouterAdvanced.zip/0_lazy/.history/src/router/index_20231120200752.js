import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import BooksView from '../views/BooksView.vue'
import AuthorsView from '../views/AuthorsView.vue'

const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,
    },
    {
        path: '/books/:id(\\d+)',
        name: 'books',
        component: BooksView,
    },
    {
        path: '/books/:id',
        name: 'authors',
        component: AuthorsView,
    },
]

const router = createRouter({
    history: createWebHistory(),
    mode: 'history',
    routes,
})

export default router
