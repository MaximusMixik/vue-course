<template>
    <book-item />
</template>
<script>
import BookItem from '@/components/BookItem.vue'
export default {
    components: { BookItem },
    name: 'BooksView',
}
</script>
<style lang="scss" scoped></style>
