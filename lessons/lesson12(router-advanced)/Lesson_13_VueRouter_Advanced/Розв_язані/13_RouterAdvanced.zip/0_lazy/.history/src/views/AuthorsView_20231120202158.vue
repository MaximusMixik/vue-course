<template>
    <div class="about">
        <h1>Authors</h1>
    </div>
</template>
