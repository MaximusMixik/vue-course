<template>
    <div></div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'BookItem',

    props: {
        id: {
            type: String,
        },
    },

    computed: {
        ...mapGetters(['getBookById']),
    },
}
</script>

<style lang="scss" scoped></style>
