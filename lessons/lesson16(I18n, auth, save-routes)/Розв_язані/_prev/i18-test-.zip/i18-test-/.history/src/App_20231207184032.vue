<template>
    <nav>
        <!-- <router-link to="/"> {{ $t('menu.home') }} </router-link> |
        <router-link to="/about"> {{ $t('menu.about') }} </router-link> |
        <router-link to="/contacts"> {{ $t('menu.contacts') }} </router-link>
         -->
        <router-link v-for="menuItem in menuItemsList" :key="menuItem.to" :to="menuItem.to">
            {{ $t(`menu.${menuItem.titleLabel}`) }}
        </router-link>
    </nav>
    <router-view />
</template>

<script>
export default {
    data() {
        return {
            menuItemsList: [
                {
                    to: '/',
                    titleLabel: 'home',
                },
                {
                    to: '/about',
                    titleLabel: 'about',
                },
                {
                    to: '/contacts',
                    titleLabel: 'contacts',
                },
            ],
        }
    },
}
</script>

<style lang="scss">
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
}

nav {
    padding: 30px;

    a {
        font-weight: bold;
        color: #2c3e50;

        &.router-link-exact-active {
            color: #42b983;
        }
    }
}
</style>
