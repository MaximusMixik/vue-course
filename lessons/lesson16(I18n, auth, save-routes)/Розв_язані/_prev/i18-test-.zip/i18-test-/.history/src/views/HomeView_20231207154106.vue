<template>
    <div class="home">Welcome!</div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {},
}
</script>
