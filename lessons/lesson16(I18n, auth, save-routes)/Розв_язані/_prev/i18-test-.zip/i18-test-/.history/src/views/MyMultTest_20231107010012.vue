<template>
    <div>
        <h1>Your prediction</h1>
        <h2>{{ currentPrediction }}</h2>
    </div>
</template>

<script>
const predictions = {
    boy: ['Іграшка', 'Цукерка', 'Торт'],
    man: ['Гроші', 'Авто', 'Шовдарь'],
}
export default {
    name: 'MyPredictor',
    computed: {
        firstNum() {
            return this.$route.params.first_num
        },
        secondNum() {
            return this.$route.params.second_num ?? 1 + Math.floor(Math.randon() * 10)
        },
        currentPrediction() {
            const randIndex = Math.floor(Math.random() * predictions[this.currentPerson].length)
            return predictions[this.currentPerson][randIndex]
        },
    },
}
</script>

<style lang="scss" scoped></style>
