<template>
    <div class="container">
        <nav>
            <!-- <router-link to="/"> {{ $t('menu.home') }} </router-link> |
        <router-link to="/about"> {{ $t('menu.about') }} </router-link> |
        <router-link to="/contacts"> {{ $t('menu.contacts') }} </router-link>
         -->
            <router-link v-for="menuItem in menuItemsList" :key="menuItem.to" :to="menuItem.to">
                {{ $t(`menu.${menuItem.titleLabel}`) }} |
            </router-link>
        </nav>
        <div>
            <span>{{ $t('messages.currentLanguage') }} : {{ currentLanguage }}</span>
            <button @click="changeLocale('ua')">Укр.</button>
            <button @click="changeLocale('en')">Eng.</button>
        </div>
    </div>
    <router-view />
</template>

<script>
export default {
    data() {
        return {
            menuItemsList: [
                {
                    to: '/',
                    titleLabel: 'home',
                },
                {
                    to: '/about',
                    titleLabel: 'about',
                },
                {
                    to: '/contacts',
                    titleLabel: 'contacts',
                },
            ],
        }
    },

    computed: {
        currentLanguage() {
            return this.$i18n.locale === 'ua' ? 'Українська' : 'English'
        },
    },

    created() {
        this.$i18n.locale = localStorage.getItem('lastLocale') ?? process.env.VUE_APP_I18N_LOCALE

        const self = this
        window.addEventListener('storage', function () {
            if (self.$i18n.locale !== localStorage.getItem('lastLocale')) {
                self.$i18n.locale = localStorage.getItem('lastLocale')
                self.$router.go()
            }
        })
    },

    methods: {
        changeLocale(lang) {
            this.$i18n.locale = lang
            localStorage.setItem('lastLocale', lang)
        },
    },
}
</script>

<style lang="scss">
.container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    // text-align: center;
    color: #2c3e50;
}

nav {
    padding: 30px;

    a {
        font-weight: bold;
        color: #2c3e50;

        &.router-link-exact-active {
            color: #42b983;
        }
    }
}
</style>
