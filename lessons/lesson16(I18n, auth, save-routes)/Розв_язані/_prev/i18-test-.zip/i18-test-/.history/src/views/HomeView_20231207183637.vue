<template>
    <div class="home">{{ $t('messages.welcome') }}</div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {},
}
</script>
