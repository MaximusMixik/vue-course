<template>
    <div class="home">
        {{ getItemsList }}
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'HomeView',

    computed: {
        ...mapGetters('todoItem', ['getItemsList']),
    },

    methods: {},
}
</script>
