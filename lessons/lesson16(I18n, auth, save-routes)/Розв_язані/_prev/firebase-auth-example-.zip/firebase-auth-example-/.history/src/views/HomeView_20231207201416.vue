<template>
    <div class="home">
        <hr />
        <div v-for="task in getItemsList" :key="task.id">{{ task.title }} - {{ task.price }}</div>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'HomeView',

    computed: {
        ...mapGetters('todoItems', ['getItemsList']),
    },

    created() {
        this.loadList()
    },

    methods: {
        ...mapActions('todoItems', ['loadList']),
    },
}
</script>
