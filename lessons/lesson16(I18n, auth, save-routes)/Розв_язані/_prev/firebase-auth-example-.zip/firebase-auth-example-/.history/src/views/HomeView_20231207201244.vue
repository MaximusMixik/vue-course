<template>
    <div class="home">
        {{ getItemsList }}
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    name: 'HomeView',

    computed: {
        ...mapGetters('todoItems', ['getItemsList']),
    },

    created() {
        this.loadList()
    },

    methods: {
        ...mapActions('todoItems', ['loadList']),
    },
}
</script>
