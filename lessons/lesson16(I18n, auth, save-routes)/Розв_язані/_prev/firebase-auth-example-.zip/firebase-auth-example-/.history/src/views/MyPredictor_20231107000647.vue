<template>
    <div></div>
</template>

<script>
export default {
    name: 'MyPredictor',
}
</script>

<style lang="scss" scoped></style>
