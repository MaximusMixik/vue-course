<script setup>
import { ref, watch } from 'vue'

const v1 = ref(1)
const v2 = ref(2)
// watch(v1, (newVal, oldVal) => {
//   console.log(`v1:  ${newVal} - ${oldVal}`)
// })

// watch(v2, (newVal, oldVal) => {
//   console.log(`v2:  ${newVal} - ${oldVal}`)
// })

// watch([v1, v2], ([new_v1, new_v2], [old_v1, old_v2]) => {
//   console.log('--------------')
//   console.log(`new:  ${new_v1} - ${new_v2}`)
//   console.log(`old: ${old_v1} - ${old_v2}`)
// })
// const arr=[v1,v2]
watch([v1, v2], (arrNew, arrOld) => {
  console.log('--------------')
  console.log(`new:  ${arrNew}`)
  console.log(`old: ${arrOld}`)
})
</script>

<template>
  <div>
    <div>Test</div>
    <div>
      v1
      <input v-model="v1" type="number" />
    </div>
    <div>
      v2
      <input v-model="v2" type="number" />
    </div>
  </div>
</template>

<style scoped>
header {
  line-height: 1.5;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  .logo {
    margin: 0 2rem 0 0;
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
    flex-wrap: wrap;
  }
}
</style>
