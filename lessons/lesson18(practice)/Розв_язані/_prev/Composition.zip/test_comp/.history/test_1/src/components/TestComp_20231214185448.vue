<template>
  <div>
    <div>{{ title }} - {{ price }}</div>
    <button @click="onBuy(price)">Buy</button>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    default: 0
  }
})
const emit = defineEmits(['buy'])
function onBuy(price) {
  emit('buy', price)
}
</script>

<style lang="scss" scoped></style>
