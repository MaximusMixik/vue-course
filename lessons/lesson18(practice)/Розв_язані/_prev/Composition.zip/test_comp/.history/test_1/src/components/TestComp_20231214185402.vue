<template>
  <div>
    <div>{{ title }} - {{ price }}</div>
    <button @click="onBuy">Buy</button>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    default: 0
  }
})
const emit = defineEmits(['buy'])
function onBuy() {
  emit('buy', this.price)
}
</script>

<style lang="scss" scoped></style>
