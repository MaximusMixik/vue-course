<template>
  <div>{{ title }} - {{ price }}</div>
  <button @click="$emit('buy', price)">Buy</button>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    default: 0
  }
})
defineEmits(['buy'])
</script>

<style lang="scss" scoped></style>
