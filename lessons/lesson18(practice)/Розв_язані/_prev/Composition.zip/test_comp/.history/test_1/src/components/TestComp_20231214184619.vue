<template>
  <div>{{ title }} - {{ price }}</div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    default: 0
  }
})
</script>

<style lang="scss" scoped></style>
