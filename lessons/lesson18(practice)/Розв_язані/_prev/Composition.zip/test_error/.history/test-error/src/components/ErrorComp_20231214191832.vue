<template>
  <div>Вибачте, сталася помилка!</div>
</template>

<style lang="scss" scoped></style>
