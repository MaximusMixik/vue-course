<template>
  <div>
    <h3>Test component</h3>
    <button @click="onClick">Generate error</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const someObj = ref(null)
function onClick() {
  someObj.value.test()
}
</script>

<style lang="scss" scoped></style>
