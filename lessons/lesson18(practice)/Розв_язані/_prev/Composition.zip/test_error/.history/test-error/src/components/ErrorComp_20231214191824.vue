<template>
  <div>Вибачте, сталася помилка!</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
