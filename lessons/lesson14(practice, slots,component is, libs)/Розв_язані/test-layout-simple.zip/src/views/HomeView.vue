<template>
  <main-layout> Вітаємо на голоній сторінці </main-layout>
</template>

<script>
export default {
  name: 'HomeView',
}
</script>
