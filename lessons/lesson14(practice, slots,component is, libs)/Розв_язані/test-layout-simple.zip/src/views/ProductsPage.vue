<template>
  <main-layout>
    <ol>
      <li>Tea</li>
      <li>Milk</li>
      <li>Bread</li>
    </ol>
  </main-layout>
</template>

<script>
export default {
  name: 'ProductsView',
}
</script>

<style lang="scss" scoped></style>
