<template>
    <div class="home">
        <person-list />
        <product-list />
        <friend-list />
    </div>
</template>

<script>
import PersonList from '@/components/PersonList.vue'
import ProductList from '@/components/ProductList.vue'
import FriendList from '@/components/FriendList.vue'
export default {
    name: 'HomeView',
    components: { PersonList, ProductList, FriendList },
    methods: {
        getTotalPrice(productList) {
            return productList.reduce((prevSum, product) => prevSum + product.price, 0)
        },
    },
}
</script>
