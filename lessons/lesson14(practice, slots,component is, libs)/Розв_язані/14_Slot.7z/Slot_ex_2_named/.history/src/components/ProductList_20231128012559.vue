<template>
    <div class="container">
        <data-card
            v-for="product in getProductsList"
            :key="product.id"
            :info="{
                logo: product.logo,
                label: product.position,
                image: product.imgSrc,
                message: product.title,
            }"
        >
            <div class="initials">
                <div>
                    {{ getInitials(employee) }}
                </div>
            </div>
        </data-card>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import DataCard from './DataCard.vue'

export default {
    name: 'PersonList',

    components: {
        DataCard,
    },

    computed: {
        ...mapGetters(['getProductsList']),
    },

    methods: {
        getInitials(employee) {
            const nameArr = employee.name.split(' ')
            return `${nameArr[1][0]}${nameArr[1][0]}`
        },
    },
}
</script>

<style lang="scss" scoped>
.container {
    display: flex;
    flex-wrap: wrap;
    .initials {
        text-align: center;
        height: 80px;
        width: 80px;
        font-size: 40px;
        background-color: greenyellow;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
}
</style>
