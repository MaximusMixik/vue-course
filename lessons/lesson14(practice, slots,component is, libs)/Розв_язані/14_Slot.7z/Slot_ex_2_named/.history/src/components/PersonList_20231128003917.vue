<template>
    <div>
        <data-card
            v-for="employee in getEmployeesList"
            :key="employee.id"
            :info="{
                logo: employee.logo,
                label: employee.position,
                message: employee.name,
            }"
        />
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import DataCard from './DataCard.vue'

export default {
    name: 'PersonList',

    components: {
        DataCard,
    },

    computed: {
        ...mapGetters(['getEmployeesList']),
    },
}
</script>

<style lang="scss" scoped></style>
