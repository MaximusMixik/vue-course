<template>
    <div>
        <data-card
            v-for="employee in getEmployeesList"
            :key="employee.id"
            :info="{
                logo: employee.logo,
                label: employee.position,
                message: employee.name,
            }"
        >
            <div class="initials">
                {{ getInitials(employee) }}
            </div>
        </data-card>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import DataCard from './DataCard.vue'

export default {
    name: 'PersonList',

    components: {
        DataCard,
    },

    computed: {
        ...mapGetters(['getEmployeesList']),
    },
}
</script>

<style lang="scss" scoped>
.initials {
    height: 50px;
    width: 50px;
}
</style>
