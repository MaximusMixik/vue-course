<template>
    <div>
        <div class="header">
            <div>
                <img :src="data.logo" />
            </div>
        </div>
        <div class="footer"></div>
    </div>
</template>

<script>
export default {
    name: 'DataCard',
}
</script>

<style lang="scss" scoped></style>
