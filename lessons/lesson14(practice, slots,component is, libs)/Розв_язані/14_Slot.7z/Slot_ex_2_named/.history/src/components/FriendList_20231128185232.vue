<template>
    <div class="container">
        <data-card
            v-for="friend in getFriendsList"
            :key="friend.id"
            :info="{
                logo: friend.logo,
                label: friend.position,
                message: friend.name,
                image: friend.imgSrc,
            }"
        >
            <template #right-header>
                {{ friend.status }}
            </template>
            <template #card-footer>
                {{ getName(friend.name) }}
            </template>
        </data-card>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import DataCard from './DataCard.vue'

export default {
    name: 'PersonList',

    components: {
        DataCard,
    },

    computed: {
        ...mapGetters(['getFriendsList']),
    },
    methods: {
        getName(fullName) {
            return fullName.split()[0]
        },
    },
}
</script>

<style lang="scss" scoped>
.container {
    display: flex;
    flex-wrap: wrap;
    .initials {
        text-align: center;
        height: 80px;
        width: 80px;
        font-size: 40px;
        background-color: greenyellow;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
}
</style>
