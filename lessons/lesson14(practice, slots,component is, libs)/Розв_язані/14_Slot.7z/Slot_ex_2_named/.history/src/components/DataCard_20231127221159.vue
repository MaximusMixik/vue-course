<template>
    <div class="card">
        <div class="header">
            <div>
                <img :src="data.logo" />
            </div>
        </div>
        <div>
            <slot>
                <img :src="data.logo" />
            </slot>
        </div>
        <div class="footer"></div>
    </div>
</template>

<script>
export default {
    name: 'DataCard',
    props: {
        defaultImageSrc: {
            type: String,
            default: require('@/assets/logo.png'),
        },
    },
}
</script>

<style lang="scss" scoped>
.card {
    width: 100px;
    height: 200px;
    border-radius: 10px;
    border: 2px solid green;
}
</style>
