<template>
    <div v-for=""><data-card info:/></div>
</template>

<script>
import DataCard from './DataCard.vue'
export default {
    name: 'PersonList',

    components: {
        DataCard,
    },
}
</script>

<style lang="scss" scoped></style>
