<template>
    <div class="card">
        <div class="header">
            <img :src="info.logo" />

            <div>
                {{ info.label }}
            </div>
        </div>
        <div class="main">
            <slot>
                <img :src="info.image ?? defaultImageSrc" />
            </slot>
        </div>
        <div class="footer">
            {{ info.message }}
        </div>
    </div>
</template>

<script>
export default {
    name: 'DataCard',
    props: {
        info: {
            type: Object,
            required: true,
        },
        defaultImageSrc: {
            type: String,
            default:
                'https://media.istockphoto.com/id/1332100919/vector/man-icon-black-icon-person-symbol.jpg?s=612x612&w=0&k=20&c=AVVJkvxQQCuBhawHrUhDRTCeNQ3Jgt0K1tXjJsFy1eg=',
        },
    },
}
</script>

<style lang="scss" scoped>
.card {
    width: 150px;
    height: 200px;
    border-radius: 10px;
    border: 2px solid green;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 8px;

    .header {
        display: flex;
        justify-content: space-between;
        > div {
            background-color: aqua;
            border-radius: 5px;
            padding: 3px;
        }
        img {
            height: 20px;
        }
    }
    .main {
        text-align: center;
        height: 70px;
        img {
            height: 70px;
        }
    }
}
</style>
