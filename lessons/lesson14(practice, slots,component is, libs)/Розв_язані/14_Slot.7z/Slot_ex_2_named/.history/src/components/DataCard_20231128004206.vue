<template>
    <div class="card">
        <div class="header">
            <div>
                <img :src="info.logo" />
            </div>
            <div>
                {{ info.label }}
            </div>
        </div>
        <div class="main">
            <slot>
                <img :src="info.image ?? defaultImageSrc" />
            </slot>
        </div>
        <div class="footer">
            {{ info.message }}
        </div>
    </div>
</template>

<script>
export default {
    name: 'DataCard',
    props: {
        info: {
            type: Object,
            required: true,
        },
        defaultImageSrc: {
            type: String,
            default:
                'https://media.istockphoto.com/id/1332100919/vector/man-icon-black-icon-person-symbol.jpg?s=612x612&w=0&k=20&c=AVVJkvxQQCuBhawHrUhDRTCeNQ3Jgt0K1tXjJsFy1eg=',
        },
    },
}
</script>

<style lang="scss" scoped>
.card {
    width: 100px;
    height: 200px;
    border-radius: 10px;
    border: 2px solid green;
    .header {
        display: flex;
        justify-content: space-between;
        & > div {
            width: 20px;
            height: 20px;
        }
    }
    .main {
        height: 70px;
        img: 70px;
    }
}
</style>
