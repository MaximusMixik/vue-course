<template>
    <div>
        <data-card
            v-for="employee in getEmployeesList"
            :key="employee.id"
            :info="{
                logo: employee.logo,
                label: employee.position,
                message: employee.name,
            }"
        >
            <div class="initials">
                <div>
                    {{ getInitials(employee) }}
                </div>
            </div>
        </data-card>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import DataCard from './DataCard.vue'

export default {
    name: 'PersonList',

    components: {
        DataCard,
    },

    computed: {
        ...mapGetters(['getEmployeesList']),
    },

    methods: {
        getInitials(employee) {
            const nameArr = employee.name.split(' ')
            return `${nameArr[1][0]}${nameArr[1][0]}`
        },
    },
}
</script>

<style lang="scss" scoped>
.initials {
    text-align: center;
    height: 70px;
    width: 70px;
    font-size: 40px;
    display: inline-block;
    background-color: greenyellow;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
}
</style>
