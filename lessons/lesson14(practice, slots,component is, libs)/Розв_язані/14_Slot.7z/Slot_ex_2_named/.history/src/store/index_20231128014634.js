import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        employees: [
            {
                id: 1,
                name: 'Іваненко Іван Іванович',
                position: 'інженер',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 2,
                name: 'Петренко Петро Петрович',
                position: 'оператор',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 3,
                name: 'Марченко Марина Анатоліївна',
                position: 'технік',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 4,
                name: 'Олійник Ольга Олександрівна',
                position: 'лаборант',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
        ],
        products: [
            {
                id: 1,
                title: 'Смартфон XYZ',
                action: 'знижка',
                imgSrc: 'https://cdn.tmobile.com/content/dam/t-mobile/en-p/cell-phones/apple/Apple-iPhone-13/Midnight/Apple-iPhone-13-Midnight-thumbnail.png',
                logo: 'https://img.freepik.com/premium-vector/shopping-bag-store-logo-online-shopping-logo-design_487414-262.jpg',
            },
            {
                id: 2,
                title: 'Ноутбук ABC',
                action: 'розпродаж',
                imgSrc: 'https://i.citrus.world/imgcache/size_800/uploads/shop/d/d/dd71cb568ad03a9b239bc43beff0721a.jpg',
                logo: 'https://img.freepik.com/premium-vector/shopping-bag-store-logo-online-shopping-logo-design_487414-262.jpg',
            },
            {
                id: 3,
                title: 'Годинник DEF',
                action: 'акція',
                imgSrc: 'https://images.prom.ua/3577668710_w640_h640_nastennye-chasy-power.jpg',
                logo: 'https://logofactory.ua/wp-content/uploads/2019/01/crafter-logo2-min-640x500.jpg',
            },
            {
                id: 4,
                title: 'Камера GHI',
                action: 'знижка',
                imgSrc: 'https://i.citrus.world/imgcache/size_800/uploads/shop/c/1/c10a1c024a4923c85b23fd5b576ab52d.jpg',
                logo: 'https://logofactory.ua/wp-content/uploads/2019/01/crafter-logo2-min-640x500.jpg',
            },
        ],
        friends: [
            {
                id: 1,
                name: 'Петро Петров',
                status: '😊', // Unicode іконка
                imgSrc: 'https://easydrawingguides.com/wp-content/uploads/2023/04/1723-Easy-cartoon-boy-coloring-page.png',
                logo: 'https://e7.pngegg.com/pngimages/322/730/png-clipart-student-school-cartoon-illustration-cartoon-school-building-cartoon-character-angle.png',
            },
            {
                id: 2,
                name: 'Ірина Іванова',
                status: '👋',
                imgSrc: 'https://iheartcraftythings.com/wp-content/uploads/2021/06/8-21.jpg',
                logo: 'https://e7.pngegg.com/pngimages/322/730/png-clipart-student-school-cartoon-illustration-cartoon-school-building-cartoon-character-angle.png',
            },
            {
                id: 3,
                name: 'Олександр Олександров',
                status: '🎉',
                imgSrc: 'https://easydrawingguides.com/wp-content/uploads/2023/04/1723-Easy-cartoon-boy-coloring-page.png',
                logo: 'https://e7.pngegg.com/pngimages/322/730/png-clipart-student-school-cartoon-illustration-cartoon-school-building-cartoon-character-angle.png',
            },
            {
                id: 4,
                name: 'Марія Маринчук',
                status: '🌟',
                imgSrc: 'https://iheartcraftythings.com/wp-content/uploads/2021/06/8-21.jpg',
                logo: 'https://e7.pngegg.com/pngimages/322/730/png-clipart-student-school-cartoon-illustration-cartoon-school-building-cartoon-character-angle.png',
            },
        ],
    },
    getters: {
        getEmployeesList: (state) => state.employees,
        getProductsList: (state) => state.products,
        getFriendsList: (state) => state.friends,
    },
    mutations: {},
    actions: {},
    modules: {},
})
