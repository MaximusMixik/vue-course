import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        employees: [
            {
                id: 1,
                name: 'Іваненко Іван Іванович',
                position: 'інженер',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 2,
                name: 'Петренко Петро Петрович',
                position: 'оператор',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 3,
                name: 'Марченко Марина Анатоліївна',
                position: 'технік',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 4,
                name: 'Олійник Ольга Олександрівна',
                position: 'лаборант',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 5,
                name: 'Григоренко Григорій Григорович',
                position: 'механік',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
        ],
        products: [
            {
                id: 1,
                title: 'Смартфон XYZ',
                action: 'знижка',
                imgSrc: 'https://nz.shop.allpressespresso.com/cdn/shop/products/ReusableCup_grande.png?v=1574973710',
                logo: 'https://img.freepik.com/premium-vector/shopping-bag-store-logo-online-shopping-logo-design_487414-262.jpg',
            },
            {
                id: 2,
                title: 'Ноутбук ABC',
                action: 'розпродаж',
                imgSrc: 'https://i0.wp.com/www.papyrusnatural.co.za/wp-content/uploads/2021/05/1-1.png?fit=1280%2C720&ssl=1',
                logo: 'https://img.freepik.com/premium-vector/shopping-bag-store-logo-online-shopping-logo-design_487414-262.jpg',
            },
            {
                id: 3,
                title: 'Годинник DEF',
                action: 'акція',
                imgSrc: 'шлях_до_зображення_товару_3.jpg',
                logo: 'https://logofactory.ua/wp-content/uploads/2019/01/crafter-logo2-min-640x500.jpg',
            },
            {
                id: 4,
                title: 'Камера GHI',
                action: 'знижка',
                imgSrc: 'шлях_до_зображення_товару_4.jpg',
                logo: 'https://logofactory.ua/wp-content/uploads/2019/01/crafter-logo2-min-640x500.jpg',
            },
            {
                id: 5,
                title: 'Колонка JKL',
                action: 'розпродаж',
                imgSrc: 'шлях_до_зображення_товару_5.jpg',
                logo: 'лого_магазину_5.png',
            },
        ],
    },
    getters: {
        getEmployeesList: (state) => state.employees,
    },
    mutations: {},
    actions: {},
    modules: {},
})
