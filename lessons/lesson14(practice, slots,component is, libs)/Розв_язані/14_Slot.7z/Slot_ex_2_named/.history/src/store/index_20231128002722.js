import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        employees Ж [
            {
              id: 1,
              name: 'Іваненко Іван Іванович',
              position: 'інженер',
              logo: 'інженер_logo.png'
            },
            {
              id: 2,
              name: 'Петренко Петро Петрович',
              position: 'оператор',
              logo: 'оператор_logo.png'
            },
            {
              id: 3,
              name: 'Марченко Марина Анатоліївна',
              position: 'технік',
              logo: 'технік_logo.png'
            },
            {
              id: 4,
              name: 'Олійник Ольга Олександрівна',
              position: 'лаборант',
              logo: 'лаборант_logo.png'
            },
            {
              id: 5,
              name: 'Григоренко Григорій Григорович',
              position: 'механік',
              logo: 'механік_logo.png'
            }
          ]
    },
    getters: {},
    mutations: {},
    actions: {},
    modules: {},
})
