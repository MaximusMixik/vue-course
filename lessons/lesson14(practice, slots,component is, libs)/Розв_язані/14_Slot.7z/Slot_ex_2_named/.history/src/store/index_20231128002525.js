import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        employees: [
            { id: 1, name: 'Іваненко Іван Іванович', position: 'Інженер' },
            { id: 2, name: 'Петренко Марія Петрівна', position: 'Адміністратор' },
            { id: 3, name: 'Сидоренко Олег Васильович', position: 'Технік' },
            { id: 4, name: 'Гриценко Анна Олександрівна', position: 'Менеджер' },
            { id: 5, name: 'Ковальов Максим Юрійович', position: 'Електромонтер' },
        ],
    },
    getters: {},
    mutations: {},
    actions: {},
    modules: {},
})
