import { createStore } from 'vuex'

export default createStore({
    namespaced: true,
    state: {
        employees: [
            {
                id: 1,
                name: 'Іваненко Іван Іванович',
                position: 'інженер',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 2,
                name: 'Петренко Петро Петрович',
                position: 'оператор',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 3,
                name: 'Марченко Марина Анатоліївна',
                position: 'технік',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 4,
                name: 'Олійник Ольга Олександрівна',
                position: 'лаборант',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
            {
                id: 5,
                name: 'Григоренко Григорій Григорович',
                position: 'механік',
                logo: 'https://s.tmimgcdn.com/scr/800x500/195400/sablon-vektor-tehniceskogo-obsluzivania-inzenera_195484-original.jpg',
            },
        ],
    },
    getters: {
        getEmployeesList: (state) => state.employees,
    },
    mutations: {},
    actions: {},
    modules: {},
})
