<template>
    <div class="home">
        <h2 @click="onTestClick">Тест : 8 * 3</h2>
        <h2 @click="onPredictClick">Передбачення для хлопця</h2>
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {
        onTestClick() {
            this.$router.push({
                path: '/test',
                params: {
                    first_num: 8,
                    second_num: 3,
                },
            })
        },
        onPredictClick() {
            this.$router.push({
                name: 'predictor',
                params: {
                    person: 'boy',
                },
            })
        },
    },
}
</script>
