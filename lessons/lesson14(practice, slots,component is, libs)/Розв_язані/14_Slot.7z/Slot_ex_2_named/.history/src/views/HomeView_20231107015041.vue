<template>
    <div class="home">
        <h1></h1>
        <h2 @click="onTestClick">Тест : 8 * 3</h2>
    </div>
</template>

<script>
export default {
    name: 'HomeView',

    methods: {
        onTestClick() {
            this.$router.push({
                name: 'test',
                params: {
                    first_num: 8,
                    second_num: 3,
                },
            })
        },
    },
}
</script>
