<template>
    <div>
        <h1>{{ firstNum }}*{{ secondNum }} =</h1>
        <label>
            Відповідь:
            <input v-model="userAnswer" type="number" />
        </label>
        <button @click="check">Перевірити</button>
    </div>
</template>

<script>
export default {
    name: 'MyPredictor',
    data() {
        return {
            userAnswer: null,
        }
    },
    computed: {
        firstNum() {
            return this.$route.params.first_num
        },
        secondNum() {
            return this.$route.params.second_num ?? 1 + Math.floor(Math.randon() * 10)
        },
    },
    methods: {
        check() {},
    },
}
</script>

<style lang="scss" scoped></style>
