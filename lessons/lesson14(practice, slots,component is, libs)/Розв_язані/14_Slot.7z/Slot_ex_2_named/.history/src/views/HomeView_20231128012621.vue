<template>
    <div class="home">
        <person-list />
        <person-list />
    </div>
</template>

<script>
import PersonList from '@/components/PersonList.vue'
export default {
    name: 'HomeView',
    components: { PersonList },
    methods: {},
}
</script>
