<template>
    <div class="home">
        <person-list />
        <product-list />
    </div>
</template>

<script>
import PersonList from '@/components/PersonList.vue'
import ProductList from '@/components/ProductList.vue'
export default {
    name: 'HomeView',
    components: { PersonList, ProductList },
    methods: {},
}
</script>
