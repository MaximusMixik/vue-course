<template>
    <div>
        <h1>Your prediction</h1>
        <h2>{{ currentPrediction }}</h2>
    </div>
</template>

<script>
const predictions = {
    boy: ['Іграшка', 'Цукерка', 'Торт'],
    man: ['Гроші', 'Авто', 'Шовдарь'],
}
export default {
    name: 'MyPredictor',
    computed: {
        currentPerson() {
            return this.$route.params.person
        },
        currentPrediction() {
            const randIndex = Math.floor(Math.random() * predictions[this.currentPerson].length)
            return predictions[randIndex]
        },
    },
}
</script>

<style lang="scss" scoped></style>
