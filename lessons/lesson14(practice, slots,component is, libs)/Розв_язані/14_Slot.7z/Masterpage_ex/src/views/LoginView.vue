<template>
    <auth-masterpage>
        <div>
            Login
            <input v-model="login" type="text" />
        </div>
        <div>
            Password
            <input v-model="password" type="password" />
        </div>
    </auth-masterpage>
</template>

<script>
import AuthMasterpage from '@/masterpages/AuthMasterpage.vue'
export default {
    name: 'LoginView',

    components: { AuthMasterpage },

    data() {
        return {
            login: null,
            password: null,
        }
    },
}
</script>

<style lang="scss" scoped></style>
