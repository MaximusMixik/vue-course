<template>
    <main-master-page>
        <div>My contacts</div>
    </main-master-page>
</template>
<script>
import MainMasterPage from '@/masterpages/MainMasterPage.vue'

export default {
    name: 'MyContacts',
    components: { MainMasterPage },
}
</script>
<style lang="scss" scoped></style>
