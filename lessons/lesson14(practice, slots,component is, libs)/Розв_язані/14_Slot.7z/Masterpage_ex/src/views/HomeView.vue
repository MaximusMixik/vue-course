<template>
    <main-master-page>
        <h1>Home</h1>
        <h2>Вітаємо на сайті компанії</h2>
    </main-master-page>
</template>

<script>
import MainMasterPage from '@/masterpages/MainMasterPage.vue'
export default {
    name: 'HomeView',
    components: { MainMasterPage },
    methods: {},
}
</script>
