<template>
    <div>
        <nav>
            <router-link to="/"> На головну </router-link>
        </nav>
        <slot></slot>
        <footer>
            <h2>Ви знаходитесь на сторінці авторизації.</h2>
            <h2>Увійдіть, що скористатися сервісами</h2>
        </footer>
    </div>
</template>

<script>
export default {
    name: 'AuthMasterpage',
}
</script>

<style lang="scss" scoped></style>
