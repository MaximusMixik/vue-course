<template>
    <div>
        <nav>
            <router-link to="/"> Home </router-link> |
            <router-link to="/about"> About </router-link>
            <router-link to="/contacts"> My Contacts </router-link>
        </nav>
        <slot></slot>
        <footer>Company: Баба Галя Корпорейшн</footer>
    </div>
</template>

<script>
export default {
    name: 'MainPasterpage',
}
</script>

<style lang="scss" scoped></style>
