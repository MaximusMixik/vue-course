<template>
    <auth-masterpage>
        <div>
            <label>
                New password
                <input v-model="password" type="password" />
            </label>
        </div>
        <div>
            <label>
                New password confirmation
                <input v-model="passwordConfirm" type="password" />
            </label>
        </div>
        <button :disabled="isPasswordsEqual">Send</button>
    </auth-masterpage>
</template>

<script>
import AuthMasterpage from '@/masterpages/AuthMasterpage.vue'
export default {
    name: 'ChangePasswordView',
    components: { AuthMasterpage },
    data() {
        return {
            password: null,
            passwordConfirm: null,
        }
    },

    computed: {
        isPasswordsEqual() {
            return !(this.password && this.passwordConfirm && this.password === this.passwordConfirm)
        },
    },
}
</script>

<style lang="scss" scoped></style>
