<template>
    <auth-masterpage></auth-masterpage>
</template>

<script>
import AuthMasterpage from '@/masterpages/AuthMasterpage.vue'
export default {
    name: 'LoginView',
    components: { AuthMasterpage },
}
</script>

<style lang="scss" scoped></style>
