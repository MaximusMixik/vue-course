<template>
    <main-master-page>
        <div class="about">
            <h1>This is an about page</h1>
        </div>
    </main-master-page>
</template>
