<template>
    <main-master-page>
        <div>My contacts</div>
    </main-master-page>
</template>
<script>
import MainMasterPage from "@/masterpages/MainMasterPage.vue"

export default
  components: { MainMasterPage },{
    name: 'MyContacts',
}
</script>
<style lang="scss" scoped></style>
