<template>
    <main-master-page> </main-master-page>
</template>

<script>
import MainMasterPage from '@/masterpages/MainMasterPage.vue'
export default {
    name: 'HomeView',
    components: { MainMasterPage },
    methods: {},
}
</script>
