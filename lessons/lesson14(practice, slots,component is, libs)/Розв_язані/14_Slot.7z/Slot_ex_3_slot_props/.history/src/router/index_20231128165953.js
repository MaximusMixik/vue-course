import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AboutView from '../views/AboutView.vue'
import MyContacts from '../views/MyContacts.vue'

const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,
    },
    {
        path: '/about',
        name: 'about',
        component: AboutView,
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        // component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue'),
    },
    {
        path: '/contacts/:task(\\D{2}-\\d{2})/:man(\\D{2}-\\d{2})',
        name: 'contacts',
        component: MyContacts,
    },
]

const router = createRouter({
    history: createWebHistory(),
    mode: 'history',
    routes,
})

router.beforeEach((to, from) => {
    console.log(from)
})

export default router
