<template>
    <div>My contacts</div>
    <div>{{ $route.params.task }}</div>
    <div>{{ $route.params.man }}</div>
</template>
<script>
export default {
    name: 'MyContacts',
}
</script>
<style lang="scss" scoped></style>
