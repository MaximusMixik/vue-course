<template>
    <main-masterpage>
        <font-awesome-icon :icon="['fas', 'link-slash']" size="3x" />
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'
export default {
    name: 'PageNotFound',
    components: { MainMasterpage },
}
</script>

<style lang="scss" scoped></style>
