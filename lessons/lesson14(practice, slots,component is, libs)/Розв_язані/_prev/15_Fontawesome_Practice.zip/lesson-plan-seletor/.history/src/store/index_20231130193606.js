import { createStore } from 'vuex'
import subjects from './modules/subjects'
import teachers from './modules/teachers'
export default createStore({
    namespaced: true,
    state: {},
    getters: {},
    mutations: {},
    actions: {},
    modules: {
        subjects,
        teachers,
    },
})
