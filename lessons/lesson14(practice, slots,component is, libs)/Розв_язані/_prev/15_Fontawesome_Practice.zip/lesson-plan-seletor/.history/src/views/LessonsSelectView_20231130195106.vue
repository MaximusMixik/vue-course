<template>
    <div>Крок 1. Вибір уроків</div>
    <div v-for="subject in getSubjectsList" :key="subject.id">
        <label>
            {{ subject.title }}
            <input v-model="selectedSubjects" :value="subject.id" type="checkbox" />
        </label>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'LessonsSelectView',

    data() {
        return {
            selectedSubjects: [],
        }
    },

    computed: {
        ...mapGetters('subjects', ['getSubjectsList']),
    },
}
</script>

<style lang="scss" scoped></style>
