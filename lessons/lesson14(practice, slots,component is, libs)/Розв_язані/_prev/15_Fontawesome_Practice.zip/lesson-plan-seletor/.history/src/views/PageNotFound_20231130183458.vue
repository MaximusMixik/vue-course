<template>
    <div>
        <font-awesome-icon :icon="['fas', 'link-slash']" size="3x" />
    </div>
</template>

<script>
export default {
    name: 'PageNotFound',
}
</script>

<style lang="scss" scoped></style>
