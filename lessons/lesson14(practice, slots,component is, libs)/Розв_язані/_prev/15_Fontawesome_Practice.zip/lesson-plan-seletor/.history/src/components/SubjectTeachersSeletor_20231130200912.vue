<template>
    <div>
        <label>
            {{ subjectTitle }}
            <select>
                <option v-for="teacher in getTeachersBySubjectId" :key="teacher.id" :value="teacher.id">
                    {{ teacher.name }}
                </option>
            </select>
        </label>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: 'SubjectTeachersSeletor',
    props: {
        subjectId: {
            type: [Number, String],
            required: true,
        },
    },

    computed: {
        ...mapGetters('subjects', ['getSubjectById']),
        ...mapGetters('teachers', ['getTeachersBySubjectId']),

        subjectTitle() {
            return this.getSubjectById(parseInt(this.subjectId))?.title
        },
    },
}
</script>

<style lang="scss" scoped></style>
