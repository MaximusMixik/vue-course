<template>
    <main-masterpage>
        <div>Lessons</div>
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'

export default {
    name: 'LessonsSelectView',
    components: { MainMasterpage },
}
</script>

<style lang="scss" scoped></style>
