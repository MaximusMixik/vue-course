<template>
    <div>Lessons</div>
</template>

<script>
export default {
    name: 'Lessons',
}
</script>

<style lang="scss" scoped></style>
