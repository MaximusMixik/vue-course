<template>
    <main-masterpage>
        <div class="home">
            <p>Вітаємо на нашому сайті</p>
            <font-awesome-icon :icon="['fab', 'github']" color="red" />
            <font-awesome-icon :icon="['fas', 'car-side']" />
        </div>
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'
export default {
    name: 'HomeView',
    components: { MainMasterpage },
    methods: {},
}
</script>
