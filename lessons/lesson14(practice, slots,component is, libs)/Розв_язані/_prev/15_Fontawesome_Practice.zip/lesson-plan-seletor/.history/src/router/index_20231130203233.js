import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LessonsView from '../views/LessonsView.vue'
import TeachersView from '../views/TeachersView.vue'
import PageNotFound from '../views/PageNotFound.vue'
import LoginPage from '../views/LoginPage.vue'
import LessonsSelectView from '../views/LessonsSelectView.vue'
import TeachersSelect from '../views/TeachersSelect.vue'
import LessonsPlan from '../views/LessonsPlan.vue'

const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,
        meta: {
            requireAuth: false,
        },
    },
    {
        path: '/lessons',
        name: 'lessons',
        component: LessonsView,
        meta: {
            requireAuth: true,
        },
        children: [
            {
                path: 'select',
                name: 'lesson-select',
                component: LessonsSelectView,
                meta: {
                    requireAuth: true,
                },
            },
            {
                path: ':subjectId(\\d+)+',
                name: 'teachers-select',
                component: TeachersSelect,
                meta: {
                    requireAuth: true,
                },
            },
            {
                path: ':subjectId(\\d+-\\d+)+',
                name: 'study-select',
                component: LessonsPlan,
                meta: {
                    requireAuth: true,
                },
            },
        ],
    },
    {
        path: '/teachers',
        name: 'teachers',
        component: TeachersView,
        meta: {
            requireAuth: true,
        },
    },
    {
        path: '/login',
        name: 'login',
        component: LoginPage,
        meta: {
            requireAuth: false,
        },
    },
    {
        path: '/:pathMatch(.*)*',
        name: 'pageNotFound',
        component: PageNotFound,
        meta: {
            requireAuth: false,
        },
    },
]

const router = createRouter({
    history: createWebHistory(),
    mode: 'history',
    routes,
})

router.beforeEach((to) => {
    const authParams = localStorage.getItem('authParams')
    if (to.meta.requireAuth && !authParams)
        return {
            name: 'login',
        }
})

export default router
