import { createStore } from 'vuex'
import lessons from './modules/lessons'
import teachers from './modules/teachers'
export default createStore({
    namespaced: true,
    state: {},
    getters: {},
    mutations: {},
    actions: {},
    modules: {},
})
