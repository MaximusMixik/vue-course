<template>
    <main-masterpage>
        <div>Крок 1. Вибір уроків</div>
        <div v-for="subject in getSubjectsList" :key="subject.id">
            <label>
                {{}}
                <input type="checkbox" />
            </label>
        </div>
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'
import { mapGetters } from 'vuex'

export default {
    name: 'LessonsSelectView',
    components: { MainMasterpage },

    computed: {
        ...mapGetters('subjects', ['getSubjectsList']),
    },
}
</script>

<style lang="scss" scoped></style>
