<template>
    <div>
        <lesson-paid-preview
            v-for="lessonPairIds in lessonsIdsPairs"
            :key="lessonPairIds"
            :lesson-pair="lessonPairIds"
        />
    </div>
</template>

<script>
import LessonPaidPreview from '@/components/LessonPaidPreview.vue'
export default {
    name: 'LessonsPlan',
    props: {

        LessonPaidPreview lessonsIdsPairs: {
            type: Array,
            default: () => [],
        },
    },
}
</script>

<style lang="scss" scoped></style>
