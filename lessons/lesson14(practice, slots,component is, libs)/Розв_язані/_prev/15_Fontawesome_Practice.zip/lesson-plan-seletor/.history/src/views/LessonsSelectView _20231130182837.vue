<template>
    <main-masterpage>
        <div>Lessons</div>
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'

export default {
    name: 'LessonsView',
    components: { MainMasterpage },
}
</script>

<style lang="scss" scoped></style>
