<template>
    <div>
        {{ lessonsIdsPairs }}
    </div>
</template>

<script>
export default {
    name: 'LessonsPlan',
    props: {
        lessonsIdsPairs: {
            type: Array,
            default: () => [],
        },
    },
}
</script>

<style lang="scss" scoped></style>
