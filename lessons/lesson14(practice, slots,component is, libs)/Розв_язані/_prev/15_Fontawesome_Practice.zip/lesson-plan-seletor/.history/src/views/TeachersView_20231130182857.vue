<template>
    <main-masterpage>
        <div>Teachers</div>
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'
export default {
    name: 'TeachersView',
    components: { MainMasterpage },
}
</script>

<style lang="scss" scoped></style>
