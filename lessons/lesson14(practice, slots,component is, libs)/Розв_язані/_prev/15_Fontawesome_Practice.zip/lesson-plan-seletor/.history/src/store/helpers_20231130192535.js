export function getModuleTemplate(moduleName, itemsList) {
    return {
        namespaced: true,
        state: {
            [moduleName]: itemsList,
        },
        getters: {
            getItemById() {},
        },
        mutations: {},
        actions: {},
        modules: {},
    }
}
