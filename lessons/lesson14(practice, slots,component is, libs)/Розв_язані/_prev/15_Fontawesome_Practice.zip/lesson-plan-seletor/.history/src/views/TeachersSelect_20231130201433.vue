<template>
    <div>
        <subject-teachers-selector />
    </div>
</template>

<script>
import SubjectTeachersSelector from '@/components/SubjectTeachersSelector.vue'
export default {
    components: { SubjectTeachersSelector },
    name: 'TeachersSelect',

    computed: {
        subjectId() {
            return this.$route.params.subjectId
        },
    },
}
</script>

<style lang="scss" scoped></style>
