<template>
    <div>
        <font-awesome-icon :icon="['fas', 'bridge-lock']" />
    </div>
    <div>Авторизуйтесь для доступу до сервісів</div>
</template>

<script>
export default {
    name: 'AuthMasterpage',
}
</script>

<style lang="scss" scoped></style>
