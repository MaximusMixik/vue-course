<template>
    <div></div>
</template>

<script>
export default {
    name: 'LessonPaidPreview',
    props: {
        lessonPair: {
            type: String,
            required: true,
        },
    },

    computed: {
        subjectId() {
            return this.lessonPair.split('-')[0]
        },
        teacherId() {
            return this.lessonPair.split('-')[1]
        },
    },
}
</script>

<style lang="scss" scoped></style>
