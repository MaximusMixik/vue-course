<template>
    <div>
        <nav>
            <router-link to="/"> Home </router-link> |
            <router-link to="/about"> About </router-link>
            <router-link to="/contacts"> My Contacts </router-link>
        </nav>
    </div>
</template>

<script>
export default {
    name: 'MainMasterpage',
}
</script>

<style lang="scss" scoped></style>
