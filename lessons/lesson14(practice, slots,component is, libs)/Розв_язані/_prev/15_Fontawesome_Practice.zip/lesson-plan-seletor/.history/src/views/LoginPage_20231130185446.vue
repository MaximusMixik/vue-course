<template>
    <auth-masterpage>
        <div>Login</div>
        <div>
            <label>
                User name
                <input v-model="userName" type="text" placeholder="Type your name" />
            </label>
        </div>
        <div>
            <label>
                Password
                <input v-model="password" type="password" />
            </label>
        </div>
        <button @click="onLogin">Login</button>
    </auth-masterpage>
</template>

<script>
import AuthMasterpage from '@/masterpages/AuthMasterpage.vue'
export default {
    name: 'LoginPage',
    components: { AuthMasterpage },

    data() {
        return {
            userName: null,
            password: null,
        }
    },

    methods: {
        onLogin() {
            localStorage.setItem(
                'authParams',
                JSON.stringify({
                    userName: this.userName,
                    token: 'testToken',
                })
            )
        },
    },
}
</script>

<style lang="scss" scoped></style>
