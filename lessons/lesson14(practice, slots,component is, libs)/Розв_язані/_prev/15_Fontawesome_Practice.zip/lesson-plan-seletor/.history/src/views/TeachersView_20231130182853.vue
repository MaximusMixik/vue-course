<template>
    <main-masterpage>
        <div>Teachers</div>
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'
export default {
    components: { MainMasterpage },
    name: 'TeachersView',
}
</script>

<style lang="scss" scoped></style>
