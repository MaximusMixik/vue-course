<template>
    <auth-masterpage>
        <div>Login</div>
    </auth-masterpage>
</template>

<script>
import AuthMasterpage from '@/masterpages/AuthMasterpage.vue'
export default {
    name: 'LoginPage',
    components: { AuthMasterpage },
}
</script>

<style lang="scss" scoped></style>
