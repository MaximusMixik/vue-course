<template>
    <div>
        <subject-teachers-selector v-for="subId in subjectId" :key="subId" :subject-id="subId" />
    </div>
</template>

<script>
import SubjectTeachersSelector from '@/components/SubjectTeachersSelector.vue'
export default {
    name: 'TeachersSelect',
    components: { SubjectTeachersSelector },

    computed: {
        subjectId() {
            return this.$route.params.subjectId
        },
    },
}
</script>

<style lang="scss" scoped></style>
