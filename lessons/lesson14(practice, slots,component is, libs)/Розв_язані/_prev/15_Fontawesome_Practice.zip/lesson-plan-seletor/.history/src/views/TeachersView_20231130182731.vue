<template>
    <div>Teachers</div>
</template>

<script>
export default {
    name: 'TeachersView',
}
</script>

<style lang="scss" scoped></style>
