<template>
    <div>
        {{ $route.params.subjectId }}
    </div>
</template>

<script>
export default {
    name: 'TeachersSelect',
}
</script>

<style lang="scss" scoped></style>
