<template>
    <div>
        <nav>
            <router-link to="/"> Головна </router-link> | <router-link to="/lessons"> Уроки </router-link> |
            <router-link to="/teachers"> Вчителі </router-link>
        </nav>
        <div></div>
    </div>
    <slot></slot>
</template>

<script>
export default {
    name: 'MainMasterpage',

    computed: {
        authParams() {
            const params = localStorage.getItem('authParams')
            return params ? JSON.parse(params) : null
        },
        userName() {
            return
        },
    },
}
</script>

<style lang="scss" scoped></style>
