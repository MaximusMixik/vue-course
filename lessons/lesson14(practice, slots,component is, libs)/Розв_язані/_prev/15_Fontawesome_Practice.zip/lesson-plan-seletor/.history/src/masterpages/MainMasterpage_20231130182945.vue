<template>
    <div>
        <nav>
            <router-link to="/"> Головна </router-link> |
            <router-link to="/lessons"> Уроки </router-link>
            <router-link to="/teachers"> Вчителі </router-link>
        </nav>
    </div>
    <slot></slot>
</template>

<script>
export default {
    name: 'MainMasterpage',
}
</script>

<style lang="scss" scoped></style>
