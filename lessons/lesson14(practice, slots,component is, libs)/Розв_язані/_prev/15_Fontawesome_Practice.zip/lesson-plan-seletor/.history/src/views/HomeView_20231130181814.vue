<template>
    <div class="home">
        <font-awesome-icon :icon="['fab', 'github']" />
        <font-awesome-icon :icon="['fas', 'car-side']" />
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {},
}
</script>
