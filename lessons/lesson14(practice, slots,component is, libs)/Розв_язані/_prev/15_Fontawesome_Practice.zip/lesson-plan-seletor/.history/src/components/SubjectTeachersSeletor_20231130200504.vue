<template>
    <div></div>
</template>

<script>
export default {
    name: 'SubjectTeachersSeletor',
    props: {
        subjectId: {
            type: [Number, String],
            required: true,
        },
    },
}
</script>

<style lang="scss" scoped></style>
