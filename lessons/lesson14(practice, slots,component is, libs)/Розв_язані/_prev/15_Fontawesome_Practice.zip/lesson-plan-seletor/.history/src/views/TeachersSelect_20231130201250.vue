<template>
    <div>
        {{ $route.params.subjectId }}
    </div>
</template>

<script>
export default {
    name: 'TeachersSelect',

    computed: {
        subjectId() {
            return this.$route.params.subjectId
        },
    },
}
</script>

<style lang="scss" scoped></style>
