<template>
    <main-masterpage>
        <div class="home">
            <font-awesome-icon :icon="['fab', 'github']" />
            <font-awesome-icon :icon="['fas', 'car-side']" />
        </div>
    </main-masterpage>
</template>

<script>
import MainMasterpage from '@/masterpages/MainMasterpage.vue'
export default {
    components: { MainMasterpage },
    name: 'HomeView',
    methods: {},
}
</script>
