<template>
    <div>
        <nav>
            <router-link to="/"> Головна </router-link> | <router-link to="/lessons"> Уроки </router-link> |
            <router-link to="/teachers"> Вчителі </router-link>
        </nav>
        <div>
            <span>userName</span>
            <button @click="onLogout">Вихід</button>
        </div>
    </div>
    <slot></slot>
</template>

<script>
export default {
    name: 'MainMasterpage',

    computed: {
        authParams() {
            const params = localStorage.getItem('authParams')
            return params ? JSON.parse(params) : null
        },
        userName() {
            return this.authParams?.userName
        },
    },

    methods: {
        onLogout() {
            localStorage.setItem('authParams', '')
        },
    },
}
</script>

<style lang="scss" scoped></style>
