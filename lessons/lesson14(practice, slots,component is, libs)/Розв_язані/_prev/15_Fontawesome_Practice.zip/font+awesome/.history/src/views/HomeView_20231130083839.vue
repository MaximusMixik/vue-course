<template>
    <div class="home">
        <font-awesome-icon icon="fa-solid fa-user-secret" />
        <font-awesome-icon :icon="['fab', 'fab-twitter']" />
    </div>
</template>

<script>
export default {
    name: 'HomeView',
    methods: {},
}
</script>
